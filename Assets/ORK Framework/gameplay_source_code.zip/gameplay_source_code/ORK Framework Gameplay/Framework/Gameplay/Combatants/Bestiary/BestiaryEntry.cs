
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BestiaryEntry : ISaveData, IContent
	{
		public List<int> areaIDs;
		
		public BestiaryStatus status;
		
		
		// in-game
		private int combatantID = -1;
		
		private int classID = 0;
		
		private int level = 1;
		
		private int classLevel = 1;
		
		public BestiaryEntry(string key)
		{
			this.Clear();
			this.Init(key);
		}
		
		public BestiaryEntry(string key, DataObject data)
		{
			this.LoadGame(data);
			this.Init(key);
		}
		
		public void Clear()
		{
			this.areaIDs = new List<int>();
			this.status = new BestiaryStatus();
		}
		
		private void Init(string key)
		{
			if(this.combatantID == -1)
			{
				if(ORK.GameSettings.bestiary.separation)
				{
					string[] tmp = key.Split('-');
					if(tmp.Length == 4 && 
						int.TryParse(tmp[0], out this.combatantID))
					{
						this.classID = int.Parse(tmp[1]);
						this.level = int.Parse(tmp[2]);
						this.classLevel = int.Parse(tmp[3]);
					}
					else
					{
						this.combatantID = -1;
					}
				}
				else
				{
					if(int.TryParse(key, out this.combatantID))
					{
						this.combatantID = int.Parse(key);
						this.classID = ORK.Combatants.Get(this.combatantID).startClassID;
						this.level = ORK.Combatants.Get(this.combatantID).startLevel;
						this.classLevel = ORK.Combatants.Get(this.combatantID).startClassLevel;
					}
					else
					{
						this.combatantID = -1;
					}
				}
			}
		}
		
		public bool IsComplete
		{
			get{ return this.status == null;}
			set
			{
				if(value)
				{
					this.status = null;
				}
				else if(this.status == null)
				{
					this.status = new BestiaryStatus();
				}
			}
		}
		
		public void CheckComplete()
		{
			if(this.status != null && this.status.IsComplete())
			{
				this.IsComplete = true;
			}
		}
		
		
		/*
		============================================================================
		Combatant functions
		============================================================================
		*/
		public Combatant GetCombatant()
		{
			if(this.combatantID != -1)
			{
				Combatant combatant = ORK.Combatants.Create(this.combatantID, null);
				combatant.Init(this.level, this.classLevel, this.classID);
				combatant.Bestiary = this;
				return combatant;
			}
			return null;
		}
		
		public int Level
		{
			get{ return this.level;}
		}
		
		public int ClassLevel
		{
			get{ return this.classLevel;}
		}
		
		
		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public string GetName()
		{
			return ORK.Combatants.GetName(this.combatantID);
		}

		public string GetDescription()
		{
			return ORK.Combatants.GetDescription(this.combatantID);
		}
		
		public string GetIconTextCode()
		{
			return ORK.Combatants.Get(this.combatantID).GetIconTextCode();
		}

		public Texture2D GetIcon()
		{
			return ORK.Combatants.GetIcon(this.combatantID);
		}

		public GUIContent GetContent()
		{
			return ORK.Combatants.GetContent(this.combatantID);
		}

		public int ID
		{
			get{ return this.combatantID;}
		}

		public int TypeID
		{
			get{ return this.classID;}
		}
		
		public IContentSimple GetTypeContent()
		{
			return ORK.Classes.Get(this.classID);
		}
		
		public string GetInfo(Combatant c)
		{
			return "";
		}
		
		
		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public DataObject SaveGame()
		{
			DataObject data = new DataObject();
			
			data.Set("areaIDs", this.areaIDs.ToArray());
			if(this.IsComplete)
			{
				data.Set("complete", true);
			}
			else
			{
				data.Set("status", this.status.SaveGame());
			}
			
			return data;
		}

		public void LoadGame(DataObject data)
		{
			this.Clear();
			if(data != null)
			{
				int[] tmp;
				data.Get("areaIDs", out tmp);
				if(tmp != null)
				{
					this.areaIDs.AddRange(tmp);
				}
				
				bool complete = false;
				data.Get("complete", ref complete);
				
				if(complete)
				{
					this.status = null;
				}
				else
				{
					this.status = new BestiaryStatus(data.GetFile("status"));
				}
			}
		}
	}
}
