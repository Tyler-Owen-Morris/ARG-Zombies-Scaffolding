
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BattleActionHandler
	{
		private List<BaseAction> actionList = new List<BaseAction>();
		
		private List<BaseAction> activeActions = new List<BaseAction>();
		
		private List<BaseAction> specialActions = new List<BaseAction>();
		
		public BattleActionHandler()
		{
			
		}
		
		
		/*
		============================================================================
		Clear functions
		============================================================================
		*/
		public void Clear()
		{
			this.actionList = new List<BaseAction>();
			this.activeActions = new List<BaseAction>();
			this.specialActions = new List<BaseAction>();
		}
		
		public void ClearStack()
		{
			this.actionList = new List<BaseAction>();
		}
		
		public void StopActiveActions()
		{
			for(int i=0; i<this.activeActions.Count; i++)
			{
				this.activeActions[i].StopAction();
			}
		}
		
		
		/*
		============================================================================
		Update functions
		============================================================================
		*/
		public void Tick()
		{
			for(int i=0; i<this.specialActions.Count; i++)
			{
				this.specialActions[i].Tick();
			}
			
			for(int i=0; i<this.activeActions.Count; i++)
			{
				this.activeActions[i].Tick();
			}
		}
		
		
		/*
		============================================================================
		Action functions
		============================================================================
		*/
		public void Perform(BaseAction action)
		{
			if(ORK.Battle.System == null || 
				(action is DeathAction && 
					((DeathAction)action).natural && 
					ORK.Battle.DeathImmediately) || 
				action is JoinBattleAction)
			{
				action.PerformAction();
			}
			else
			{
				ORK.Battle.System.PerformAction(action);
			}
		}
		
		public void Finished(BaseAction action)
		{
			if(ORK.Battle.System != null && 
				(!(action is DeathAction) || 
					!((DeathAction)action).natural || 
					!ORK.Battle.DeathImmediately) && 
				!(action is JoinBattleAction))
			{
				ORK.Battle.System.ActionFinished(action);
			}
		}
		
		
		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool Has()
		{
			return this.actionList.Count > 0;
		}
		
		public bool HasActive()
		{
			return this.activeActions.Count > 0;
		}
		
		public bool CanEndBattle()
		{
			return this.specialActions.Count == 0 && this.activeActions.Count == 0 && 
				(this.actionList.Count == 0 || 
					(!this.Contains(ActionType.Death) &&
					!this.Contains(ActionType.Join)));
		}
		
		public bool IsLatestActive(BaseAction action)
		{
			if(this.activeActions.Count > 0 && 
				this.activeActions[this.activeActions.Count - 1] == action)
			{
				return true;
			}
			return false;
		}
		
		public bool Contains(ActionType type)
		{
			for(int i=0; i<this.actionList.Count; i++)
			{
				if(this.actionList[i].IsType(type))
				{
					return true;
				}
			}
			return false;
		}
		
		
		/*
		============================================================================
		Add functions
		============================================================================
		*/
		public void Add(BaseAction action)
		{
			// no battle running
			if(ORK.Battle.System == null)
			{
				if(action != null && !action.IsCastingAbility())
				{
					action.PerformAction();
				}
			}
			// normal actions
			else if(!ORK.Battle.BattleEnd)
			{
				if(action != null)
				{
					action.CheckTargetAggressive();
					// defend actions first?
					if(action is DefendAction && ORK.Battle.DefendFirst)
					{
						this.actionList.Insert(0, action);
					}
					else
					{
						this.actionList.Add(action);
					}
				}
				ORK.Battle.System.ActionAdded(action);
			}
		}
		
		public void Unshift(BaseAction action)
		{
			// no battle running
			if(ORK.Battle.System == null)
			{
				if(action != null && !action.IsCastingAbility())
				{
					action.PerformAction();
				}
			}
			// normal actions
			else if(!ORK.Battle.BattleEnd)
			{
				if(action != null)
				{
					// death or join immediately
					if((action is DeathAction && 
						((DeathAction)action).natural && 
						ORK.Battle.DeathImmediately) || 
						action is JoinBattleAction)
					{
						action.PerformAction();
					}
					// other actions
					else
					{
						action.CheckTargetAggressive();
						this.actionList.Insert(0, action);
						ORK.Battle.System.ActionUnshifted(action);
					}
				}
			}
		}
		
		public void AddActive(BaseAction action)
		{
			if((action is DeathAction && 
					((DeathAction)action).natural && 
					ORK.Battle.DeathImmediately) || 
				action is JoinBattleAction)
			{
				this.specialActions.Add(action);
			}
			else
			{
				this.activeActions.Add(action);
			}
		}
		
		
		/*
		============================================================================
		Remove functions
		============================================================================
		*/
		public void RemoveFromUser(Combatant combatant)
		{
			if(ORK.Battle.System != null && !ORK.Battle.BattleEnd)
			{
				for(int i=0; i<this.actionList.Count; i++)
				{
					if(this.actionList[i].user == combatant && 
						!this.actionList[i].IsType(ActionType.CounterAttack) && 
						!this.actionList[i].IsType(ActionType.Death))
					{
						this.actionList.RemoveAt(i--);
					}
				}
				combatant.Actions.Removed();
			}
		}
		
		public void RemoveTarget(Combatant target)
		{
			if(ORK.Battle.System != null && !ORK.Battle.BattleEnd)
			{
				for(int i=0; i<this.actionList.Count; i++)
				{
					if(this.actionList[i].target.Contains(target) && 
						!this.actionList[i].IsType(ActionType.Death))
					{
						if(this.actionList[i].IsType(ActionType.CounterAttack))
						{
							this.actionList.RemoveAt(i--);
						}
						else
						{
							this.actionList[i].target.Remove(target);
						}
					}
				}
			}
		}
		
		public void RemoveActive(BaseAction action)
		{
			if((action is DeathAction && 
					((DeathAction)action).natural && 
					ORK.Battle.DeathImmediately) || 
				action is JoinBattleAction)
			{
				this.specialActions.Remove(action);
			}
			else
			{
				this.activeActions.Remove(action);
				if(ORK.BattleSettings.camera.blockEventCams && 
					this.activeActions.Count == 0)
				{
					ORK.BattleSettings.camera.SetLatestUser(null);
				}
				if(ORK.Battle.System != null)
				{
					ORK.Battle.System.ActiveActionRemoved();
				}
			}
		}
		
		
		/*
		============================================================================
		Change order functions
		============================================================================
		*/
		public void ChangeOrderFromUser(Combatant combatant, int change)
		{
			if(ORK.Battle.System != null && !ORK.Battle.BattleEnd)
			{
				List<BaseAction> changed = new List<BaseAction>();
				for(int i=0; i<this.actionList.Count; i++)
				{
					if(this.actionList[i].user == combatant && 
						!changed.Contains(this.actionList[i]) && 
						!this.actionList[i].IsType(ActionType.CounterAttack) && 
						!this.actionList[i].IsType(ActionType.Death))
					{
						BaseAction tmpAction = this.actionList[i];
						
						int newIndex = i + change;
						newIndex = Mathf.Max(newIndex, 0);
						newIndex = Mathf.Min(newIndex, this.actionList.Count - 1);
						
						this.actionList.RemoveAt(i);
						this.actionList.Insert(newIndex, tmpAction);
						changed.Add(tmpAction);
					}
				}
			}
		}
		
		
		/*
		============================================================================
		Get functions
		============================================================================
		*/
		public BaseAction NextPerformable()
		{
			for(int i=0; i<this.actionList.Count; i++)
			{
				BaseAction action = this.actionList[i];
				
				if(action.user != null)
				{
					action.user.CheckDeath();
					
					// remove action from dead user
					if(action.user.Dead && !action.IsType(ActionType.Death))
					{
						this.actionList.RemoveAt(i--);
					}
					// action found
					else if(!action.user.Actions.InAction && 
						(action.IsType(ActionType.Death) || action.IsType(ActionType.CounterAttack) || 
						action.user.Actions.AllowPerformingAction(action.autoAttackFlag)))
					{
						this.actionList.RemoveAt(i);
						return action;
					}
				}
			}
			return null;
		}
	}
}
