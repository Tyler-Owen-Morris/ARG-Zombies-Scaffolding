
using System.Collections.Generic;

namespace ORKFramework
{
	public class ItemBMItem : BMItem
	{
		private ItemShortcut item;
		
		public ItemBMItem(ItemShortcut item, ChoiceContent content)
		{
			this.item = item;
			this.content = content;
		}
		
		public override void CreateDrag(Combatant owner)
		{
			if(this.content.drag == null)
			{
				// drag+drop
				this.content.isDragable = ORK.BattleSettings.bmDrag;
				this.content.clickCount = ORK.BattleSettings.bmClick ? ORK.BattleSettings.bmClickCount : 0;
				this.content.isTooltip = ORK.BattleSettings.bmTooltip;
				if(this.content.isDragable || this.content.clickCount > 0 || this.content.isTooltip)
				{
					this.content.drag = this.item.GetDrag(owner.BattleMenu, owner);
				}
			}
			
			// portrait
			if(this.content.portrait == null && 
				owner.BattleMenu.Settings.showItemPortraits && 
				this.item.HasPortrait())
			{
				this.content.portrait = this.item.GetPortrait();
			}
		}
		
		public override bool ActiveCheck(Combatant owner)
		{
			bool tmp = this.content.Active;
			this.content.Active = this.item.CanUse(owner, true) && 
				(this.item.Setting.targetSettings.NoneTarget() || 
					this.item.Setting.targetSettings.GetPossibleTargets(owner, 
						ORK.Game.Combatants.Get(owner, true, Range.Battle, 
							Consider.No, Consider.Ignore, owner.InBattle ? Consider.Yes : Consider.Ignore), 
						ORK.Game.Combatants.Get(owner, true, Range.Battle, 
							Consider.Yes, Consider.Ignore, owner.InBattle ? Consider.Yes : Consider.Ignore)).Count > 0);
			return tmp != this.content.Active;
		}

		public override void Selected(Combatant owner)
		{
			if(owner.BattleMenu != null)
			{
				if(this.item.Setting.targetSettings.TargetSelf())
				{
					BaseAction action = new ItemAction(owner, this.item);
					action.SetTarget(owner);
					owner.Actions.Add(action, false);
				}
				else if(this.item.Setting.targetSettings.NoneTarget())
				{
					BaseAction action = new ItemAction(owner, this.item);
					if(action.targetRaycast.NeedInteraction())
					{
						owner.BattleMenu.RayAction = action;
					}
					else
					{
						if(action.targetRaycast.active)
						{
							action.rayTargetSet = true;
							action.rayPoint = action.targetRaycast.GetRayPoint(owner.GameObject, VectorHelper.GetScreenCenter());
						}
						owner.Actions.Add(action, false);
					}
				}
				else
				{
					// use on group target
					if(owner.BattleMenu.Settings.useGroupTarget)
					{
						Combatant target = owner.Group.SelectedTargets.GetItemTarget(owner, this.item);
						if(target != null)
						{
							BaseAction action = new ItemAction(owner, this.item);
							action.SetTarget(target);
							owner.Actions.Add(action, false);
							return;
						}
					}
					// use on individual target
					if(owner.BattleMenu.Settings.useIndividualTarget)
					{
						Combatant target = owner.SelectedTargets.GetItemTarget(owner, this.item);
						if(target != null)
						{
							BaseAction action = new ItemAction(owner, this.item);
							action.SetTarget(target);
							owner.Actions.Add(action, false);
							return;
						}
					}
					
					// display target menu
					List<BMItem> list = new List<BMItem>();
					
					if(owner.BattleMenu.Settings.addBack && 
						owner.BattleMenu.Settings.backFirst && 
						ORK.BattleSettings.useTargetMenu)
					{
						list.Add(new BackBMItem(
							owner.BattleMenu.Settings.contentLayout.GetChoiceContent(ORK.MenuSettings.backButton)));
					}
					
					List<Combatant> targets = this.item.Setting.targetSettings.GetPossibleTargets(owner, 
						ORK.Game.Combatants.Get(owner, true, Range.Battle, 
							Consider.No, Consider.Ignore, owner.InBattle ? Consider.Yes : Consider.Ignore), 
						ORK.Game.Combatants.Get(owner, true, Range.Battle, 
							Consider.Yes, Consider.Ignore, owner.InBattle ? Consider.Yes : Consider.Ignore));
					
					int selection = -1;
					if(this.item.Setting.targetSettings.SingleTarget())
					{
						for(int i=0; i<targets.Count; i++)
						{
							List<Combatant> tmp = new List<Combatant>();
							tmp.Add(targets[i]);
							list.Add(new TargetBMItem(
								owner.BattleMenu.GetCombatantChoice(targets[i]), 
								this.item, tmp));
							
							if(selection < 0 && this.item.Setting.targetSettings.useAutoTarget && 
								this.item.Setting.targetSettings.autoTarget.Check(targets[i]))
							{
								selection = i;
							}
						}
					}
					else if(this.item.Setting.targetSettings.GroupTarget())
					{
						list.Add(new TargetBMItem(
							ORK.BattleTexts.GetAllCombatantsContent(
								this.item.Setting.targetSettings.targetType, 
								owner.BattleMenu.Settings.contentLayout), 
							this.item, targets));
					}
					
					if(owner.BattleMenu.Settings.addBack && 
						!owner.BattleMenu.Settings.backFirst && 
						ORK.BattleSettings.useTargetMenu)
					{
						list.Add(new BackBMItem(
							owner.BattleMenu.Settings.contentLayout.GetChoiceContent(ORK.MenuSettings.backButton)));
					}
					
					owner.BattleMenu.Show(list, selection < 0 ? 0 : selection, BattleMenuMode.Target);
				}
			}
		}
	}
}
