
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ActiveBattleMenu : IChoice, IDragOrigin
	{
		private bool isOpen = false;
		
		private int menuID = 0;
		
		private BattleMenu settings;
		
		private Combatant owner;
		
		private Combatant commandedBy;
		
		
		// list items
		private List<BMItem> items;
		
		private ChoiceContent[] choices;

		private int[] choiceActions;
		
		private BattleMenuMode mode;
		
		private Dictionary<BattleMenuMode, int> rememberedSelection = new Dictionary<BattleMenuMode, int>();
		
		
		// raycasting
		private BaseAction rayAction = null;
		
		
		// box/content
		private GUIBox box;
		
		private DialogueContent content;
		
		private string title = "";
		
		private float lastUpdate = 0;
		
		
		// description
		private GUIBox descBox;
		
		
		// selection
		private int currentSelection = 0;
		
		
		// breadcrumbs
		private Stack<List<BMItem>> lastItems = new Stack<List<BMItem>>();
		
		private Stack<int> lastSelections = new Stack<int>();
		
		private Stack<BattleMenuMode> lastModes = new Stack<BattleMenuMode>();
		
		public ActiveBattleMenu(Combatant owner, int menuID)
		{
			this.owner = owner;
			this.menuID = menuID;
			this.settings = ORK.BattleMenus.Get(this.menuID);
		}
		
		public string GetTitle()
		{
			if(this.settings.showTitle)
			{
				return this.settings.title[ORK.Game.Language].
					Replace("%n", this.owner.GetName()).
					Replace("%d", this.owner.GetDescription()).
					Replace("%i", this.owner.GetIconTextCode());
			}
			return "";
		}
		
		public ChoiceContent GetCombatantChoice(Combatant combatant)
		{
			if(this.settings.ownCombatantChoice)
			{
				return this.settings.combatantChoice.GetChoiceContent(combatant);
			}
			else
			{
				return ORK.MenuSettings.combatantChoice.GetChoiceContent(combatant);
			}
		}
		
		public BattleMenu Settings
		{
			get{ return this.settings;}
		}
		
		public int MenuID
		{
			get{ return this.menuID;}
		}
		
		public bool IsOpen
		{
			get{ return this.isOpen;}
			set
			{
				if(this.isOpen != value)
				{
					this.isOpen = value;
					
					if(this.isOpen)
					{
						this.owner.Actions.IsChoosing = true;
						ORK.Battle.DoBattleMenuBlock(1);
						if(ORK.Battle.IsRealTime() && ORK.BattleSystem.realTime.menuPause && 
							ORK.BattleSystem.realTime.freezeAction)
						{
							ORK.Game.FreezeTime(true);
						}
						
						// play opening audio
						if(this.settings.openClip != null)
						{
							ORK.Audio.PlayOneShot(this.settings.openClip, this.settings.openVolume * ORK.Game.SoundVolume);
						}
					}
					else
					{
						ORK.Battle.DoBattleMenuBlock(-1);
						if(ORK.Battle.IsRealTime() && ORK.BattleSystem.realTime.menuPause && 
							ORK.BattleSystem.realTime.freezeAction)
						{
							ORK.Game.FreezeTime(false);
						}
						ORK.Battle.RemoveMenuUser(this.owner);
						ORK.Battle.SetMenuFinished();
						
						// play closing audio
						if(this.settings.closeClip != null)
						{
							ORK.Audio.PlayOneShot(this.settings.closeClip, this.settings.closeVolume * ORK.Game.SoundVolume);
						}
					}
				}
			}
		}
		
		public bool RememberSelection
		{
			get{ return this.settings.rememberSelection;}
		}
		
		public void Clear()
		{
			this.ClearTargetSelection();
			this.currentSelection = -2;
			this.items = null;
			this.lastSelections = new Stack<int>();
			this.lastItems = new Stack<List<BMItem>>();
			this.lastModes = new Stack<BattleMenuMode>();
			this.title = this.GetTitle();
			this.choices = null;
			this.choiceActions = null;
		}
		
		public void Close()
		{
			this.Clear();
			if(this.box != null)
			{
				this.currentSelection = -2;
				this.box.InitOut();
				this.CloseDescription();
			}
			else
			{
				this.IsOpen = false;
				if(this.commandedBy != null)
				{
					this.commandedBy.BattleMenu.Show(true);
					this.commandedBy = null;
				}
			}
		}
		
		public void Reset(bool call)
		{
			// clear target selection
			this.ClearTargetSelection();
			if(call)
			{
				this.Show();
			}
			else
			{
				if(this.box != null)
				{
					if(this.box.Content != null)
					{
						this.box.Content.controlInterface = null;
					}
					this.box.InitOut();
					this.box = null;
					this.CloseDescription();
				}
				this.Clear();
			}
		}
		
		public bool Controlable
		{
			get{ return this.box != null && this.box.Controlable;}
		}
		
		public GUIBox Box
		{
			get{ return this.box;}
		}
		
		public Combatant CommandedBy
		{
			get{return this.commandedBy;}
			set{ this.commandedBy = value;}
		}
		
		
		/*
		============================================================================
		Ok/cancel button functions
		============================================================================
		*/
		public bool ShowOKButton(GUIBox origin)
		{
			return false;
		}
		
		public bool ShowCancelButton(GUIBox origin)
		{
			return false;
		}
		
		public bool IsOKButtonActive(GUIBox origin)
		{
			return false;
		}
		
		public bool IsCancelButtonActive(GUIBox origin)
		{
			return false;
		}
		
		
		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public void Show()
		{
			this.Show(false);
		}
		
		public void Show(bool reset)
		{
			if(this.box == null || reset)
			{
				this.Clear();
				this.Show(this.settings.GetMenu(this.owner), 0, BattleMenuMode.List);
			}
		}
		
		public void Show(List<BMItem> list, int selection, BattleMenuMode mode)
		{
			if(!this.isOpen)
			{
				this.IsOpen = true;
				ORK.Battle.AddMenuUser(this.owner);
			}
			if(this.box != null)
			{
				this.StoreCurrent();
				if(this.box.Content != null)
				{
					this.box.Content.controlInterface = null;
				}
				this.box.InitOut();
				this.box = null;
				this.CloseDescription();
			}
			
			this.mode = mode;
			this.items = list;
			this.currentSelection = selection;
			this.CheckList();
			this.lastUpdate = Time.time;
			
			this.box = ORK.GUIBoxes.Create(this.settings.GetGUIBoxID(this.mode));
			
			if(BattleMenuMode.Target.Equals(this.mode))
			{
				if(this.settings.selectSelf)
				{
					for(int i=0; i<this.items.Count; i++)
					{
						if(this.items[i] is TargetBMItem && 
							this.items[i].Contains(this.owner))
						{
							this.currentSelection = i;
							break;
						}
					}
				}
				if(this.settings.selectLastTarget)
				{
					for(int i=0; i<this.items.Count; i++)
					{
						if(this.items[i] is TargetBMItem && 
							this.items[i].ContainsAny(this.owner.LastTargets))
						{
							this.currentSelection = i;
							break;
						}
					}
				}
				this.box.hidden = !ORK.BattleSettings.useTargetMenu;
			}
			else if(this.RememberSelection && 
				this.rememberedSelection.ContainsKey(this.mode))
			{
				this.currentSelection = this.rememberedSelection[this.mode];
			}
			
			this.CreateChoices();
			
			if(this.currentSelection < 0)
			{
				this.currentSelection = 0;
			}
			else if(this.currentSelection >= this.choices.Length)
			{
				this.currentSelection = this.choices.Length - 1;
			}
			
			this.content = new DialogueContent("", this.title, this.choices, this, this.currentSelection, 
				this.settings.showPortrait ? this.owner.GetPortrait(this.settings.portraitTypeID) : null, 
				BattleMenuMode.Target.Equals(this.mode) ? 
					(this.settings.ownCombatantChoice ? 
						this.settings.combatantChoice.GetStatusElements() : 
						ORK.MenuSettings.combatantChoice.GetStatusElements()) : 
					null);
			this.content.header = this.settings.GetHeaderContent(this.mode);
			
			if(this.settings.showPortrait && this.settings.ownPortraitPosition)
			{
				this.content.setPortraitPosition = this.settings.portraitPosition;
			}
			
			this.box.inPause = ORK.Battle.IsRealTime() && 
				ORK.BattleSystem.realTime.menuPause && 
				ORK.BattleSystem.realTime.freezeAction;
			
			this.box.Content = this.content;
			this.box.InitIn();
			this.SelectionChanged(this.currentSelection, this.box);
		}
		
		private void ShowDescription(string desc)
		{
			// hide description box
			if(this.descBox != null && desc == "" && !this.settings.descAlways)
			{
				this.descBox.InitOut();
				this.descBox = null;
			}
			// show/change description box
			else if(this.settings.useDesc && (desc != "" || this.settings.descAlways))
			{
				if(this.descBox == null)
				{
					this.descBox = ORK.GUIBoxes.Create(this.settings.descBoxID);
					this.descBox.controlable = false;
					this.descBox.InitIn();
				}
				this.descBox.Content = new DialogueContent(desc, this.settings.GetDescriptionTitle(), null, null);
			}
		}
		
		public void FocusGained(GUIBox origin)
		{
			
		}
		
		public void FocusLost(GUIBox origin)
		{
			
		}
		
		private void CloseDescription()
		{
			if(this.descBox != null)
			{
				this.descBox.InitOut();
				this.descBox = null;
			}
		}

		public void Closed(GUIBox origin)
		{
			this.box = null;
			this.content = null;
			
			if(this.currentSelection == -2)
			{
				this.IsOpen = false;
				if(this.commandedBy != null)
				{
					this.commandedBy.BattleMenu.Show(true);
					this.commandedBy = null;
				}
			}
			else if(this.currentSelection == -1)
			{
				this.Back();
			}
			else if(this.currentSelection >= 0 && 
				this.currentSelection < this.items.Count)
			{
				if(!(this.items[this.currentSelection] is BackBMItem))
				{
					this.StoreCurrent();
				}
				this.items[this.currentSelection].Selected(this.owner);
			}
		}
		
		public void Back()
		{
			if(this.lastSelections.Count > 0)
			{
				this.Show(this.lastItems.Pop(), this.lastSelections.Pop(), this.lastModes.Pop());
			}
			else if(ORK.Battle.IsMenuBackAllowed || this.commandedBy != null)
			{
				this.owner.EndBattleMenu(true);
			}
			else
			{
				this.Show();
			}
		}
		
		private void StoreCurrent()
		{
			if(this.items != null)
			{
				this.lastSelections.Push(this.currentSelection);
				this.lastItems.Push(this.items);
				this.lastModes.Push(this.mode);
			}
		}
		
		
		/*
		============================================================================
		Choice handling functions
		============================================================================
		*/
		public void CreateChoices()
		{
			List<ChoiceContent> cc = new List<ChoiceContent>();
			List<int> ca = new List<int>();
			for(int i=0; i<this.items.Count; i++)
			{
				this.items[i].CreateDrag(this.owner);
				cc.Add(this.items[i].content);
				ca.Add(i);
			}
			this.choices = cc.ToArray();
			this.choiceActions = ca.ToArray();
		}

		public void ChoiceSelected(int index, GUIBox origin)
		{
			if(index >= 0 && index < this.choiceActions.Length)
			{
				this.ClearTargetSelection();
				this.currentSelection = this.choiceActions[index];
				
				// remember selection
				if(!BattleMenuMode.Target.Equals(this.mode) && 
					this.RememberSelection)
				{
					if(this.rememberedSelection.ContainsKey(this.mode))
					{
						this.rememberedSelection[this.mode] = this.currentSelection;
					}
					else
					{
						this.rememberedSelection.Add(this.mode, this.currentSelection);
					}
				}
				
				this.box.InitOut();
				this.CloseDescription();
			}
		}

		public void SelectionChanged(int index, GUIBox origin)
		{
			// stop blinking old target
			this.ClearTargetSelection();
			if(index >= 0 && index < this.choiceActions.Length)
			{
				this.ShowDescription(this.choices[index].description);
				this.currentSelection = this.choiceActions[index];
				
				// remember selection
				if(!BattleMenuMode.Target.Equals(this.mode) && 
					this.RememberSelection)
				{
					if(this.rememberedSelection.ContainsKey(this.mode))
					{
						this.rememberedSelection[this.mode] = this.currentSelection;
					}
					else
					{
						this.rememberedSelection.Add(this.mode, this.currentSelection);
					}
				}
				
				// start blinking new target
				if(this.currentSelection >= 0 && 
					this.currentSelection < this.items.Count)
				{
					this.items[this.currentSelection].Blink(true);
				}
			}
		}

		public void Canceled(GUIBox origin)
		{
			if(this.lastSelections.Count > 0)
			{
				this.ClearTargetSelection();
				this.box.Audio.PlayCancel();
				this.currentSelection = -1;
				this.box.InitOut();
				this.CloseDescription();
			}
			else if(ORK.Battle.IsMenuBackAllowed || this.commandedBy != null)
			{
				this.ClearTargetSelection();
				this.box.Audio.PlayCancel();
				this.owner.EndBattleMenu(true);
			}
		}
		
		public bool CombatantClicked(Combatant combatant)
		{
			for(int i=0; i<this.items.Count; i++)
			{
				if(this.items[i].Contains(combatant))
				{
					this.ClearTargetSelection();
					this.currentSelection = i;
					this.box.InitOut();
					this.CloseDescription();
					return true;
				}
			}
			return false;
		}
		
		public void ClearTargetSelection()
		{
			if(this.items != null && 
				this.currentSelection >= 0 && 
				this.currentSelection < this.items.Count)
			{
				this.items[this.currentSelection].Blink(false);
			}
		}
		
		
		/*
		============================================================================
		Update functions
		============================================================================
		*/
		public bool Tick(GUIBox origin)
		{
			if(this.rayAction != null)
			{
				if(ORK.InputKeys.Get(ORK.GameControls.cancelKey).GetButton())
				{
					this.rayAction = null;
					this.Back();
				}
				else
				{
					this.rayAction.targetRaycast.Tick(this, this.owner.GameObject);
				}
			}
			else if((Time.time - this.lastUpdate) > this.settings.updateInterval)
			{
				this.CheckList();
				this.lastUpdate = Time.time;
			}
			return false;
		}
		
		private bool CheckList()
		{
			bool changed = false;
			if(this.items != null)
			{
				for(int i=0; i<this.items.Count; i++)
				{
					if(this.items[i].ActiveCheck(this.owner))
					{
						changed = true;
					}
				}
			}
			return changed;
		}

		public void ChangeAbilityLevel(int change)
		{
			if(this.currentSelection >= 0 && 
				this.currentSelection < this.items.Count)
			{
				if(this.items[this.currentSelection].ChangeUseLevel(change, this.owner))
				{
					this.CreateChoices();
					if(this.content != null)
					{
						this.content.choice = this.choices;
						this.content.newContent = true;
					}
				}
			}
		}
		
		
		/*
		============================================================================
		Raycast functions
		============================================================================
		*/
		public BaseAction RayAction
		{
			get{ return this.rayAction;}
			set{ this.rayAction = value;}
		}
		
		public void SetRayPoint(Vector3 point)
		{
			if(this.rayAction != null)
			{
				this.rayAction.rayTargetSet = true;
				this.rayAction.rayPoint = point;
				this.AddAction(this.rayAction);
				this.rayAction = null;
			}
		}
		
		
		/*
		============================================================================
		Drag and drop functions
		============================================================================
		*/
		public void Dropped(DragInfo drag)
		{
			
		}
		
		public bool DroppedOnCombatant(Combatant c, DragInfo drag)
		{
			if(drag != null)
			{
				if(this.commandedBy != null)
				{
					BaseAction action = drag.GetAction();
					if(action != null)
					{
						action.SetTarget(c);
						this.AddAction(action);
						return true;
					}
				}
				else
				{
					return drag.UseOn(c, true);
				}
			}
			return false;
		}
		
		public bool DroppedToWorld(Vector3 position, DragInfo drag)
		{
			return false;
		}
		
		
		/*
		============================================================================
		Action functions
		============================================================================
		*/
		public void AddAction(BaseAction action)
		{
			if(this.commandedBy != null)
			{
				this.owner.Actions.NextAction = action;
				this.owner.EndBattleMenu(true);
			}
			else
			{
				this.owner.Actions.Add(action, false);
			}
		}
	}
}
