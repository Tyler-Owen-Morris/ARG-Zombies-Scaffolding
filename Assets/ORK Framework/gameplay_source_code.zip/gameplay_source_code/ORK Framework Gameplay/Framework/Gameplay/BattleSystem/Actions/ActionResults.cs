
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ActionResults
	{
		public int hit = 0;
		
		public int critical = 0;
		
		public int miss = 0;
		
		public int block = 0;
		
		public ActionResults()
		{
			
		}
		
		public BattleActionResult GetResult()
		{
			if(this.critical >= this.hit && 
				this.critical >= this.miss && 
				this.critical >= this.block)
			{
				return BattleActionResult.Critical;
			}
			else if(this.miss >= this.hit && 
				this.miss >= this.critical && 
				this.miss >= this.block)
			{
				return BattleActionResult.Miss;
			}
			else if(this.block >= this.hit && 
				this.block >= this.critical && 
				this.block >= this.miss)
			{
				return BattleActionResult.Block;
			}
			return BattleActionResult.Hit;
		}
	}
}
