
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	[System.Serializable]
	public class BattleCombatant
	{
		[ORKEditorInfo(ORKDataType.Faction)]
		public int factionID = 0;
		
		public bool useGroup = true;
		
		public CombatantGroupMember member;
		
		[ORKEditorInfo(ORKDataType.CombatantGroup)]
		public int id = 0;
		
		public BattleCombatant()
		{
			
		}
		
		public Group GetGroup(CombatantSpawner spawner, int spawnerIndex, bool respawn)
		{
			Group group = null;
			if(this.useGroup)
			{
				group = ORK.CombatantGroups.Create(this.id, this.factionID);
				
			}
			else if(this.member != null)
			{
				group = new Group(this.factionID);
				this.member.Create(group);
			}
			if(group != null)
			{
				group.SetSpawner(spawner, spawnerIndex, respawn);
			}
			return group;
		}
	}
}
