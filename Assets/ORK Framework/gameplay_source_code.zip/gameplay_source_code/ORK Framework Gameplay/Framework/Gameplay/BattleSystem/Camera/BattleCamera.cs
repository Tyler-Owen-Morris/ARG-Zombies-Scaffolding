
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BattleCamera : BaseData
	{
		[ORKEditorHelp("Block Event Camera", "Camera changes by battle events are blocked.\n" +
			"The battle camera settings are only available when this setting is enabled.\n" +
			"Please note that the battle camera is only used if the camera controls are blocked.", "")]
		public bool blockEventCams = false;
		
		[ORKEditorHelp("Combatant Center", "The camera will use the center of all combatants " +
			"for it's rotation and look movements.\n" +
			"If disabled, the position of the battle arena is used.", "")]
		[ORKEditorLayout("blockEventCams", true)]
		public bool useCombatantCenter = false;
		
		[ORKEditorHelp("Remember Position", "The last position of the base battle camera is remembered.\n" +
			"If the battle camera changes (e.g. to look at the latest target), " +
			"it will return to the remembered position after it's 'look at' action is finished.", "")]
		public bool rememberPosition = false;
		
		[ORKEditorHelp("Look Damping", "The damping for 'look at' camera changes.\n" +
			"The higher the value, the faster the camera will get to it's looking position.\n" +
			"A lower value will result in a smoother camera movement.", "")]
		public float lookAtDamping = 5.0f;
		
		
		// rotation
		[ORKEditorHelp("Rotation Axis", "Set at the camera's rotation axis by setting it's X, Y and Z rotation.\n" +
			"E.g. X=0, Y=1, Z=0 will rotate along the Y-axis around the battle arena.\n" +
			"A value between 0 and 1 is recommended.", "")]
		[ORKEditorInfo(separator=true)]
		public Vector3 rotationAxis = Vector3.zero;
		
		[ORKEditorHelp("Rotation Speed", "The speed at which the camera will rotate.\n" +
			"Set the speed to 0 if no camera rotation is wanted.\n" +
			"Use negative numbers to invert rotation.", "")]
		public float rotationSpeed = 0;
		
		
		// rotation limit
		[ORKEditorHelp("Limit Rotation", "The rotation is limited to defined minimum/maximum degrees.\n" +
			"If the camera rotation reaches a limit (rotation at battle start + min/max rotation), " +
			"the rotation is inverted (the camera rotates into the opposite direction).", "")]
		[ORKEditorInfo(separator=true)]
		public bool limitRotation = false;
		
		[ORKEditorHelp("Minimum Rotation", "The minimum rotation of the camera (left limit) in degree.\n" +
			"The value has to be between -180 and 0.", "")]
		[ORKEditorLayout("limitRotation", true)]
		public Vector3 minRotation = Vector3.zero;
		
		[ORKEditorHelp("Maximum Rotation", "The maximum rotation of the camera (right limit) in degree.\n" +
			"The value has to be between 0 and 180.", "")]
		[ORKEditorInfo(callbackAfter="check:rotations")]
		[ORKEditorLayout(endCheckGroup=true)]
		public Vector3 maxRotation = Vector3.zero;
		
		
		// damage
		[ORKEditorInfo("Look At Latest Damage", "The camera can look at the last combatant who received damage.", "", 
			endFoldout=true, separatorForce=true)]
		public LookAtSettings latestDamage = new LookAtSettings();
		
		// user
		[ORKEditorInfo("Look At Latest User", "The camera can look at the combatant " +
			"who performs the current action (i.e. the last action that has been started).", "", 
			endFoldout=true)]
		public LookAtSettings latestUser = new LookAtSettings();
		
		// menu
		[ORKEditorInfo("Look At Menu User", "The camera can look at the combatant with the battle menu opened.", "", 
			endFoldout=true)]
		public LookAtSettings menuUser = new LookAtSettings();
		
		// selection
		[ORKEditorInfo("Look At Selection", "The camera can look at the currently selected combatant (target selection).", "", 
			endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public LookAtSettings selection = new LookAtSettings();
		
		
		// ingame
		private bool lookingAtSomething = false;

		private bool forceReset = false;

		private int blockedByAnimation = 0;

		private Transform camera = null;

		private Camera cameraComponent = null;

		private bool activated = false;
		
		private BattleComponent battleComponent = null;
		
		private int lastLookAtIndex = -1;

		private Vector3 lastPos = Vector3.zero;

		private Quaternion lastRot = Quaternion.identity;
		
		private float lastFoV = 40;
		
		private Vector3 useRotationAxis = Vector3.zero;

		private Vector3 startRotationAxis = Vector3.zero;
		
		
		// look at reset times
		private float damageTimeout = -1;
		
		private float userTimeout = -1;
		
		private float menuTimeout = -1;
		
		private float selectionTimeout = -1;
		
		public BattleCamera()
		{
			
		}
		
		
		/*
		============================================================================
		Look at functions
		============================================================================
		*/
		private void ClearLookTargets()
		{
			this.latestDamage.Target = null;
			this.damageTimeout = -1;
			
			this.latestUser.Target = null;
			this.userTimeout = -1;
			
			this.menuUser.Target = null;
			this.menuTimeout = -1;
			
			this.selection.Target = null;
			this.selectionTimeout = -1;
		}
		
		public void SetLatestDamage(Transform t)
		{
			if(this.latestDamage.enable && 
				this.latestDamage.Target != t)
			{
				this.ClearLookTargets();
				this.latestDamage.Target = t;
				if(this.latestDamage.Target != null)
				{
					this.latestDamage.Set(this.camera);
					if(this.latestDamage.time > 0)
					{
						this.damageTimeout = this.latestDamage.time;
					}
				}
			}
		}
		
		public void SetLatestUser(Transform t)
		{
			if(this.latestUser.enable && 
				this.latestUser.Target != t)
			{
				this.ClearLookTargets();
				this.latestUser.Target = t;
				if(this.latestUser.Target != null)
				{
					this.latestUser.Set(this.camera);
					if(this.latestUser.time > 0)
					{
						this.userTimeout = this.latestUser.time;
					}
				}
			}
		}
		
		public void SetMenuUser(Transform t)
		{
			if(this.menuUser.enable && 
				this.menuUser.Target != t)
			{
				this.ClearLookTargets();
				this.menuUser.Target = t;
				if(this.menuUser.Target != null)
				{
					this.menuUser.Set(this.camera);
					if(this.menuUser.time > 0)
					{
						this.menuTimeout = this.menuUser.time;
					}
				}
			}
		}
		
		public void SetSelection(Transform t)
		{
			if(this.selection.enable && 
				this.selection.Target != t)
			{
				this.ClearLookTargets();
				this.selection.Target = t;
				if(this.selection.Target != null)
				{
					this.selection.Set(this.camera);
					if(this.selection.time > 0)
					{
						this.selectionTimeout = this.selection.time;
					}
				}
			}
		}
		
		
		/*
		============================================================================
		Block functions
		============================================================================
		*/
		public void BlockedByAnimation(bool block)
		{
			if(block)
			{
				this.blockedByAnimation++;
			}
			else
			{
				this.blockedByAnimation--;
			}
			this.forceReset = true;
		}
		
		
		/*
		============================================================================
		Camera functions
		============================================================================
		*/
		public void Tick()
		{
			if(ORK.Control.CameraBlocked && 
				this.blockEventCams && this.blockedByAnimation == 0 && 
				this.activated && this.camera != null)
			{
				// reset timers
				if(this.damageTimeout > 0)
				{
					this.damageTimeout -= Time.deltaTime;
					if(this.damageTimeout <= 0)
					{
						this.SetLatestDamage(null);
					}
				}
				if(this.userTimeout > 0)
				{
					this.userTimeout -= Time.deltaTime;
					if(this.userTimeout <= 0)
					{
						this.SetLatestUser(null);
					}
				}
				if(this.menuTimeout > 0)
				{
					this.menuTimeout -= Time.deltaTime;
					if(this.menuTimeout <= 0)
					{
						this.SetMenuUser(null);
					}
				}
				if(this.selectionTimeout > 0)
				{
					this.selectionTimeout -= Time.deltaTime;
					if(this.selectionTimeout <= 0)
					{
						this.SetSelection(null);
					}
				}
				
				
				int index = -1;
				bool looking = false;
				bool resetBase = true;
				
				if(this.selection.Target != null && this.selection.CheckCamPos())
				{
					if(this.selection.simpleLook)
					{
						index = 0;
						Quaternion rotation = Quaternion.LookRotation(this.selection.Target.position - this.camera.position);
						this.camera.rotation = Quaternion.Slerp(this.camera.rotation, rotation, this.lookAtDamping * Time.deltaTime);
					}
					else
					{
						this.selection.Rotate(this.camera);
						looking = true;
					}
					resetBase = false;
					this.lookingAtSomething = true;
				}
				if(resetBase && this.menuUser.Target != null && this.menuUser.CheckCamPos())
				{
					if(this.menuUser.simpleLook)
					{
						index = 1;
						Quaternion rotation = Quaternion.LookRotation(this.menuUser.Target.position - this.camera.position);
						this.camera.rotation = Quaternion.Slerp(this.camera.rotation, rotation, this.lookAtDamping * Time.deltaTime);
					}
					else
					{
						this.menuUser.Rotate(this.camera);
						looking = true;
					}
					resetBase = false;
					this.lookingAtSomething = true;
				}
				if(resetBase && this.latestDamage.Target != null && this.latestDamage.CheckCamPos())
				{
					if(this.latestDamage.simpleLook)
					{
						index = 2;
						Quaternion rotation = Quaternion.LookRotation(this.latestDamage.Target.position - this.camera.position);
						this.camera.rotation = Quaternion.Slerp(this.camera.rotation, rotation, this.lookAtDamping * Time.deltaTime);
					}
					else
					{
						this.latestDamage.Rotate(this.camera);
						looking = true;
					}
					resetBase = false;
					this.lookingAtSomething = true;
				}
				if(resetBase && this.latestUser.Target != null && this.latestUser.CheckCamPos())
				{
					if(this.latestUser.simpleLook)
					{
						index = 2;
						Quaternion rotation = Quaternion.LookRotation(this.latestUser.Target.position - this.camera.position);
						this.camera.rotation = Quaternion.Slerp(this.camera.rotation, rotation, this.lookAtDamping * Time.deltaTime);
					}
					else
					{
						this.latestUser.Rotate(this.camera);
						looking = true;
					}
					resetBase = false;
					this.lookingAtSomething = true;
				}
				
				if(!looking)
				{
					if(this.forceReset || 
						(this.lookingAtSomething && 
						(resetBase || index != this.lastLookAtIndex)))
					{
						this.camera.position = this.lastPos;
						this.camera.rotation = this.lastRot;
						if(this.cameraComponent != null)
						{
							this.cameraComponent.fieldOfView = this.lastFoV;
						}
						this.forceReset = false;
						this.lookingAtSomething = false;
					}
					
					if(this.rotationSpeed != 0)
					{
						if(this.useCombatantCenter)
						{
							this.camera.RotateAround(ORK.Battle.GetCombatantCenter().transform.position, 
									this.useRotationAxis, this.rotationSpeed * Time.deltaTime);
						}
						else
						{
							this.camera.RotateAround(this.battleComponent.transform.position, 
									this.useRotationAxis, this.rotationSpeed * Time.deltaTime);
						}
						
						if(this.limitRotation)
						{
							Vector3 tmpRot = this.camera.eulerAngles - this.startRotationAxis;
							VectorHelper.SecureVector(ref tmpRot, -190, 190, 360);
							
							// X-axis
							if(tmpRot.x <= this.minRotation.x)
							{
								this.useRotationAxis.x = -this.useRotationAxis.x;
							}
							else if(tmpRot.x >= this.maxRotation.x)
							{
								this.useRotationAxis.x = -this.useRotationAxis.x;
							}
							// Y-axis
							if(tmpRot.y <= this.minRotation.y)
							{
								this.useRotationAxis.y = -this.useRotationAxis.y;
							}
							else if(tmpRot.y >= this.maxRotation.y)
							{
								this.useRotationAxis.y = -this.useRotationAxis.y;
							}
							// Z-axis
							if(tmpRot.z <= this.minRotation.z)
							{
								this.useRotationAxis.z = -this.useRotationAxis.z;
							}
							else if(tmpRot.z >= this.maxRotation.z)
							{
								this.useRotationAxis.z = -this.useRotationAxis.z;
							}
						}
					}
					
					if(this.rememberPosition)
					{
						this.lastPos = this.camera.position;
						this.lastRot = this.camera.rotation;
						if(this.cameraComponent != null)
						{
							this.lastFoV = this.cameraComponent.fieldOfView;
						}
					}
				}
				this.lastLookAtIndex = index;
			}
		}
		
		public void StartBattle(BattleComponent battleComponent)
		{
			this.battleComponent = battleComponent;
			this.useRotationAxis = this.rotationAxis;
			this.startRotationAxis = Vector3.zero;
			this.lookingAtSomething = false;
			if(Camera.main)
			{
				this.camera = Camera.main.transform;
				this.cameraComponent = this.camera.GetComponent<Camera>();
				this.lastPos = this.camera.position;
				this.lastRot = this.camera.rotation;
				if(this.cameraComponent != null)
				{
					this.lastFoV = this.cameraComponent.fieldOfView;
				}
				this.startRotationAxis = this.camera.eulerAngles;
			}
			
			this.latestDamage.Target = null;
			this.latestUser.Target = null;
			this.menuUser.Target = null;
			this.selection.Target = null;
			this.lastLookAtIndex = -1;
			this.blockedByAnimation = 0;
			this.forceReset = false;
			this.activated = true;
		}
		
		public void EndBattle()
		{
			this.activated = false;
			this.blockedByAnimation = 0;
			this.lookingAtSomething = false;
			this.forceReset = false;
			this.camera = null;
			this.cameraComponent = null;
			this.latestDamage.Target = null;
			this.latestUser.Target = null;
			this.menuUser.Target = null;
			this.selection.Target = null;
			this.battleComponent = null;
			this.lastLookAtIndex = -1;
			this.lastPos = Vector3.zero;
			this.lastRot = Quaternion.identity;
		}
	}
}
