
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class MoveDetection : BaseData
	{
		[ORKEditorHelp("Type", "Select how movement will be detected within the defined settings:\n" +
			"- Sight: The combatant only needs to be present.\n" +
			"- Movement: The combatants needs to move (requires a CharacterController or Rigidbody component).", "")]
		public MoveDetectionType type = MoveDetectionType.Sight;
		
		
		// sight
		[ORKEditorHelp("Use Raycast", "Use a raycast to check if any other objects are between combatant and target.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("type", MoveDetectionType.Sight)]
		public bool useRaycast = false;
		
		[ORKEditorHelp("Layer Mask", "The layer mask used for the raycast.ground.", "")]
		[ORKEditorLayout("useRaycast", true)]
		public LayerMask rayLayerMask = -1;
		
		[ORKEditorHelp("Use Child", "The position of the defined child of the combatant's game object " +
			"will be used for the raycast.\n" +
			"If the child can't be found, the game object itself will be used.\n" +
			"Define the child as Path/To/Child, use / to separate game objects in the hierarchy.\n" +
			"Leave empty if no child object should be used.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string rayChildName = "";
		
		[ORKEditorHelp("Use Child Target", "The position of the defined child of the target's game object " +
			"will be used as the raycast's target.\n" +
			"If the child can't be found, the game object itself will be used.\n" +
			"Define the child as Path/To/Child, use / to separate game objects in the hierarchy.\n" +
			"Leave empty if no child object should be used.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2)]
		public string rayChildTarget = "";
		
		
		// movement
		[ORKEditorHelp("Minimum Speed", "The minimum speed at which the combatant must move to be detected.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("type", MoveDetectionType.Movement)]
		[ORKEditorLimit(0.0f, false)]
		public float minSpeed = 1;
		
		[ORKEditorHelp("Horizontal Speed", "Only the horizontal speed will be used for the check.\n" +
			"If disabled, also the vertical speed (e.g. jumping) will be used.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool horizontalSpeed = false;
		
		
		// range
		[ORKEditorInfo(separator=true, labelText="Range Settings")]
		public Range range = new Range(20);
		
		
		// radius
		[ORKEditorHelp("Angle", "The angle (0 to 360) at which a combatant will be detected.\n" +
			"E.g. 180 will detect combatants at an angle of 90 degree to the left and right.", "")]
		[ORKEditorInfo(separator=true, labelText="Angle Settings")]
		[ORKEditorLimit(0.0f, 360.0f)]
		public float angle = 360;
		
		[ORKEditorHelp("Angle Offset", "The offset (-180 to 180) added to the angle, e.g.:\n" +
			"- 0 is front" +
			"- -90 is left" +
			"- 90 is right" +
			"- 180/-180 is back", "")]
		[ORKEditorLimit(-180.0f, 180.0f)]
		public float angleOffset = 0;
		
		public MoveDetection()
		{
			
		}
		
		
		/*
		============================================================================
		Detection functions
		============================================================================
		*/
		public bool Detected(Combatant owner, Combatant target)
		{
			if(owner != null && owner.GameObject != null && 
				target != null && target.GameObject != null)
			{
				if(this.range.InRange(owner, target))
				{
					// absolute value of the angle
					float tmpAngle = Mathf.Abs(VectorHelper.HorizontalAngle(owner.GameObject.transform, target.GameObject.transform) - this.angleOffset);
					// angle to the left and right
					if(tmpAngle <= this.angle / 2)
					{
						if(MoveDetectionType.Sight.Equals(this.type))
						{
							if(this.useRaycast)
							{
								Vector3 origin = TransformHelper.GetChild(this.rayChildName, owner.GameObject.transform).position;
								RaycastOutput[] hit = RaycastHelper.RaycastAll(origin, 
									VectorHelper.GetDirection(origin, 
										TransformHelper.GetChild(this.rayChildTarget, target.GameObject.transform).position), 
									range.range, this.rayLayerMask);
								
								for(int i=0; i<hit.Length; i++)
								{
									if(hit[i].transform.root.gameObject != owner.GameObject.transform.root.gameObject || 
										hit[i].transform.root.gameObject != target.GameObject.transform.root.gameObject)
									{
										return false;
									}
								}
							}
							return true;
						}
						else if(MoveDetectionType.Movement.Equals(this.type))
						{
							CharacterController cc = target.GameObject.GetComponent<CharacterController>();
							if(cc != null)
							{
								if(this.horizontalSpeed)
								{
									return new Vector3(cc.velocity.x, 0, cc.velocity.z).magnitude >= this.minSpeed;
								}
								else
								{
									return cc.velocity.magnitude >= this.minSpeed;
								}
							}
							else
							{
								Rigidbody rb = target.GameObject.GetComponent<Rigidbody>();
								if(rb != null)
								{
									if(this.horizontalSpeed)
									{
										return new Vector3(rb.velocity.x, 0, rb.velocity.z).magnitude >= this.minSpeed;
									}
									else
									{
										return rb.velocity.magnitude >= this.minSpeed;
									}
								}
							}
						}
					}
				}
			}
			return false;
		}
	}
}
