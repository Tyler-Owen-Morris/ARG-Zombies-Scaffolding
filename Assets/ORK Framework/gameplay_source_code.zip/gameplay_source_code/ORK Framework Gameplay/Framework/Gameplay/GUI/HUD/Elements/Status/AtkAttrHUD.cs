
using UnityEngine;
using ORKFramework.Display;
using System.Collections.Generic;

namespace ORKFramework
{
	public class AtkAttrHUD : BaseData
	{
		// attribute
		[ORKEditorHelp("Attribute Group", "Select the attack attribute group that will be displayed.", "")]
		[ORKEditorInfo(ORKDataType.AttackAttributes, separator=true)]
		public int id = 0;
		
		[ORKEditorHelp("Group Information", "The name, description and icon displayed will be from the selected attribute group.\n" +
			"If disabled, the information of a selected attribute of the group (or a list of all attributes) will be displayed.", "")]
		public bool groupInfo = false;
		
		// data origin
		[ORKEditorHelp("Value Origin", "Select where the displayed value will come from:\n" +
			"- Current: The current value of the attack attributes.\n" +
			"- Preview: The preview value of the attack attributes. If no preview is available, the current value is used instead.\n" +
			"- Preview Hide: The preview value of the attack attributes. Hidden if no preview is available.\n" +
			"- Preview Hide No Change: The preview value of the attack attributes. Only hides values if there is no change to the current value." +
			"A preview value displays how the attack attributes will change if a selected equipment would be equipped. " +
			"Preview values are only available for player group members.", "")]
		[ORKEditorLayout("groupInfo", false, setDefault=true, defaultValue=HUDStatusOrigin.Current)]
		public HUDStatusOrigin origin = HUDStatusOrigin.Current;
		
		[ORKEditorInfo("Positive Change Text Format", "Define the appearance of the text for a positive change, " +
			"e.g. color, shadow, font size.", "", endFoldout=true)]
		[ORKEditorLayout("origin", HUDStatusOrigin.Current, elseCheckGroup=true)]
		public TextFormat previewPositiveFormat = TextFormat.Default;
		
		[ORKEditorInfo("Negative Change Text Format", "Define the appearance of the text for a negative change, " +
			"e.g. color, shadow, font size.", "", endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public TextFormat previewNegativeFormat = TextFormat.Default;
		
		
		// list
		[ORKEditorHelp("List All", "All attributes of the selected group will be listed.\n" +
			"If disabled, only the selected attribute of the group will be displayed.", "")]
		public bool list = false;
		
		// TODO: list > optionally check value, e.g. > 100
		
		[ORKEditorHelp("Offset", "The offset of each listed attribute.", "")]
		[ORKEditorLayout("list", true)]
		public Vector2 off = new Vector2(0, 30);
		
		[ORKEditorHelp("Set Size", "Set the size of the individual attack attribute manually.\n" +
			"If disabled, the size defined by the bounds is used.", "")]
		public bool setSize = false;
		
		[ORKEditorHelp("Size", "The width (X) and height (Y) of each attack attribute.", "")]
		[ORKEditorLayout("setSize", true, endCheckGroup=true)]
		public Vector2 size = new Vector2(100, 20);
		
		[ORKEditorHelp("Keep List Position", "The position of the list will be fixed by the index of the attribute.\n" +
			"E.g. if an attribute isn't displayed due to a value check, " +
			"an empty line will be displayed instead of the next attribute.\n" +
			"If disabled, not displayed attributes will be replaced by the next attribute, shortening the list.", "")]
		public bool keepListPosition = false;
		
		// list conditions
		[ORKEditorHelp("Check Attribute Value", "Check the attribute value of the listed attributes.\n" +
			"Only attributes with a valid check will be listed (e.g. value > 100 to show a weakness).\n" +
			"If disabled, all attributes will be listed.", "")]
		public bool checkAttributeValue = false;
		
		[ORKEditorHelp("Check Type", "Checks if the attribute's value is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the value is between two defind values, including the values.\n" +
			"Range exclusive checks if the value is between two defined values, excluding the values.\n" +
			"Approximately checks if the value is similar to the defined value.", "")]
		[ORKEditorLayout("checkAttributeValue", true)]
		public VariableValueCheck listCheck = VariableValueCheck.IsEqual;
		
		[ORKEditorHelp("Check Value", "Define the value that will be used for the check.", "")]
		public float listValue = 0;
		
		[ORKEditorHelp("Check Value 2", "Define the 2nd value that will be used for the range check.", "")]
		[ORKEditorLayout(new string[] {"listCheck", "listCheck"}, 
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive}, 
			needed=Needed.One, endCheckGroup=true, endGroups=2)]
		public float listValue2 = 0;
		
		
		// single attribute
		[ORKEditorHelp("Attribute", "Select the attribute that will be displayed.", "")]
		[ORKEditorInfo(ORKDataType.AttackAttributes, idFieldName="id")]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, endGroups=2)]
		public int id2 = 0;
		
		
		// text
		[ORKEditorInfo(separator=true, label=new string[] {
			"%n = name, %d = description, %i = icon", 
			"% = current value (not available for group info)", 
			"%c = change between current and preview value (not available for group info)"
		})]
		public StatusTextHUD text = new StatusTextHUD();
		
		public AtkAttrHUD()
		{
			
		}
		
		
		/*
		============================================================================
		Create label functions
		============================================================================
		*/
		public void CreateLabels(out List<BaseLabel> label, Combatant combatant, bool isBestiary, Rect bounds)
		{
			label = new List<BaseLabel>();
			
			if(this.groupInfo)
			{
				label = new MultiContent(
					TextHelper.ReplaceSpecials(this.text.text[ORK.Game.Language].
						Replace("%n", ORK.AttackAttributes.GetName(this.id)).
						Replace("%d", ORK.AttackAttributes.GetDescription(this.id)).
						Replace("%i", TextCode.AttackAttributeIcon + this.id + "#").
						Replace("%", "")), 
					null, null, bounds, this.text.lineSpacing, this.text.alignment, 
					this.text.vAlignment, BoxHeightAdjustment.Auto, false, this.text.textFormat).label;
			}
			else if(this.list)
			{
				int count = 0;
				for(int i=0; i<ORK.AttackAttributes.AttributeCount(this.id); i++)
				{
					if(this.CreateAttribute(ref label, combatant, isBestiary, i, 
						new Rect(this.off.x * count, this.off.y * count, 
							this.setSize ? this.size.x : bounds.width, 
							this.setSize ? this.size.y : bounds.height)) || 
						this.keepListPosition)
					{
						count++;
					}
				}
			}
			else
			{
				this.CreateAttribute(ref label, combatant, isBestiary, this.id2, bounds);
			}
		}
		
		private bool CreateAttribute(ref List<BaseLabel> label, Combatant combatant, bool isBestiary, 
			int index, Rect bounds)
		{
			int change = 0;
			float value = 0;
			
			if(HUDStatusOrigin.Current.Equals(this.origin))
			{
				value = combatant.Status.GetAttackAttribute(this.id).GetValue(index);
			}
			else if(HUDStatusOrigin.Preview.Equals(this.origin))
			{
				if(combatant.Status.PreviewAvailable)
				{
					value = combatant.Status.GetAttackAttribute(this.id).GetPreviewValue(index);
					change = value.CompareTo(combatant.Status.GetAttackAttribute(this.id).GetValue(index));
				}
				else
				{
					value = combatant.Status.GetAttackAttribute(this.id).GetValue(index);
				}
			}
			else if(HUDStatusOrigin.PreviewHide.Equals(this.origin))
			{
				if(combatant.Status.PreviewAvailable)
				{
					value = combatant.Status.GetAttackAttribute(this.id).GetPreviewValue(index);
					change = value.CompareTo(combatant.Status.GetAttackAttribute(this.id).GetValue(index));
				}
				else
				{
					return false;
				}
			}
			else if(HUDStatusOrigin.PreviewHideNoChange.Equals(this.origin))
			{
				if(combatant.Status.PreviewAvailable)
				{
					value = combatant.Status.GetAttackAttribute(this.id).GetPreviewValue(index);
					
					if(value == combatant.Status.GetAttackAttribute(this.id).GetValue(index))
					{
						return false;
					}
					
					change = value.CompareTo(combatant.Status.GetAttackAttribute(this.id).GetValue(index));
				}
				else
				{
					return false;
				}
			}
			
			if(!this.checkAttributeValue || 
				ValueHelper.CheckVariableValue(value, this.listValue, this.listValue2, this.listCheck))
			{
				int previewChange = (int)(combatant.Status.GetAttackAttribute(this.id).GetPreviewValue(index) - 
					combatant.Status.GetAttackAttribute(this.id).GetValue(index));
				string tmpText = "";
				
				if(!isBestiary || combatant.Bestiary == null || combatant.Bestiary.IsComplete || 
					combatant.Bestiary.status.attackAttribute[this.id].attribute[index])
				{
					tmpText = TextHelper.ReplaceSpecials(this.text.text[ORK.Game.Language].
						Replace("%n", ORK.AttackAttributes.GetName(this.id, index)).
						Replace("%d", ORK.AttackAttributes.GetDescription(this.id, index)).
						Replace("%i", TextCode.AttackAttributeSubIcon + this.id + "#" + index + "#").
						Replace("%c", previewChange.ToString()).
						Replace("%", value.ToString()));
				}
				else
				{
					change = 0;
					tmpText = TextHelper.ReplaceSpecials(this.text.text[ORK.Game.Language].
						Replace("%n", ORK.AttackAttributes.GetName(this.id, index)).
						Replace("%d", ORK.AttackAttributes.GetDescription(this.id, index)).
						Replace("%i", TextCode.AttackAttributeSubIcon + this.id + "#" + index + "#").
						Replace("%c", previewChange.ToString()).
						Replace("%", ORK.GameSettings.bestiary.attackAttributeText[ORK.Game.Language]));
				}
				
				label.AddRange(new MultiContent(tmpText, null, null, bounds, 
					this.text.lineSpacing, this.text.alignment, 
					this.text.vAlignment, BoxHeightAdjustment.Auto, false, 
					change > 0 ? 
					this.previewPositiveFormat : 
						(change < 0 ? 
							this.previewNegativeFormat : 
							this.text.textFormat)).label);
				
				return true;
			}
			else
			{
				return false;
			}
		}
	}
}
