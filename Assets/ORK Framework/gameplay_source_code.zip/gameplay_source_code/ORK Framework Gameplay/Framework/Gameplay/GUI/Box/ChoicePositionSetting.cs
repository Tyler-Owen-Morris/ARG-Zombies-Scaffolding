
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ChoicePositionSetting : BaseData
	{
		[ORKEditorHelp("Position", "Define the position of this choice.\n" +
			"The position is defined relative to the text displayed in the GUI box, " +
			"i.e. X=0, Y=0 is located in the upper left corner of the new line after the text.", "")]
		public Vector2 position = Vector2.zero;
		
		[ORKEditorHelp("Choice Anchor", "Select the anchor of the choice.", "")]
		public TextAnchor anchor = TextAnchor.MiddleCenter;
		
		[ORKEditorHelp("Set Size", "Set the size of the choice.", "")]
		public bool setSize = false;
		
		[ORKEditorHelp("Size", "Define the width (X) and height (Y) of the choice.", "")]
		[ORKEditorLayout("setSize", true, endCheckGroup=true)]
		public Vector2 size = new Vector2(50, 50);
		
		public ChoicePositionSetting()
		{
			
		}
	}
}
