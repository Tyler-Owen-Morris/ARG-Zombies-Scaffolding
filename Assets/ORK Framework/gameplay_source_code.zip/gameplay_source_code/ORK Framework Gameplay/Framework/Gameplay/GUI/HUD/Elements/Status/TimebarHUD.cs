
using UnityEngine;
using ORKFramework.Display;
using System.Collections.Generic;

namespace ORKFramework
{
	public class TimebarHUD : BaseData
	{
		[ORKEditorHelp("Used Timebar", "The used timebar will be displayed - " +
			"it's used to display how much of the timebar will be used by already selected actions.\n" +
			"If disabled, the actual timebar will be displayed.", "")]
		public bool usedTB = false;
		
		
		// value bar
		[ORKEditorHelp("Use Bar", "The timebar will be displayed as a bar instead of text.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useBar = false;
		
		[ORKEditorHelp("Bar Bounds", "The position and size of the bar.\n" +
			"The coordinates X=0, Y=0 are located at the upper left corner of this element's bounds.", "")]
		[ORKEditorLayout("useBar", true)]
		public Rect barBounds = new Rect(0, 0, 100, 10);
		
		[ORKEditorLayout(autoInit=true)]
		public ValueBar bar;
		
		
		// text
		[ORKEditorInfo(separator=true, label=new string[] {"% = current value, %m = maximum value"})]
		[ORKEditorLayout(elseCheckGroup=true, autoInit=true)]
		public StatusTextHUD text;
		
		[ORKEditorHelp("Time Format", "Define the format that will be used for the time.\n" +
			"E.g.: 0.0 will display one decimal.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public string timeFormat = "0.0";
		
		public TimebarHUD()
		{
			
		}
		
		
		/*
		============================================================================
		Create label functions
		============================================================================
		*/
		public void CreateLabels(out List<BaseLabel> label, Combatant combatant, Rect bounds)
		{
			label = new List<BaseLabel>();
			
			if(this.useBar)
			{
				this.bar.Create(ref label, 
					new Rect(this.barBounds.x + bounds.x, this.barBounds.y + bounds.y, this.barBounds.width, this.barBounds.height), 
					this.usedTB ? combatant.UsedTimeBar : combatant.TimeBar, 0, ORK.BattleSystem.activeTime.maxTimebar);
			}
			else
			{
				label.AddRange(new MultiContent(
					TextHelper.ReplaceSpecials(this.text.text[ORK.Game.Language].
						Replace("%m", ORK.BattleSystem.activeTime.maxTimebar.ToString(this.timeFormat)).
						Replace("%", this.usedTB ? 
							combatant.UsedTimeBar.ToString(this.timeFormat) : 
							combatant.TimeBar.ToString(this.timeFormat))), 
					null, null, bounds, this.text.lineSpacing, this.text.alignment, 
					this.text.vAlignment, BoxHeightAdjustment.Auto, false, 
					this.text.textFormat).label);
			}
		}
	}
}
