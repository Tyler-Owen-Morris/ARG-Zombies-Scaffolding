
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BattleInfo : BaseData
	{
		[ORKEditorHelp("Enable", "This info text will be displayed.", "")]
		public bool enable = true;
		
		[ORKEditorHelp("Text", "The text of this info.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("enable", true, endCheckGroup=true)]
		public string[] text;
		
		public BattleInfo()
		{
			
		}
		
		public BattleInfo(string t)
		{
			this.text = ArrayHelper.CreateArray(ORK.Languages.Count, t);
		}
		
		
		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public void Show(Combatant user, string info)
		{
			if(this.enable && ORK.Battle.DisplayInfoTexts() && user != null)
			{
				if(ORK.BattleTexts.infoAtCom && 
					user != null && user.GameObject != null)
				{
					if(user.BattleInfo != null && 
						!user.BattleInfo.FadingOut && 
						!user.BattleInfo.FadedOut && 
						ORK.BattleTexts.infoComUpdate)
					{
						((DialogueContent)user.BattleInfo.Content).Update(this.text[ORK.Game.Language].
								Replace("%u", user.GetName()).
								Replace("%", info), "", null, 0, null, null);
						user.BattleInfo.CloseAfter(ORK.BattleTexts.infoTime, false);
					}
					else
					{
						user.BattleInfo = ORK.GUI.CreateInfoBox(
							this.text[ORK.Game.Language].
								Replace("%u", user.GetName()).
								Replace("%", info), 
							"", ORK.BattleTexts.infoBoxID, ORK.BattleTexts.infoTime, null, 
							TransformHelper.GetChildObject(ORK.BattleTexts.infoChildName, user.GameObject), ORK.BattleTexts.infoPosOff);
					}
				}
				else
				{
					ORK.GUI.BattleInfo = ORK.GUI.CreateInfoBox(
						this.text[ORK.Game.Language].
							Replace("%u", user.GetName()).
							Replace("%", info), 
						"", ORK.BattleTexts.infoBoxID, ORK.BattleTexts.infoTime, null, 
						null, Vector2.zero);
				}
			}
		}
	}
}

