
using UnityEngine;
using ORKFramework.Display;
using System.Collections.Generic;

namespace ORKFramework
{
	public class PortraitHUD : BaseData
	{
		[ORKEditorHelp("Portrait Type", "Select the portrait type that will be dispalyed.\n" +
			"The combatant needs to have a portrait with this type.\n" +
			"Please note that the portrait is displayed within the box/button!", "")]
		[ORKEditorInfo(ORKDataType.PortraitType)]
		public int portraitTypeID = 0;
		
		
		// position
		[ORKEditorHelp("Position", "Set the X and Y position of the portrait within the element's bounds.", "")]
		[ORKEditorInfo(labelText="Portrait Position")]
		public Vector2 position = Vector2.zero;
		
		[ORKEditorHelp("Anchor", "Select the anchor of the portrait position.\n" +
			"E.g. 'Upper Left' will place the upper left corner of the image at the defined position, " +
			"'Lower Right' will place the lower right corner of the image at the defind position.", "")]
		public TextAnchor anchor = TextAnchor.UpperLeft;
		
		[ORKEditorHelp("Relative To", "Select the the corner of the element's bounds the portrait's position will be relative to.", "")]
		public TextAnchor relativeTo = TextAnchor.UpperLeft;
		
		
		// size
		[ORKEditorHelp("Vertical Scale", "The portrait will be scaled using the screen height.\n" +
			"If disabled, the screen height will be used to scale.", "")]
		[ORKEditorInfo(separator=true, labelText="Portrait Size")]
		public bool verticalScale = false;
		
		[ORKEditorHelp("Set Size", "Set the size of the portrait.\n" +
		 	"If disabled, the width and height of the portrait image are used.\n" +
		 	"Please note, that the image can be distorted if you set the size.", "")]
		public bool setSize = false;
		
		[ORKEditorHelp("Size", "Set the width (X) and height (Y) of the portrait.", "")]
		[ORKEditorLayout("setSize", true, endCheckGroup=true)]
		public Vector2 imageSize = new Vector2(100, 100);
		
		public PortraitHUD()
		{
			
		}
		
		
		/*
		============================================================================
		Create label functions
		============================================================================
		*/
		public void CreateLabels(out List<BaseLabel> label, Combatant combatant, Rect bounds, Texture2D image)
		{
			label = new List<BaseLabel>();
			
			if(image != null)
			{
				Vector2 ratio = new Vector2(Screen.width / ORK.GameSettings.defaultScreen.x, 
					Screen.height / ORK.GameSettings.defaultScreen.y);
				
				Rect tmpBounds = new Rect(this.position.x, this.position.y, 
					((this.setSize ? this.imageSize.x : image.width) / ratio.x) * (this.verticalScale ? ratio.x : ratio.y), 
					((this.setSize ? this.imageSize.y : image.height) / ratio.y) * (this.verticalScale ? ratio.x : ratio.y));
				
				Vector2 tmp = GUIHelper.GetRectAnchor(bounds, this.relativeTo);
				tmpBounds.x += (tmp.x - bounds.x);
				tmpBounds.y += (tmp.y - bounds.y);
				
				GUIHelper.GetRectAnchor(ref tmpBounds, -tmpBounds.width, -tmpBounds.height, this.anchor);
				
				label.Add(new ImageLabel(image, tmpBounds, ScaleMode.StretchToFill, true, 0));
			}
		}
	}
}
