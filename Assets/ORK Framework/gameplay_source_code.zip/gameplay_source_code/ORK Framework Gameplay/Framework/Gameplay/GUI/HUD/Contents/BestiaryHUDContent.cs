
using UnityEngine;
using ORKFramework;
using ORKFramework.Display;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BestiaryHUDContent : GUIBoxContent
	{
		private Combatant combatant;
		
		private HUDStatus[] element;
		
		private bool showOkCancelButtons = false;
		
		
		// created content
		private List<MultiHUDContent> content;
		
		private bool autoUpdate = false;
		
		private float updateInterval = 0;
		
		private float updateTime = 0;
		
		private bool markUpdate = false;
		
		
		// set portrait
		private int portraitType = -1;
		
		private Portrait setPortrait;
		
		public PortraitPosition setPortraitPosition;
		
		// displayed portrait
		private Portrait portrait;
		
		private PortraitPosition portraitPosition;
		
		public BestiaryHUDContent(Combatant combatant, string name, int portraitType, 
			IChoice ci, HUDStatus[] element, bool showOkCancel)
		{
			this.Combatant = combatant;
			this.SetName(name);
			this.portraitType = portraitType;
			this.controlInterface = ci;
			this.element = element;
			this.showOkCancelButtons = showOkCancel;
			
			this.newContent = true;
		}
		
		public void Update(Combatant combatant, string name, int portraitType, IChoice ci, HUDStatus[] element)
		{
			this.Combatant = combatant;
			this.SetName(name);
			this.portraitType = portraitType;
			this.controlInterface = ci;
			this.element = element;
			
			this.newContent = true;
		}
		
		public Combatant Combatant
		{
			get{ return this.combatant;}
			set
			{
				if(this.combatant != value)
				{
					if(Application.isPlaying)
					{
						if(this.combatant != null)
						{
							this.combatant.UpdateHUD -= this.Recalculate;
							ORK.GUI.UpdateHUD -= this.Recalculate;
						}
						this.combatant = value;
						if(this.combatant != null)
						{
							this.combatant.UpdateHUD += this.Recalculate;
							ORK.GUI.UpdateHUD += this.Recalculate;
						}
					}
					else
					{
						this.combatant = value;
					}
					
					this.portrait = null;
					this.portraitPosition = null;
					this.newContent = true;
				}
			}
		}

		public override void Tick()
		{
			base.Tick();
			if(this.box != null)
			{
				if(this.markUpdate)
				{
					this.newContent = true;
					this.markUpdate = false;
				}
				else if(this.box.Controlable && 
						this.controlInterface != null && this.box.Focused && 
						!this.controlInterface.Tick(this.box))
				{
					if(!this.box.disableChoice)
					{
						if(ORK.InputKeys.Get(ORK.GameControls.acceptKey).GetButton())
						{
							this.OkPressed();
						}
					}
					
					if(ORK.InputKeys.Get(ORK.GameControls.cancelKey).GetButton())
					{
						this.CancelPressed();
					}
					else
					{
						float v = ORK.InputKeys.Get(ORK.GameControls.verticalAxis).GetAxis();
						if(v < -0.3)
						{
							this.scroll.y += ORK.MenuSettings.scrollSpeed;
						}
						else if(v > 0.3)
						{
							this.scroll.y -= ORK.MenuSettings.scrollSpeed;
						}
					}
				}
			}
		}
		
		public override void OkPressed()
		{
			ORK.InputKeys.ResetInputAxes();
			if(this.controlInterface != null)
			{
				this.box.Audio.PlayAccept();
				this.controlInterface.ChoiceSelected(this.selection, this.box);
			}
		}
		
		public override void CancelPressed()
		{
			ORK.InputKeys.ResetInputAxes();
			if(this.controlInterface != null)
			{
				this.controlInterface.Canceled(this.box);
			}
		}
		
		public override void Closed()
		{
			if(this.combatant != null && Application.isPlaying)
			{
				this.combatant.UpdateHUD -= this.Recalculate;
				ORK.GUI.UpdateHUD -= this.Recalculate;
			}
			this.combatant = null;
			if(this.controlInterface != null)
			{
				this.controlInterface.Closed(this.box);
			}
		}
		
		public void SetAutoUpdate(float interval)
		{
			this.autoUpdate = interval > 0;
			this.updateInterval = interval;
			this.updateTime = interval;
		}
		
		
		/*
		============================================================================
		Init functions
		============================================================================
		*/
		public override void Init(GUIBox box)
		{
			if(this.newContent)
			{
				this.box = box;
				this.newContent = false;
				this.markUpdate = false;
				
				this.CalculateContent(this.box.bounds.width - (this.box.Settings.boxPadding.x + this.box.Settings.boxPadding.z), false);
				
				this.UpdatePortrait();
			}
		}
		
		private void CalculateContent(float baseWidth, bool recalced)
		{
			this.content = new List<MultiHUDContent>();
			
			float contentHeight = 0;
			
			if(this.element != null)
			{
				for(int i=0; i<this.element.Length; i++)
				{
					MultiHUDContent mhc = new MultiHUDContent(this.element[i]);
					mhc.UpdateContent(this.combatant, true);
					
					if(mhc.label != null)
					{
						if(contentHeight < this.element[i].bounds.y + mhc.bounds.height)
						{
							contentHeight = this.element[i].bounds.y + mhc.bounds.height;
						}
						
						this.content.Add(mhc);
					}
				}
			}
			
			if(BoxHeightAdjustment.Auto.Equals(this.box.Settings.heightAdjustment) && 
				!this.box.forceSize)
			{
				this.box.bounds.height = contentHeight + this.box.Settings.boxPadding.y + this.box.Settings.boxPadding.w;
			}
			else if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
			{
				this.scrollRect = new Rect(this.box.Settings.boxPadding.x, this.box.Settings.boxPadding.y, 
					baseWidth, contentHeight);
			}
			
			this.contentBounds = new Rect(this.box.Settings.boxPadding.x, this.box.Settings.boxPadding.y, 
				this.box.bounds.width - (this.box.Settings.boxPadding.x + this.box.Settings.boxPadding.z), 
				this.box.bounds.height - (this.box.Settings.boxPadding.y + this.box.Settings.boxPadding.w));
			
			if(!recalced && contentHeight > this.contentBounds.height && 
				BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
			{
				float scrollbarWidth = 0;
				if(ORK.GUI.IsNewUI)
				{
					if(this.box.Skins.scrollbarPrefab != null)
					{
						RectTransform rect = this.box.Skins.scrollbarPrefab.GetComponent<RectTransform>();
						if(rect != null)
						{
							scrollbarWidth = rect.sizeDelta.x;
						}
					}
				}
				else
				{
					scrollbarWidth = GUI.skin.verticalScrollbar.fixedWidth;
				}
				this.CalculateContent(baseWidth - (scrollbarWidth + this.box.Settings.scrollPadding), true);
			}
			else if(this.showOkCancelButtons)
			{
				this.CalculateButtons();
			}
		}
		
		private void UpdatePortrait()
		{
			Portrait tmpPortrait = this.portrait;
			
			if(this.portraitType != -1 && this.combatant != null)
			{
				this.setPortrait = this.combatant.GetPortrait(this.portraitType);
			}
			
			if(this.setPortrait != null && this.setPortrait.image != null)
			{
				this.portrait = this.setPortrait;
			}
			else
			{
				this.portrait = null;
			}
			
			if(this.portrait != null && this.portrait.image != null)
			{
				this.portrait.image.wrapMode = TextureWrapMode.Clamp;
				
				if(this.setPortraitPosition != null)
				{
					this.portraitPosition = this.setPortraitPosition;
				}
				else if(this.portrait.ownPortraitPosition)
				{
					this.portraitPosition = this.portrait.portraitPosition;
				}
				else if(this.box.Settings.ownPortraitPosition)
				{
					this.portraitPosition = this.box.Settings.portraitPosition;
				}
				else
				{
					this.portraitPosition = ORK.MenuSettings.portraitPosition;
				}
			}
			
			// new UI
			if(tmpPortrait != this.portrait)
			{
				this.CreatePortraitObject(this.portrait, this.portraitPosition);
			}
		}
		
		public override void CreateNewUI()
		{
			if(ORK.GUI.IsNewUI && 
				this.box.gameObject != null)
			{
				GameObject parent = this.UpdatePanel();
				
				// create
				int index = 0;
				if(this.labelObject == null)
				{
					this.labelObject = new List<RectTransform>();
				}
				else
				{
					for(int i=0; i<this.labelObject.Count; i++)
					{
						if(this.labelObject[i] == null)
						{
							this.labelObject.RemoveAt(i--);
						}
						else
						{
							this.labelObject[i].SetParent(null, false);
						}
					}
				}
				
				// display content
				for(int i=0; i<this.content.Count; i++)
				{
					this.content[i].CreateObjects(this.box, parent, this.labelObject, ref index);
				}
				
				// update labels
				for(int i=0; i<this.labelObject.Count; i++)
				{
					// remove empty
					if(this.labelObject[i] == null)
					{
						this.labelObject.RemoveAt(i--);
					}
					// remove exceeding labels
					else if(i >= index)
					{
						GameObject.Destroy(this.labelObject[i].gameObject);
						this.labelObject.RemoveAt(i--);
					}
				}
				
				// portrait
				this.CreatePortraitObject(this.portrait, this.portraitPosition);
			}
		}
		
		public void Recalculate()
		{
			this.markUpdate = true;
		}
		
		
		/*
		============================================================================
		Show GUI functions
		============================================================================
		*/
		public override void ShowBefore()
		{
			if(this.box != null && this.portrait != null && this.portrait.image != null && 
				this.portraitPosition != null && PortraitBoxPosition.Behind.Equals(this.portraitPosition.boxPosition))
			{
				this.portraitPosition.Show(this.portrait, this.box.windowRect);
			}
		}
		
		public override void ShowAfter()
		{
			if(this.box != null && this.portrait != null && this.portrait.image != null && 
				this.portraitPosition != null && PortraitBoxPosition.InFront.Equals(this.portraitPosition.boxPosition))
			{
				this.portraitPosition.Show(this.portrait, this.box.windowRect);
			}
		}

		public override void ShowWindow()
		{
			if(this.box.doFlash)
			{
				GUI.color = this.box.flashColor;
			}
			else
			{
				GUI.color = this.box.color;
			}
			
			GUIStyle textStyle = new GUIStyle(GUI.skin.label);
			textStyle.wordWrap = false;
			
			if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
			{
				GUI.skin.horizontalScrollbar = GUIStyle.none;
				this.scroll = GUI.BeginScrollView(this.contentBounds, this.scroll, this.scrollRect);
				GUI.BeginGroup(this.scrollRect);
			}
			else
			{
				GUI.BeginGroup(this.contentBounds);
			}
			
			// within box potrait
			if(this.portrait != null && this.portrait.image != null && 
				this.portraitPosition != null && PortraitBoxPosition.Within.Equals(this.portraitPosition.boxPosition))
			{
				this.portraitPosition.Show(this.portrait, this.box.windowRect);
			}
			
			// display content
			for(int i=0; i<this.content.Count; i++)
			{
				// no flash > reset color
				this.box.SetGUIColor(this.content[i].setting.noFlash);
				
				// show
				this.content[i].Show(textStyle);
				this.box.SetGUIColor(false);
			}
			
			GUI.EndGroup();
			if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
			{
				GUI.EndScrollView();
			}
		}
	}
}
