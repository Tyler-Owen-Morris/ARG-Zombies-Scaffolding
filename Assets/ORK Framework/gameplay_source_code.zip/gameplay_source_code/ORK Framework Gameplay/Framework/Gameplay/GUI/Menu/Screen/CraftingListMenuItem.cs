
using UnityEngine;
using System.Collections.Generic;
using ORKFramework;
using ORKFramework.Menu.Parts;

namespace ORKFramework.Menu
{
	public class CraftingListMenuItem : BaseData
	{
		[ORKEditorHelp("Button Type", "Select the type of the button:\n" +
			"- Back: Closes the crafting list menu without doing anything ('Back' button).\n" +
			"- Cancel: Closes the crafting list menu without doing anything ('Cancel' button).\n" +
			"- Create: Uses the items added to the crafting list and tries to " +
			"create a new item using the available crafting recipes.\n" +
			"- Clear: Removes all items from the crafting list.\n" +
			"- Items: Shows all items in the crafting list as individual buttons. " +
			"Clicking on a button will remove them from the list.", "")]
		public CraftingListMenuItemType type = CraftingListMenuItemType.Back;
		
		
		// use key
		[ORKEditorHelp("Use Key", "Use an input key to call the action of this button (e.g. creating a new item).", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout(new string[] {"type", "type"}, 
			new System.Object[] {CraftingListMenuItemType.Create, CraftingListMenuItemType.Clear}, 
			needed=Needed.One, endCheckGroup=true, 
			setDefault=true, defaultValue=false)]
		public bool useKey = false;
		
		[ORKEditorHelp("Call Key", "Select the input key to use this sub menu item.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("useKey", true, endCheckGroup=true)]
		public int keyID = 0;
		
		
		// own content
		[ORKEditorHelp("Own Button Content", "Override the button's default name, description and icon.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout(new string[] {"type", "type"}, 
			new System.Object[] {CraftingListMenuItemType.Back, CraftingListMenuItemType.Cancel}, 
			needed=Needed.One, endCheckGroup=true)]
		public bool ownContent = false;
		
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language, foldoutDefault=false)]
		[ORKEditorLayout(new string[] {"ownContent", "type", "type"}, 
			new System.Object[] {true, CraftingListMenuItemType.Create, CraftingListMenuItemType.Clear}, 
			needed=Needed.One, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public LanguageInfo[] button;
		
		
		// item content layout
		[ORKEditorHelp("As Buttons", "The crafting list items will be displayed as buttons.", "")]
		[ORKEditorInfo(labelText="Item Content Layout")]
		[ORKEditorLayout("type", CraftingListMenuItemType.Items)]
		public bool isButtonList = true;
		
		[ORKEditorLayout(endCheckGroup=true)]
		public TitleContentLayout contentLayout = new TitleContentLayout(
			ContentLayoutType.None, ContentLayoutType.Both, ContentLayoutInfoType.Info);
		
		public CraftingListMenuItem()
		{
			
		}
	}
}
