
using System.Collections.Generic;
using UnityEngine;
using ORKFramework.Menu.Parts;
using ORKFramework.Events;

namespace ORKFramework.Menu
{
	public class MenuScreen : BaseIndexData, IChoiceSimple, IEventStarter
	{
		// base settings
		[ORKEditorHelp("Name", "The name of this menu screen.", "")]
		[ORKEditorInfo("Base Settings", "Set the name and base settings of this menu screen.", "", 
			expandWidth=true)]
		public string name = "";
		
		
		// screen settings
		[ORKEditorHelp("Remember Selection", "Remember the last selections made in the menu screen.\n" +
			"If disabled, the selection highlights the first menu item in the list.", "")]
		[ORKEditorInfo(separator=true, labelText="Settings")]
		public bool rememberSelection = false;
		
		[ORKEditorHelp("Block Control", "The player control is blocked while this menu screen is displayed.", "")]
		public bool blockControl = true;
		
		[ORKEditorHelp("Single Screen", "This menu screen can only be displayed alone.\n" +
			"All other menu screens will automatically close if this menu screen is opened.\n" +
			"If disabled, this menu screen can be displayed with other menu screens.", "")]
		public bool singleScreen = true;
		
		[ORKEditorHelp("2nd Call Closes", "Calling/opening this menu screen when it's already open will close it.\n" +
			"I.e. you can open and close the menu screen with a single button.", "")]
		public bool closeOn2nd = true;
		
		[ORKEditorHelp("Close Only Focused", "This menu screen will only close on a 2nd call when it's focused.\n" +
			"I.e. if you're using another menu screen with this in the background, you'll show this menu screen.", "")]
		[ORKEditorLayout("closeOn2nd", true, endCheckGroup=true)]
		public bool close2ndFocused = false;
		
		[ORKEditorHelp("Close Focus Lost", "This menu screen will close when losing the focus.", "")]
		public bool closeFocusLost = false;
		
		
		// pause
		[ORKEditorHelp("Pause Game", "The game will be paused while this menu screen is opened.", "")]
		[ORKEditorInfo(separator=true, labelText="Pause Settings")]
		public bool pauseGame = false;
		
		[ORKEditorHelp("Pause Time", "The game time (play time) will pause when the game is paused.", "")]
		[ORKEditorLayout("pauseGame", true)]
		public bool pauseTime = false;
		
		[ORKEditorHelp("Freeze Pause", "The game freezes in pause, i.e. animations, movements, etc. will stop.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool freezePause = false;
		
		
		// call key
		[ORKEditorHelp("Use Call Key", "This menu screen can be called directly by an input key.", "")]
		[ORKEditorInfo(separator=true, labelText="Input Key Call")]
		public bool useKey = false;
		
		[ORKEditorHelp("Input Key", "Select the input key used to call this menu screen.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("useKey", true)]
		public int keyID = 0;
		
		// requirement
		[ORKEditorHelp("Use Requirement", "A defined requirement must be valid to enable calling this menu screen by an input key.", "")]
		public bool useReq = false;
		
		[ORKEditorHelp("Requirement", "Select the requirement that must be valid.", "")]
		[ORKEditorInfo(ORKDataType.Requirement)]
		[ORKEditorLayout("useReq", true, endCheckGroup=true, endGroups=2)]
		public int reqID = 0;
		
		
		// change combatant
		[ORKEditorHelp("Alive User", "When opening this menu screen and the user is dead, " +
			"the first alive member of the group will be used.", "")]
		[ORKEditorInfo(separator=true, labelText="Combatant Settings")]
		public bool aliveUser = false;
		
		[ORKEditorHelp("Allow Change", "This screen allows changing the combatant.\n" +
			"If disabled, the combatant of this menu screen is fixed to a previous selection " +
			"(by default the player combatant, i.e. the leader of the player group).", "")]
		public bool allowComChange = false;
		
		[ORKEditorHelp("Only Battle Group", "Only the battle group is available for changing the combatant.\n" +
			"If disabled, you can browse through the whole player group.", "")]
		[ORKEditorLayout("allowComChange", true)]
		public bool changeOnlyBattle = true;
		
		[ORKEditorHelp("Previous Key", "Select the key to change to the previous combatant.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int prevKeyID = 0;
		
		[ORKEditorHelp("Next Key", "Select the key to change to the next combatant.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout(endCheckGroup=true)]
		public int nextKeyID = 0;
		
		
		// change part
		[ORKEditorHelp("Allow Change", "This screen allows changing the active menu part.\n" +
			"You can only change to controlable menu parts.", "")]
		[ORKEditorInfo(separator=true, labelText="Menu Part Change Keys")]
		public bool allowPartChange = false;
		
		[ORKEditorHelp("Previous Key", "Select the key to change to the previous menu part.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("allowPartChange", true)]
		public int prevPartKeyID = 0;
		
		[ORKEditorHelp("Next Key", "Select the key to change to the next menu part.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout(endCheckGroup=true)]
		public int nextPartKeyID = 0;
		
		
		// bg image
		[ORKEditorHelp("No General Background", "This menu screen wont display the general background images.\n" +
			"If disabled, the general background will be displayed.\n" +
			"The general background is defined in the Menu Settings.", "")]
		[ORKEditorInfo(separator=true, labelText="Background Image")]
		public bool noGeneralBG = false;
		
		[ORKEditorHelp("Own Background", "Override the default menu background image settings.", "")]
		public bool ownBG = false;
		
		[ORKEditorLayout("ownBG", true, endCheckGroup=true, autoInit=true)]
		[ORKEditorArray(false, "Add Background", "Adds a background image.", "", 
			"Remove", "Removes this background image.", "", foldout=true, 
			foldoutText=new string[] {"Background Image", "Define the background image that will be displayed.", ""})]
		public BackgroundImage[] background;
		
		
		// audio settings
		[ORKEditorHelp("Open Clip", "Select the audio clip that will be played when opening this menu.\n" +
			"Select none to not play an audio clip.", "")]
		[ORKEditorInfo(separator=true, labelText="Audio Settings")]
		public AudioClip openClip;
		
		[ORKEditorHelp("Volume (Open)", "The volume used to play the open clip (between 0 and 1).", "")]
		[ORKEditorLayout("openClip", null, elseCheckGroup=true, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float openVolume = 1;
		
		[ORKEditorHelp("Close Clip", "Select the audio clip that will be played when closing this menu.\n" +
			"Select none to not play an audio clip.", "")]
		public AudioClip closeClip;
		
		[ORKEditorHelp("Volume (Close)", "The volume used to play the close clip (between 0 and 1).", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("closeClip", null, elseCheckGroup=true, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float closeVolume = 1;
		
		
		// music settings
		[ORKEditorHelp("Own Music", "This menu screen plays a different music clip while opened.", "")]
		[ORKEditorInfo("Music Settings", "A menu screen can play a different music clip while opened.\n" +
			"The currently playing clip will resume playing after the menu screen has been closed.", "")]
		public bool ownMusic = false;
		
		[ORKEditorInfo(separator=true, labelText="Play Music")]
		[ORKEditorLayout("ownMusic", true, autoInit=true)]
		public PlayMusic playMusic;
		
		[ORKEditorInfo(endFoldout=true, separator=true, labelText="Resume Music")]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public PlayMusicStored playStored;
		
		
		// close screens when opening
		[ORKEditorHelp("Close Screen (Opening)", "Select the menu screen that will be closed if this menu screen is opened.\n" +
			"Please note that this doesn't prevent the selected menu screen from being opened again while this screen displayed.", "")]
		[ORKEditorInfo("Close Screens (Opening)", "Closes selected menu screens when this screen is opened.\n" +
			"Only available when not using 'Single Screen' mode.", "", endFoldout=true, 
			isPopup=true, popupType=ORKDataType.MenuScreen, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Menu Screen", "Adds a menu screen that will be closed when this menu screen is opened.", "",
			"Remove", "Removes the menu screen.", "", isHorizontal=true)]
		[ORKEditorLayout("singleScreen", false, endCheckGroup=true, autoInit=true)]
		public int[] closeScreensOpening;
		
		
		// close screens when closing
		[ORKEditorHelp("Close Screen (Closing)", "Select the menu screen that will be closed if this menu screen is closed.", "")]
		[ORKEditorInfo("Close Screens (Closing)", "Closes selected menu screens when this screen is closed.\n" +
			"Only available when not using 'Single Screen' mode.", "", endFoldout=true, 
			isPopup=true, popupType=ORKDataType.MenuScreen, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Menu Screen", "Adds a menu screen that will be closed when this menu screen is closed.", "",
			"Remove", "Removes the menu screen.", "", isHorizontal=true)]
		[ORKEditorLayout("singleScreen", false, endCheckGroup=true, autoInit=true)]
		public int[] closeScreensClosing;
		
		
		
		// parts
		[ORKEditorInfo(separator=true, callbackBefore="button:parts")]
		[ORKEditorArray(foldout=true, isMove=true, isRemove=true, 
			removeText=new string[] {"Remove", "Removes this menu part.", ""})]
		public BaseMenuPart[] part = new BaseMenuPart[0];
		
		
		// ingame
		private Combatant combatant;
		
		private MenuStatus menuStatus = MenuStatus.Closed;
		
		private IEventStarter starter;
		
		private MenuScreenItem callOnClose;
		
		private GUIBox[] bgBox;
		
		public MenuScreen()
		{
			
		}
		
		public MenuScreen(string name)
		{
			this.name = name;
		}
		
		public MenuStatus Status
		{
			get{ return this.menuStatus;}
		}
		
		public Combatant Combatant
		{
			get{ return this.combatant;}
			set
			{
				Combatant old = this.combatant;
				this.combatant = value;
				
				if(!MenuStatus.Closed.Equals(this.menuStatus))
				{
					for(int i=0; i<this.part.Length; i++)
					{
						this.part[i].ChangeCombatant(old);
					}
					for(int i=0; i<this.part.Length; i++)
					{
						if(this.part[i].ShowFirstDescription())
						{
							break;
						}
					}
				}
			}
		}
		
		public void Clear()
		{
			this.starter = null;
			this.callOnClose = null;
		}
		
		public bool IsFocused()
		{
			for(int i=0; i<this.part.Length; i++)
			{
				if(this.part[i].IsFocused())
				{
					return true;
				}
			}
			return false;
		}
		
		public bool RememberSelection
		{
			get{ return this.rememberSelection;}
		}
		
		
		/*
		============================================================================
		Key functions
		============================================================================
		*/
		public void Tick()
		{
			if(MenuStatus.Opening.Equals(this.menuStatus))
			{
				bool openend = true;
				for(int i=0; i<this.part.Length; i++)
				{
					if(!this.part[i].IsOpened)
					{
						openend = false;
						break;
					}
				}
				if(openend)
				{
					this.menuStatus = MenuStatus.Opened;
				}
			}
			else if(MenuStatus.Opened.Equals(this.menuStatus))
			{
				// check call key
				if(this.useKey && ORK.InputKeys.Get(this.keyID).GetButton() && 
					(!this.useReq || ORK.Requirements.Get(this.reqID).Check()))
				{
					if(this.closeOn2nd && 
						(!this.close2ndFocused || this.IsFocused()))
					{
						this.Close();
					}
					else
					{
						this.Show();
					}
				}
				// combatant change
				else if(this.allowComChange)
				{
					// previous combatant
					if(ORK.InputKeys.Get(this.prevKeyID).GetButton())
					{
						this.Combatant = ORK.Game.ActiveGroup.GetOffset(this.combatant, -1, this.changeOnlyBattle);
					}
					// next combatant
					else if(ORK.InputKeys.Get(this.nextKeyID).GetButton())
					{
						this.Combatant = ORK.Game.ActiveGroup.GetOffset(this.combatant, 1, this.changeOnlyBattle);
					}
				}
				// part change
				else if(this.allowPartChange)
				{
					// previous part
					if(ORK.InputKeys.Get(this.prevPartKeyID).GetButton())
					{
						this.ChangeActivePart(-1);
					}
					// next part
					else if(ORK.InputKeys.Get(this.nextPartKeyID).GetButton())
					{
						this.ChangeActivePart(1);
					}
				}
				
				if(this.closeFocusLost && !this.IsFocused())
				{
					this.Close();
				}
			}
			else if(MenuStatus.Closing.Equals(this.menuStatus))
			{
				bool closed = true;
				for(int i=0; i<this.part.Length; i++)
				{
					if(!this.part[i].IsClosed)
					{
						closed = false;
						break;
					}
				}
				if(this.bgBox != null)
				{
					for(int i=0; i<this.bgBox.Length; i++)
					{
						if(this.bgBox[i] != null)
						{
							if(this.bgBox[i].FadedOut)
							{
								this.bgBox[i] = null;
							}
							else
							{
								closed = false;
							}
						}
					}
				}
				if(closed)
				{
					this.Closed();
				}
			}
			else if(MenuStatus.Closed.Equals(this.menuStatus))
			{
				// check call key
				if(this.useKey && ORK.InputKeys.Get(this.keyID).GetButton() && 
					(!this.useReq || ORK.Requirements.Get(this.reqID).Check()))
				{
					this.combatant = ORK.Game.ActiveGroup.Leader;
					this.Show();
				}
			}
		}
		
		public void ChangeActivePart(int change)
		{
			// find active part
			int activeIndex = -1;
			for(int i=0; i<this.part.Length; i++)
			{
				if(this.part[i].IsFocused())
				{
					activeIndex = i;
					break;
				}
			}
			
			if(activeIndex != -1)
			{
				int newIndex = activeIndex;
				
				do
				{
					newIndex += change;
					if(newIndex < 0)
					{
						newIndex = this.part.Length - 1;
					}
					else if(newIndex >= this.part.Length)
					{
						newIndex = 0;
					}
					
					if(this.part[newIndex].Controlable)
					{
						this.part[newIndex].FocusFirst();
						activeIndex = newIndex;
					}
				} while(newIndex != activeIndex);
			}
		}
		
		
		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public void Show(IEventStarter starter)
		{
			if(!ORK.GUI.FocusBlocked)
			{
				this.starter = starter;
				this.Show();
			}
		}
		
		public void Show()
		{
			if(!ORK.GUI.FocusBlocked)
			{
				if(MenuStatus.Opened.Equals(this.menuStatus))
				{
					for(int i=0; i<this.part.Length; i++)
					{
						if(this.part[i].FocusFirst())
						{
							break;
						}
					}
				}
				else if(!MenuStatus.Closing.Equals(this.menuStatus) && 
					ORK.Menu.CheckSingleScreen(this))
				{
					// play opening audio
					if(this.openClip != null)
					{
						ORK.Audio.PlayOneShot(this.openClip, this.openVolume * ORK.Game.SoundVolume);
					}
					
					// music
					if(this.ownMusic)
					{
						ORK.Music.StoreCurrent(true);
						this.playMusic.Play();
					}
					
					if(this.blockControl)
					{
						ORK.Control.SetMenuBlock(1);
					}
					if(this.pauseGame)
					{
						ORK.Game.PauseGame(true, this.pauseTime, this.freezePause);
					}
					
					if(this.combatant == null)
					{
						this.combatant = ORK.Game.ActiveGroup.Leader;
					}
					
					if(this.aliveUser && this.combatant != null && this.combatant.Dead)
					{
						this.combatant = this.combatant.Group.GetFirstAlive();
					}
					
					if(this.noGeneralBG)
					{
						ORK.Menu.CloseGeneralMenuBG();
					}
					else
					{
						ORK.Menu.ShowGeneralMenuBG();
					}
					
					if(this.ownBG && this.background != null && this.background.Length > 0)
					{
						this.bgBox = new GUIBox[this.background.Length];
						for(int i=0; i<this.bgBox.Length; i++)
						{
							this.bgBox[i] = this.background[i].Init();
						}
					}
					else if(!this.ownBG && ORK.MenuSettings.defaultMenuBG.Length > 0)
					{
						this.bgBox = new GUIBox[ORK.MenuSettings.defaultMenuBG.Length];
						for(int i=0; i<this.bgBox.Length; i++)
						{
							this.bgBox[i] = ORK.MenuSettings.defaultMenuBG[i].Init();
						}
					}
					
					for(int i=0; i<this.part.Length; i++)
					{
						this.part[i].Screen = this;
					}
					for(int i=0; i<this.part.Length; i++)
					{
						this.part[i].Show(this);
					}
					
					for(int i=0; i<this.part.Length; i++)
					{
						if(this.part[i].ShowFirstDescription())
						{
							break;
						}
					}
					this.menuStatus = MenuStatus.Opening;
					ORK.Menu.AddScreen(this);
				}
			}
		}
		
		public void CloseImmediate()
		{
			this.Clear();
			if(!MenuStatus.Closed.Equals(this.menuStatus))
			{
				this.CloseScreensClosing();
				
				// play closing audio (if not alraedy closing)
				if(!MenuStatus.Closing.Equals(this.menuStatus) && 
					this.closeClip != null)
				{
					ORK.Audio.PlayOneShot(this.closeClip, this.closeVolume * ORK.Game.SoundVolume);
				}
				// music
				if(this.ownMusic)
				{
					this.playStored.Play(true);
				}
				
				// immediately close all parts
				for(int i=0; i<this.part.Length; i++)
				{
					this.part[i].CloseImmediate();
				}
				if(this.bgBox != null)
				{
					for(int i=0; i<this.bgBox.Length; i++)
					{
						if(this.bgBox[i] != null)
						{
							this.bgBox[i].SetOutDone();
							this.bgBox[i] = null;
						}
					}
				}
				ORK.Menu.RemoveScreen(this);
				// release menu block
				if(this.blockControl)
				{
					ORK.Control.SetMenuBlock(-1);
				}
				if(this.pauseGame)
				{
					ORK.Game.PauseGame(false, this.pauseTime, this.freezePause);
				}
			}
			this.menuStatus = MenuStatus.Closed;
		}
		
		public void Close(MenuScreenItem call)
		{
			this.callOnClose = call;
			this.Close();
		}
		
		public void Close()
		{
			if(!ORK.GUI.FocusBlocked && 
				!MenuStatus.Closing.Equals(this.menuStatus) && 
				!MenuStatus.Closed.Equals(this.menuStatus))
			{
				this.CloseScreensClosing();
				
				// play closing audio
				if(this.closeClip != null)
				{
					ORK.Audio.PlayOneShot(this.closeClip, this.closeVolume * ORK.Game.SoundVolume);
				}
				// music
				if(this.ownMusic)
				{
					this.playStored.Play(true);
				}
				// close all parts
				for(int i=this.part.Length - 1; i>=0; i--)
				{
					this.part[i].Close();
				}
				if(this.bgBox != null)
				{
					for(int i=this.bgBox.Length - 1; i>=0; i--)
					{
						if(this.bgBox[i] != null)
						{
							this.bgBox[i].InitOut();
						}
					}
				}
				this.menuStatus = MenuStatus.Closing;
			}
		}
		
		private void Closed()
		{
			ORK.Menu.RemoveScreen(this);
			this.menuStatus = MenuStatus.Closed;
			
			if(this.callOnClose != null)
			{
				this.callOnClose.Selected(this);
				this.callOnClose = null;
			}
			else if(ComponentHelper.IsAlive(this.starter))
			{
				this.starter.EventEnded();
				this.starter = null;
			}
			
			if(this.blockControl)
			{
				ORK.Control.SetMenuBlock(-1);
			}
			if(this.pauseGame)
			{
				ORK.Game.PauseGame(false, this.pauseTime, this.freezePause);
			}
		}
		
		public void CloseScreensOpening()
		{
			if(!this.singleScreen && 
				this.closeScreensOpening != null && 
				this.closeScreensOpening.Length > 0)
			{
				for(int i=0; i<this.closeScreensOpening.Length; i++)
				{
					MenuScreen screen = ORK.MenuScreens.Get(this.closeScreensOpening[i]);
					screen.Clear();
					screen.Close();
				}
			}
		}
		
		public void CloseScreensClosing()
		{
			if(!this.singleScreen && 
				this.closeScreensClosing != null && 
				this.closeScreensClosing.Length > 0)
			{
				for(int i=0; i<this.closeScreensClosing.Length; i++)
				{
					MenuScreen screen = ORK.MenuScreens.Get(this.closeScreensClosing[i]);
					screen.Clear();
					screen.Close();
				}
			}
		}
		
		
		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public void ShowDescription(string desc, string name, IContentSimple content)
		{
			if(!MenuStatus.Closing.Equals(this.menuStatus))
			{
				for(int i=0; i<this.part.Length; i++)
				{
					if(this.part[i] is DescriptionMenuPart)
					{
						((DescriptionMenuPart)this.part[i]).Show(desc, name, content);
					}
				}
			}
		}
		
		
		/*
		============================================================================
		Event functions
		============================================================================
		*/
		public void EventEnded()
		{
			this.Show();
		}

		public void DontDestroy()
		{
			
		}

		public GameObject GameObject
		{
			get { return null;}
		}
	}
}
