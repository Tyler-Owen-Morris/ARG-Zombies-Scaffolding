
using UnityEngine;
using ORKFramework.Display;
using ORKFramework.Menu;
using System.Collections.Generic;

namespace ORKFramework
{
	public class HUDStatus : HUDElement
	{
		[ORKEditorHelp("Type", "Select the type of the HUD element:\n" +
			"- Information: Displays information of a combatant (name, class, level, etc.).\n" +
			"- Faction: Displays the name and description of a combatant's faction and " +
			"sympathy towards the player - faction information isn't displayed for the player.\n" +
			"- Status Value: Displays the value of a combatant's status value.\n" +
			"- Status Effect: Displays a combatant's status effects.\n" +
			"- Attack Attribute: Displays a combatant's attack attributes values.\n" +
			"- Defence Attribute: Displays a combatant's defence attributes values.\n" +
			"- Defence Attribute ID: Desplays a combatant's defence attributes.\n" +
			"- Timebar: Displays the timebar or used timebar value of a combatant (only in 'Active Time' type battles).\n" +
			"- Cast Time: Displays the cast time of a combatant currently casting an ability (only while casting).\n" +
			"- Inventory Space: Displays the combatant's inventory space (current and maximum).\n" +
			"- Portrait: Displays a portrait of the combatant (The portrait is displayed within the box/button).\n" +
			"- Shortcut: Displays the assigned shortcuts of the combatant.\n" +
			"- Equipment: Displays a combatant's equipment parts and equipment.\n" +
			"- Delay Time: Displays a combatant's delay time (only while the time is running).", "")]
		public HUDStatusType type = HUDStatusType.Information;
		
		
		// combatant origin
		[ORKEditorHelp("Combatant Origin", "Select which combatant will be used:\n" +
			"- User: The combatant of the HUD is used to display this HUD.\n" +
			"- Group Target: A group target of the combatant's group.\n" +
			"- Individual Target: An individual target of the combatant.\n" +
			"- Last Target: The last target the combatant attacked or used an ability/item on.", "")]
		[ORKEditorLayout("type", HUDStatusType.Shortcut, elseCheckGroup=true, 
			setDefault=true, defaultValue=HUDStatusCombatantOrigin.User)]
		public HUDStatusCombatantOrigin combatantOrigin = HUDStatusCombatantOrigin.User;
		
		[ORKEditorHelp("Target Index", "The index of the group/individual target.\n" +
			"Nothing will be displayed if the index exceeds the available targets or no target is selected.", "")]
		[ORKEditorLimit(0, false)]
		[ORKEditorLayout(new string[] {"combatantOrigin", "combatantOrigin"}, 
			new System.Object[] {HUDStatusCombatantOrigin.GroupTarget, HUDStatusCombatantOrigin.IndividualTarget}, 
			needed=Needed.One, endCheckGroup=true, endGroups=2)]
		public int originTargetIndex = 0;
		
		
		// information
		[ORKEditorInfo(separatorForce=true, label=new string[] {
			"%n = name, %d = description, %i = icon, % = level", 
			"%cn = class name, %cd = class description, %ci = class icon, %c = class level"
		})]
		[ORKEditorLayout("type", HUDStatusType.Information, endCheckGroup=true, autoInit=true)]
		public StatusTextHUD information;
		
		
		// faction
		[ORKEditorLayout("type", HUDStatusType.Faction, endCheckGroup=true, autoInit=true)]
		public FactionTextHUD faction;
		
		
		// status value
		[ORKEditorLayout("type", HUDStatusType.StatusValue, endCheckGroup=true, autoInit=true)]
		public StatusValueHUD status;
		
		
		// status effect
		[ORKEditorLayout("type", HUDStatusType.StatusEffect, endCheckGroup=true, autoInit=true)]
		public EffectTextHUD effect;
		
		
		// attack attribute
		[ORKEditorLayout("type", HUDStatusType.AttackAttribute, endCheckGroup=true, autoInit=true)]
		public AtkAttrHUD atkAttr;
		
		
		// defence attribute
		[ORKEditorLayout("type", HUDStatusType.DefenceAttribute, endCheckGroup=true, autoInit=true)]
		public DefAttrHUD defAttr;
		
		[ORKEditorLayout("type", HUDStatusType.DefenceAttributeID, endCheckGroup=true, autoInit=true)]
		public DefIDHUD defID;
		
		
		// timebar
		[ORKEditorLayout("type", HUDStatusType.Timebar, endCheckGroup=true, autoInit=true)]
		public TimebarHUD timebar;
		
		
		// cast time
		[ORKEditorLayout("type", HUDStatusType.CastTime, endCheckGroup=true, autoInit=true)]
		public CastTimeHUD castTime;
		
		
		// inventory limit
		[ORKEditorLayout("type", HUDStatusType.InventorySpace, endCheckGroup=true, autoInit=true)]
		public InventorySpaceHUD invSpace;
		
		
		// portrait
		[ORKEditorLayout("type", HUDStatusType.Portrait, endCheckGroup=true, autoInit=true)]
		public PortraitHUD portrait;
		
		
		// portrait
		[ORKEditorLayout("type", HUDStatusType.Shortcut, endCheckGroup=true, autoInit=true)]
		public ShortcutHUD shortcut;
		
		
		// equipment
		[ORKEditorLayout("type", HUDStatusType.Equipment, endCheckGroup=true, autoInit=true)]
		public EquipmentHUD equipment;
		
		
		// delay time
		[ORKEditorLayout("type", HUDStatusType.DelayTime, endCheckGroup=true, autoInit=true)]
		public DelayTimeHUD delayTime;
		
		
		
		// requirements
		[ORKEditorHelp("Use Requirements", "Use status requirements and game variable conditions.", "")]
		[ORKEditorInfo("Display Requirements", "Displaying this HUD element can depend on status requirements and " +
			"game variable conditions.\n" +
			"If the requirements aren't met, the element wont be displayed.", "")]
		public bool useRequirements = false;
		
		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout("useRequirements", true, endCheckGroup=true, autoInit=true)]
		public SimpleCombatantRequirement requirement;
		
		
		
		// click action
		[ORKEditorHelp("Click Type", "Clicking/touching this HUD element will trigger:\n" +
			"- None: Nothing happens.\n" +
			"- Menu Screen: Calls a selected menu screen with " +
			"the combatant as user (only player group members).\n" +
			"- Change Menu User: Changes the menu user to the combatant " +
			"in all opened menu screens and shops (only player group members)." +
			"- Change Player: Changes the player combatant (i.e. leader of the player group) " +
			"to the combatant (only player group members).\n" +
			"- Select Target: Selects the combatant as a target in battle (like clicking on the combatant's game object).", "")]
		[ORKEditorInfo(separator=true, labelText="Click Action")]
		public HUDCombatantClickType clickType = HUDCombatantClickType.None;
		
		// menu screen
		[ORKEditorHelp("Menu Screen", "Select the menu screen that will be called.", "")]
		[ORKEditorInfo(ORKDataType.MenuScreen)]
		[ORKEditorLayout("clickType", HUDCombatantClickType.MenuScreen)]
		public int callScreenID = 0;
		
		[ORKEditorHelp("Close Screen", "The screen will be closed if it is already opened.\n" +
			"If 'Allow User Change' is enabled, the screen will only be closed when clicking on " +
			"the combatant that is the current menu user.", "")]
		public bool closeScreen = false;
		
		[ORKEditorHelp("Allow User Change", "The screen will only be closed when clicking on " +
			"the combatant that is the current menu user.", "")]
		[ORKEditorLayout("closeScreen", true, endCheckGroup=true)]
		public bool closeScreenChange = true;
		
		[ORKEditorHelp("Use Requirement", "A defined requirement must be valid to enable calling the menu screen.", "")]
		public bool screenUseReq = false;
		
		[ORKEditorHelp("Requirement", "Select the requirement that must be valid.", "")]
		[ORKEditorInfo(ORKDataType.Requirement)]
		[ORKEditorLayout("screenUseReq", true, endCheckGroup=true, endGroups=2)]
		public int screenReqID = 0;
		
		// click sound
		[ORKEditorHelp("Click Clip", "Select the audio clip that will be played when clicking this HUD element.\n" +
			"Select none to not play an audio clip.", "")]
		[ORKEditorInfo(separator=true)]
		public AudioClip clickClip;
		
		[ORKEditorHelp("Volume", "The volume used to play the click clip (between 0 and 1).", "")]
		[ORKEditorLayout("clickClip", null, elseCheckGroup=true, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float clickVolume = 1;
		
		
		public HUDStatus()
		{
			
		}
		
		public override void CreateLabels(out List<BaseLabel> label, Rect displayBounds, 
			Combatant combatant)
		{
			this.CreateLabels(out label, displayBounds, combatant, false);
		}
		
		public void CreateLabels(out List<BaseLabel> label, Rect displayBounds, 
			Combatant combatant, bool isBestiary)
		{
			label = null;
			
			if(!HUDStatusType.Shortcut.Equals(this.type) && 
				combatant != null)
			{
				if(HUDStatusCombatantOrigin.GroupTarget.Equals(this.combatantOrigin))
				{
					combatant = combatant.Group.SelectedTargets[this.originTargetIndex];
				}
				else if(HUDStatusCombatantOrigin.IndividualTarget.Equals(this.combatantOrigin))
				{
					combatant = combatant.SelectedTargets[this.originTargetIndex];
				}
				else if(HUDStatusCombatantOrigin.LastTarget.Equals(this.combatantOrigin))
				{
					combatant = combatant.LastTargets.Count > 0 ? combatant.LastTargets[0] : null;
				}
			}
			
			
			if(!this.useRequirements || this.requirement.Check(combatant))
			{
				if(combatant != null)
				{
					if(HUDStatusType.Information.Equals(this.type))
					{
						label = new MultiContent(
							TextHelper.ReplaceSpecials(this.information.text[ORK.Game.Language].
								Replace("%n", combatant.GetName()).
								Replace("%d", combatant.GetDescription()).
								Replace("%i", combatant.GetIconTextCode()).
								Replace("%cn", ORK.Classes.GetName(combatant.ClassID)).
								Replace("%cd", ORK.Classes.GetDescription(combatant.ClassID)).
								Replace("%ci", TextCode.ClassIcon + combatant.ClassID + "#").
								Replace("%c", combatant.ClassLevel.ToString()).
								Replace("%", combatant.Level.ToString())), 
							null, null, displayBounds, this.information.lineSpacing, this.information.alignment, 
							this.information.vAlignment, BoxHeightAdjustment.Auto, false, this.information.textFormat).label;
					}
					else if(HUDStatusType.Faction.Equals(this.type))
					{
						this.faction.CreateLabels(out label, combatant, displayBounds);
					}
					else if(HUDStatusType.StatusValue.Equals(this.type))
					{
						this.status.CreateLabels(out label, combatant, isBestiary, displayBounds);
					}
					else if(HUDStatusType.StatusEffect.Equals(this.type))
					{
						this.effect.CreateLabels(out label, combatant, displayBounds);
					}
					else if(HUDStatusType.AttackAttribute.Equals(this.type))
					{
						this.atkAttr.CreateLabels(out label, combatant, isBestiary, displayBounds);
					}
					else if(HUDStatusType.DefenceAttribute.Equals(this.type))
					{
						this.defAttr.CreateLabels(out label, combatant, isBestiary, displayBounds);
					}
					else if(HUDStatusType.DefenceAttributeID.Equals(this.type))
					{
						this.defID.CreateLabels(out label, combatant, isBestiary, displayBounds);
					}
					else if(HUDStatusType.Timebar.Equals(this.type))
					{
						if(ORK.Battle.IsActiveTime() && ORK.Battle.IsBattleRunning())
						{
							this.timebar.CreateLabels(out label, combatant, displayBounds);
						}
					}
					else if(HUDStatusType.CastTime.Equals(this.type))
					{
						if(combatant.Actions.IsCastingAbility)
						{
							this.castTime.CreateLabels(out label, combatant, displayBounds);
						}
					}
					else if(HUDStatusType.InventorySpace.Equals(this.type))
					{
						this.invSpace.CreateLabels(out label, combatant, displayBounds);
					}
					else if(HUDStatusType.Portrait.Equals(this.type))
					{
						Portrait p = combatant.GetPortrait(this.portrait.portraitTypeID);
						if(p != null && p.image != null)
						{
							this.portrait.CreateLabels(out label, combatant, displayBounds, p.image);
						}
					}
					else if(HUDStatusType.Shortcut.Equals(this.type))
					{
						this.shortcut.CreateLabels(out label, combatant, displayBounds);
					}
					else if(HUDStatusType.Equipment.Equals(this.type))
					{
						this.equipment.CreateLabels(out label, combatant, isBestiary, displayBounds);
					}
					else if(HUDStatusType.DelayTime.Equals(this.type))
					{
						if(combatant.DelayTime > 0)
						{
							this.delayTime.CreateLabels(out label, combatant, displayBounds);
						}
					}
				}
			}
		}
		
		public void CreateLabelsEditor(out List<BaseLabel> label, Rect displayBounds, 
			Combatant combatant, bool isBestiary)
		{
			this.CreateLabels(out label, displayBounds, combatant, isBestiary);
		}
		
		
		/*
		============================================================================
		Drag and drop functions
		============================================================================
		*/
		public override ChoiceContent GetDragOnPosition(Combatant combatant, Vector2 position)
		{
			if(combatant != null && HUDStatusType.Shortcut.Equals(this.type))
			{
				return this.shortcut.GetDragOnPosition(combatant, position, this.bounds);
			}
			return null;
		}
		
		public override bool CheckDrop(Combatant combatant, DragInfo drag, Vector2 position)
		{
			if(!HUDStatusType.Shortcut.Equals(this.type) && 
				combatant != null)
			{
				if(HUDStatusCombatantOrigin.GroupTarget.Equals(this.combatantOrigin))
				{
					combatant = combatant.Group.SelectedTargets[this.originTargetIndex];
				}
				else if(HUDStatusCombatantOrigin.IndividualTarget.Equals(this.combatantOrigin))
				{
					combatant = combatant.SelectedTargets[this.originTargetIndex];
				}
				else if(HUDStatusCombatantOrigin.LastTarget.Equals(this.combatantOrigin))
				{
					combatant = combatant.LastTargets.Count > 0 ? combatant.LastTargets[0] : null;
				}
			}
			
			if(combatant != null && drag.User != null && 
				HUDStatusType.Shortcut.Equals(this.type))
			{
				return this.shortcut.CheckDrop(combatant, drag, position, this.bounds);
			}
			return false;
		}
		
		public override IContent GetTooltip(Combatant combatant, Vector2 position)
		{
			if(!HUDStatusType.Shortcut.Equals(this.type) && 
				combatant != null)
			{
				if(HUDStatusCombatantOrigin.GroupTarget.Equals(this.combatantOrigin))
				{
					combatant = combatant.Group.SelectedTargets[this.originTargetIndex];
				}
				else if(HUDStatusCombatantOrigin.IndividualTarget.Equals(this.combatantOrigin))
				{
					combatant = combatant.SelectedTargets[this.originTargetIndex];
				}
				else if(HUDStatusCombatantOrigin.LastTarget.Equals(this.combatantOrigin))
				{
					combatant = combatant.LastTargets.Count > 0 ? combatant.LastTargets[0] : null;
				}
			}
			
			if(combatant != null)
			{
				if(HUDStatusType.StatusEffect.Equals(this.type))
				{
					return this.effect.GetTooltip(combatant, position, this.bounds);
				}
				else if(HUDStatusType.Shortcut.Equals(this.type))
				{
					return this.shortcut.GetTooltip(combatant, position, this.bounds);
				}
			}
			return null;
		}
		
		public override bool CheckClick(Combatant owner, Vector2 position)
		{
			if(owner != null && 
				!HUDCombatantClickType.None.Equals(this.clickType))
			{
				if(HUDCombatantClickType.MenuScreen.Equals(this.clickType))
				{
					if(owner.IsPlayerControlled())
					{
						MenuScreen screen = ORK.MenuScreens.Get(this.callScreenID);
						if(this.closeScreen && MenuStatus.Opened.Equals(screen.Status) && 
							(!this.closeScreenChange || screen.Combatant == owner))
						{
							if(this.clickClip != null)
							{
								ORK.Audio.PlayOneShot(this.clickClip, this.clickVolume);
							}
							
							screen.Close();
						}
						else if(!this.screenUseReq || ORK.Requirements.Get(this.screenReqID).Check())
						{
							if(this.clickClip != null)
							{
								ORK.Audio.PlayOneShot(this.clickClip, this.clickVolume);
							}
							
							screen.Combatant = owner;
							screen.Show();
						}
					}
				}
				else if(HUDCombatantClickType.ChangeMenuUser.Equals(this.clickType))
				{
					if(owner.IsPlayerControlled() && 
						(ORK.Menu.AnyMenu || ORK.Menu.AnyShop))
					{
						if(this.clickClip != null)
						{
							ORK.Audio.PlayOneShot(this.clickClip, this.clickVolume);
						}
						
						ORK.Menu.ChangeUser(owner, true, true);
					}
				}
				else if(HUDCombatantClickType.ChangePlayer.Equals(this.clickType))
				{
					if(owner.IsPlayerControlled() && 
						owner != ORK.Game.ActiveGroup.Leader)
					{
						if(this.clickClip != null)
						{
							ORK.Audio.PlayOneShot(this.clickClip, this.clickVolume);
						}
						
						ORK.Game.PlayerHandler.SetPlayer(owner, false);
					}
				}
				else if(HUDCombatantClickType.SelectTarget.Equals(this.clickType))
				{
					if(ORK.Battle.CombatantClicked(owner))
					{
						if(this.clickClip != null)
						{
							ORK.Audio.PlayOneShot(this.clickClip, this.clickVolume);
						}
					}
				}
				return true;
			}
			return false;
		}
	}
}
