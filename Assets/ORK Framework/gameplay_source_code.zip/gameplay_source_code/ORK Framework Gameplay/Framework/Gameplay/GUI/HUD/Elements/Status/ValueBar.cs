
using UnityEngine;
using ORKFramework.Display;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ValueBar : BaseData
	{
		[ORKEditorHelp("Bar Filling", "Select how the bar will be filled, i.e. the orientation of the bar.", "")]
		public HUDBarFilling filling = HUDBarFilling.LeftToRight;
		
		[ORKEditorHelp("Hide Empty Bar", "The bar wont be displayed when it's empty " +
			"(i.e. the value is the minimum value or lower).\n" +
			"If disabled, an empty bar will also be displayed (using the empty bar color).", "")]
		public bool hideEmpty = false;
		
		
		// color interpolation
		[ORKEditorHelp("Interpolate Colors", "When using colors instead of images, " +
			"the color will be interpolated between two percent settings.", "")]
		public bool interpolateColors = false;
		
		[ORKEditorHelp("Interpolate Empty Colors", "When using colors instead of images for the empty bar, " +
			"the color will be interpolated between two percent settings.", "")]
		public bool interpolateEmptyColors = false;
		
		
		// iconize
		[ORKEditorHelp("Use Icons", "The bar is displayed as icons, e.g. 10 HP could be displayed as 10 heart icons.", "")]
		public bool useIcons = false;
		
		[ORKEditorHelp("Icon Size", "The size of the icons, X=width, Y=height.\n" +
			"The full/empty icon images are defined by the bar/empty bar images.", "")]
		[ORKEditorLayout("useIcons", true)]
		public Vector2 icSize = new Vector2(30, 30);
		
		[ORKEditorHelp("Icon Offset", "The offset between two icons.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public float icOff = 0;
		
		
		// images
		[ORKEditorArray(false, "Add Images", "Add images to this element.\n" +
			"The bar can display different images depending on the filled percent of the bar.", "", 
			"Remove", "Remove images from this element.", "", noRemoveCount=1, isCopy=true, isMove=true, 
			foldout=true, foldoutText=new string[] {
				"Value Bar", "Set the percent and colors/images of the bar.", ""
		})]
		public ValueBarImage[] image = new ValueBarImage[] {new ValueBarImage()};
		
		public ValueBar()
		{
			
		}
		
		
		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public void CheckImages()
		{
			for(int i=0; i<this.image.Length; i++)
			{
				// make sure of percent sort
				if(i == 0)
				{
					this.image[i].percent = 100;
				}
				else if(this.image[i].percent > this.image[i - 1].percent)
				{
					this.image[i].percent = this.image[i - 1].percent;
				}
			}
		}
		
		
		/*
		============================================================================
		GUI functions
		============================================================================
		*/
		public void Create(ref List<BaseLabel> label, Rect bounds, float value, float minValue, float maxValue)
		{
			if(!this.hideEmpty || value > minValue)
			{
				ImageLabel imageLabel = null;
				
				value -= minValue;
				float p = value / (maxValue - minValue);
				if(p < 0)
				{
					p = 0;
				}
				else if(p > 1)
				{
					p = 1;
				}
				
				int index = 0;
				for(int i=this.image.Length-1; i>=0; i--)
				{
					if(p * 100 <= this.image[i].percent)
					{
						index = i;
						break;
					}
				}
				
				// color interpolation
				int interpolateColorID = -1;
				float interpolate = 1;
				if(this.interpolateColors && index < this.image.Length - 1 && 
					!this.image[index + 1].image.useImage)
				{
					interpolateColorID = this.image[index + 1].image.color;
					interpolate = (p * 100 - this.image[index + 1].percent) / 
						(this.image[index].percent - this.image[index + 1].percent);
				}
				
				int interpolateEmptyColorID = -1;
				float interpolateEmpty = 1;
				if(this.interpolateColors && index < this.image.Length - 1 && 
					this.image[index + 1].useEmpty && 
					!this.image[index + 1].image.useImage)
				{
					interpolateEmptyColorID = this.image[index + 1].emptyImage.color;
					interpolateEmpty = (p * 100 - this.image[index + 1].percent) / 
						(this.image[index].percent - this.image[index + 1].percent);
				}
				
				if(this.useIcons)
				{
					int j = 0;
					if(HUDBarFilling.LeftToRight.Equals(this.filling))
					{
						for(int i=(int)minValue; i<maxValue; i++)
						{
							if(i < value)
							{
								imageLabel = this.image[index].image.Create(
									new Rect((this.icSize.x + this.icOff) * j, 0, this.icSize.x, this.icSize.y), 
									interpolateColorID, interpolate);
							}
							else if(this.image[index].useEmpty)
							{
								imageLabel = this.image[index].emptyImage.Create(
									new Rect((this.icSize.x + this.icOff) * j, 0, this.icSize.x, this.icSize.y), 
									interpolateEmptyColorID, interpolateEmpty);
							}
							else
							{
								imageLabel = null;
							}
							if(imageLabel != null)
							{
								label.Add(imageLabel);
							}
							j++;
						}
					}
					else if(HUDBarFilling.RightToLeft.Equals(this.filling))
					{
						for(int i=(int)maxValue-1; i>=minValue; i--)
						{
							if(i < value)
							{
								imageLabel = this.image[index].image.Create(
									new Rect((this.icSize.x + this.icOff) * j, 0, this.icSize.x, this.icSize.y), 
									interpolateColorID, interpolate);
							}
							else if(this.image[index].useEmpty)
							{
								imageLabel = this.image[index].emptyImage.Create(
									new Rect((this.icSize.x + this.icOff) * j, 0, this.icSize.x, this.icSize.y), 
									interpolateEmptyColorID, interpolateEmpty);
							}
							else
							{
								imageLabel = null;
							}
							if(imageLabel != null)
							{
								label.Add(imageLabel);
							}
							j++;
						}
					}
					else if(HUDBarFilling.TopToBottom.Equals(this.filling))
					{
						for(int i=(int)minValue; i<maxValue; i++)
						{
							if(i < value)
							{
								imageLabel = this.image[index].image.Create(
									new Rect(0, (this.icSize.y + this.icOff) * j, this.icSize.x, this.icSize.y), 
									interpolateColorID, interpolate);
							}
							else if(this.image[index].useEmpty)
							{
								imageLabel = this.image[index].emptyImage.Create(
									new Rect(0, (this.icSize.y + this.icOff) * j, this.icSize.x, this.icSize.y), 
									interpolateEmptyColorID, interpolateEmpty);
							}
							else
							{
								imageLabel = null;
							}
							if(imageLabel != null)
							{
								label.Add(imageLabel);
							}
							j++;
						}
					}
					else if(HUDBarFilling.BottomToTop.Equals(this.filling))
					{
						for(int i=(int)maxValue-1; i>=minValue; i--)
						{
							if(i < value)
							{
								imageLabel = this.image[index].image.Create(
									new Rect(0, (this.icSize.y + this.icOff) * j, this.icSize.x, this.icSize.y), 
									interpolateColorID, interpolate);
							}
							else if(this.image[index].useEmpty)
							{
								imageLabel = this.image[index].emptyImage.Create(
									new Rect(0, (this.icSize.x + this.icOff) * j, this.icSize.x, this.icSize.y), 
									interpolateEmptyColorID, interpolateEmpty);
							}
							else
							{
								imageLabel = null;
							}
							if(imageLabel != null)
							{
								label.Add(imageLabel);
							}
							j++;
						}
					}
				}
				else
				{
					if(this.image[index].useEmpty)
					{
						imageLabel = this.image[index].emptyImage.Create(bounds, 
							this.filling, p, true, interpolateEmptyColorID, interpolateEmpty);
						if(imageLabel != null)
						{
							label.Add(imageLabel);
						}
					}
					
					imageLabel = this.image[index].image.Create(bounds, 
						this.filling, p, false, interpolateColorID, interpolate);
					
					if(imageLabel != null)
					{
						label.Add(imageLabel);
					}
				}
			}
		}
	}
}
