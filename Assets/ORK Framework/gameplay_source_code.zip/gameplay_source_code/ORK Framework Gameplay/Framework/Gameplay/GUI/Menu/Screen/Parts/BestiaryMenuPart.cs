
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Menu.Parts
{
	[ORKEditorHelp("Bestiary (Area)", "Displays bestiary entries separated by areas and area types.", "")]
	public class BestiaryAreaMenuPart : BaseMenuPart, IChoice, ITabChoice
	{
		// type settings
		// available types
		[ORKEditorHelp("All Area Types", "All area types will be available.\n" +
			"If disabled, you have to select the area types that will be available.", "")]
		[ORKEditorInfo("Available Area Types", "Define what area types will be displayed in this menu screen.", "")]
		public bool allTypes = true;
		
		public TypeSorter typeSorter = new TypeSorter();
		
		[ORKEditorHelp("Area Type", "Select the area type that will be available.", "")]
		[ORKEditorInfo(ORKDataType.AreaType, endFoldout=true, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Area Type", "Adds an area type that will be available.", "", 
			"Remove", "Removes this area type.", "", noRemoveCount=1, isHorizontal=true)]
		[ORKEditorLayout("allTypes", false, endCheckGroup=true, autoInit=true, autoSize=1)]
		public int[] availableTypeID;
		
		
		// type box settings
		[ORKEditorHelp("Show Type Box", "A type selection box is displayed.\n" +
			"If disabled, no type selection box is displayed, " +
			"but you can change the type using the change type keys.", "")]
		[ORKEditorInfo("Type Box Settings", "Define the content and layout of the area type box.", "")]
		public bool showTypeBox = true;
		
		[ORKEditorHelp("Show Empty Types", "Empty area types (without any added entries) will be displayed (with inactive buttons).\n" +
			"If disabled, only the area types with added areas will be displayed.", "")]
		public bool showEmptyTypes = false;
		
		[ORKEditorHelp("Merge Types", "Merge all area types into a single display.\n" +
			"If disabled, only a single area type will be displayed at a time - " +
			"you can use the type change keys to circle through available types.", "")]
		[ORKEditorLayout("showTypeBox", false, setDefault=true, defaultValue=false)]
		public bool mergeTypes = false;
		
		[ORKEditorHelp("Type Tabs", "Show the area types as tabs in the area box.", "")]
		[ORKEditorLayout("mergeTypes", false, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool typeTabs = false;
		
		[ORKEditorHelp("Display Type>Area", "Select the box display mode (Area Type to Area):\n" +
			"- Same: Types and areas use the same GUI box.\n" +
			"- One: Only one box will be displayed at a time. Types and areas use different GUI boxes.\n" +
			"- Multi: Multiple boxes are displayed at the same time. Types and areas use different GUI boxes.\n" +
			"- Sequence: Same as 'Multi', but the areas will only be displayed when a type was selected.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout(elseCheckGroup=true, setDefault=true, defaultValue=MenuBoxDisplay.Multi)]
		public MenuBoxDisplay displayArea = MenuBoxDisplay.Multi;
		
		[ORKEditorHelp("Type Box", "Select the GUI box used to display the area types.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		[ORKEditorLayout("displayArea", MenuBoxDisplay.Same, elseCheckGroup=true, endCheckGroup=true)]
		public int guiBoxID = 0;
		
		// back button
		[ORKEditorHelp("Add Back", "A back button will be added to the area type list.", "")]
		[ORKEditorInfo(separator=true)]
		public bool addBackType = false;
		
		[ORKEditorHelp("First Element", "The back button will be the first element in the area type list.\n" +
			"If disabled, the back button will be the last element.", "")]
		[ORKEditorLayout("addBackType", true, endCheckGroup=true)]
		public bool backFirstType = false;
		
		// title
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used type GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Title Settings")]
		[ORKEditorLayout(setDefault=true, defaultValue=false)]
		public bool useTypeTitle = false;
		
		[ORKEditorHelp("Title", "The title of the box.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useTypeTitle", true, endCheckGroup=true, endGroups=2, autoInit=true, autoLangSize=true)]
		public string[] typeTitle;
		
		[ORKEditorInfo("Type Content Layout", "Define the layout of the area type buttons.", "", 
			endFoldout=true)]
		[ORKEditorLayout(new string[] {"showTypeBox", "typeTabs"}, new System.Object[] {true, true}, 
			needed=Needed.One, endCheckGroup=true)]
		public ContentLayout typeContentLayout = new ContentLayout(ContentLayoutType.Both, ContentLayoutInfoType.None);
		
		// headers
		[ORKEditorInfo("Type Header Texts", "The header texts displayed above the choices.", "", 
			endFoldout=true, endFolds=2)]
		public HeaderTexts typeHeaderTexts = new HeaderTexts();
		
		
		// area box settings
		[ORKEditorHelp("Display Area>Bestiary", "Select the box display mode (Area to Bestiary):\n" +
			"- Same: Areas and bestiary use the same GUI box.\n" +
			"- One: Only one box will be displayed at a time. Areas and bestiary use different GUI boxes.\n" +
			"- Multi: Multiple boxes are displayed at the same time. Areas and bestiary use different GUI boxes.\n" +
			"- Sequence: Same as 'Multi', but the bestiary will only be displayed when an area was selected.", "")]
		[ORKEditorInfo("Area Box Settings", "Define the content and layout of the area box.", "", 
			isEnumToolbar=true, toolbarWidth=75)]
		public MenuBoxDisplay displayBestiary = MenuBoxDisplay.Multi;
		
		[ORKEditorHelp("Area Box", "Select the GUI box used to display the areas.\n" +
			"If 'Same' box display is selected, this box will also display the area types.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		[ORKEditorLayout("displayBestiary", MenuBoxDisplay.Same, elseCheckGroup=true, endCheckGroup=true)]
		public int guiBoxID2 = 0;
		
		[ORKEditorHelp("Show Portraits", "Display the portrait of a selected area (if available).", "")]
		public bool showAreaPortraits = false;
		
		[ORKEditorInfo(separator=true)]
		public ContentSorter areaSorter = new ContentSorter();
		
		// back button
		[ORKEditorHelp("Add Back", "A back button will be added to the area list.", "")]
		[ORKEditorInfo(separator=true)]
		public bool addBackArea = false;
		
		[ORKEditorHelp("First Element", "The back button will be the first element in the area list.\n" +
			"If disabled, the back button will be the last element.", "")]
		[ORKEditorLayout("addBackArea", true, endCheckGroup=true)]
		public bool backFirstArea = false;
		
		// title
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used area GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Title Settings")]
		public bool useTitleArea = false;
		
		[ORKEditorHelp("Title", "The title of the area box.", "")]
		[ORKEditorInfo(expandWidth=true, label=new string[] {
			"%n = type name (only if 'Merge Types' isn't selected)"
		})]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useTitleArea", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] titleArea;
		
		// layout
		[ORKEditorInfo("Area Content Layout", "Define the layout of the area buttons.", "", 
			endFoldout=true)]
		public ContentLayout areaContentLayout = new ContentLayout(ContentLayoutType.Both, ContentLayoutInfoType.None);
		
		// headers
		[ORKEditorInfo("Header Texts", "The header texts displayed above the choices.", "", 
			endFoldout=true, endFolds=2)]
		public HeaderTexts areaHeaderTexts = new HeaderTexts();
		
		
		// bestiary box settings
		[ORKEditorHelp("Display Bestiary>Entry", "Select the box display mode (Bestiary to Entry):\n" +
			"- Same: Bestiary and entries use the same GUI box.\n" +
			"- One: Only one box will be displayed at a time. Bestiary and entries use different GUI boxes.\n" +
			"- Multi: Multiple boxes are displayed at the same time. Bestiary and entries use different GUI boxes.\n" +
			"- Sequence: Same as 'Multi', but the entries will only be displayed when an area was selected.", "")]
		[ORKEditorInfo("Bestiary Box Settings", "Define the content and layout of the bestiary list box.", "", 
			isEnumToolbar=true, toolbarWidth=75)]
		public MenuBoxDisplay displayEntry = MenuBoxDisplay.Multi;
		
		[ORKEditorHelp("Bestiary Box", "Select the GUI box used to display the bestiary entries.\n" +
			"If 'Same' box display is selected, this box will also display the areas.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		public int guiBoxID3 = 0;
		
		[ORKEditorHelp("Show Portrait", "Display a portrait of the entry's combatant (if available).", "")]
		public bool showBestiaryPortrait = false;
		
		[ORKEditorHelp("Portrait Type", "Select the portrait type that will be used.", "")]
		[ORKEditorInfo(ORKDataType.PortraitType)]
		[ORKEditorLayout("showBestiaryPortrait", true, endCheckGroup=true)]
		public int bestiaryPortraitType = 0;
		
		[ORKEditorInfo(separator=true)]
		public ContentSorter bestiarySorter = new ContentSorter();
		
		[ORKEditorHelp("Add Back", "A back button will be added to the bestiary list.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("useChoice", true)]
		public bool addBackBestiary = false;
		
		[ORKEditorHelp("First Element", "The back button will be the first element in the bestiary list.\n" +
			"If disabled, the back button will be the last element.", "")]
		[ORKEditorLayout("addBackBestiary", true, endCheckGroup=true)]
		public bool backFirstBestiary = false;
		
		// title
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used bestiary GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Title Settings")]
		public bool useTitleBestiary = false;
		
		[ORKEditorHelp("Title", "The title of the bestiary box.", "")]
		[ORKEditorInfo(expandWidth=true, label=new string[] {
			"%n = area name"
		})]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useTitleBestiary", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] titleBestiary;
		
		// layout
		[ORKEditorInfo("Bestiary Content Layout", "Define the layout of the bestiary entry buttons.", "", 
			endFoldout=true)]
		public ContentLayout entryContentLayout = new ContentLayout(ContentLayoutType.Both, ContentLayoutInfoType.None);
		
		// headers
		[ORKEditorInfo("Header Texts", "The header texts displayed above the choices.", "", 
			endFoldout=true, endFolds=2)]
		public HeaderTexts headerTexts = new HeaderTexts();
		
		
		// entry box settings
		[ORKEditorHelp("Entry Box", "Select the GUI box used to display the a selected bestiary entry's information.\n" +
			"If 'Same' box display is selected, this box will also display the logs.", "")]
		[ORKEditorInfo("Entry Box Settings", "Define the content and layout of the bestiary entry box.", "", 
			isPopup=true, popupType=ORKDataType.GUIBox)]
		public int guiBoxID4 = 0;
		
		[ORKEditorHelp("Show OK Button", "Show the 'Ok' button of the GUI box.\n" +
			"When using 'Accept Next Page', this will toggle to the next combatant page.", "")]
		public bool showOkButton = false;
		
		[ORKEditorHelp("Show Cancel Button", "Show the 'Cancel' button of the GUI box.\n" +
			"This will close the entry box.", "")]
		public bool showCancelButton = false;
		
		[ORKEditorHelp("Show Portrait", "Display a portrait of the entry's combatant (if available).", "")]
		[ORKEditorInfo(separator=true)]
		public bool showEntryPortrait = false;
		
		[ORKEditorHelp("Portrait Type", "Select the portrait type that will be used.", "")]
		[ORKEditorInfo(ORKDataType.PortraitType)]
		[ORKEditorLayout("showEntryPortrait", true, endCheckGroup=true)]
		public int entryPortraitType = 0;
		
		[ORKEditorInfo(endFoldout=true, separator=true)]
		public BestiaryInformationDisplay entryInfo = new BestiaryInformationDisplay();
		
		
		// switch type keys
		[ORKEditorHelp("Use Change Keys", "The area type can be changed by input keys.", "")]
		[ORKEditorInfo("Type Change Keys", "The area type can be changed by input keys.", "")]
		[ORKEditorLayout("mergeTypes", false, setDefault=true, defaultValue=false)]
		public bool useTypeKeys = false;
		
		[ORKEditorHelp("Next Type", "Select the key used to select the next area type.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("useTypeKeys", true)]
		public int nextTypeKey = 0;
		
		[ORKEditorHelp("Previous Type", "Select the key used to select the previous area type.", "")]
		[ORKEditorInfo(ORKDataType.InputKey, endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2)]
		public int prevTypeKey = 0;
		
		
		// ingame
		private GUIBox box;
		
		private GUIBox box2;
		
		private GUIBox box3;
		
		private GUIBox box4;
		
		private int tmpTypeID = 0;
		
		private int current = 0;
		
		private int current2 = 0;
		
		private int current3 = 0;
		
		private int current4 = 0;
		
		private bool exitFlag = false;
		
		private int nextBox = 0;
		
		
		// area types
		private ChoiceContent[] typeChoice;
		
		private int[] typeAction;
		
		private List<int> areaTypes;
		
		
		// areas
		private ChoiceContent[] areaChoice;
		
		private List<Area> areas;
		
		
		// bestiary entries
		private ChoiceContent[] entryChoice;
		
		private List<BestiaryEntry> entries;
		
		public BestiaryAreaMenuPart()
		{
			
		}
		
		
		/*
		============================================================================
		Ok/cancel button functions
		============================================================================
		*/
		public bool ShowOKButton(GUIBox origin)
		{
			return this.box4 == origin && this.showOkButton;
		}
		
		public bool ShowCancelButton(GUIBox origin)
		{
			return this.box4 == origin && this.showCancelButton;
		}
		
		public bool IsOKButtonActive(GUIBox origin)
		{
			return this.box4 == origin;
		}
		
		public bool IsCancelButtonActive(GUIBox origin)
		{
			return this.box4 == origin;
		}
		
		public override bool Controlable
		{
			get{ return this.IsOpened;}
		}
		
		
		/*
		============================================================================
		Menu functions
		============================================================================
		*/
		public override bool IsOpened
		{
			get
			{
				return (this.box == null || this.box.FadedIn) && 
					(this.box2 == null || this.box2.FadedIn) && 
						(this.box3 == null || this.box3.FadedIn) && 
						(this.box4 == null || this.box4.FadedIn);
			}
		}
		
		public override bool IsClosed
		{
			get{ return this.box == null && this.box2 == null && 
				this.box3 == null && this.box4 == null;}
		}
		
		public bool Tick(GUIBox origin)
		{
			if(this.useTypeKeys)
			{
				if(ORK.InputKeys.Get(this.nextTypeKey).GetButton())
				{
					this.ChangeTypeKey(1, origin);
					return true;
				}
				else if(ORK.InputKeys.Get(this.prevTypeKey).GetButton())
				{
					this.ChangeTypeKey(-1, origin);
					return true;
				}
			}
			if(this.box4 == origin)
			{
				if(this.entryInfo.usePageKeys && this.entryInfo.page.Length > 1)
				{
					if(ORK.InputKeys.Get(this.entryInfo.nextPageKey).GetButton())
					{
						this.box.Audio.PlayAccept();
						this.ChangeEntryPage(1);
						return true;
					}
					else if(ORK.InputKeys.Get(this.entryInfo.prevPageKey).GetButton())
					{
						this.box.Audio.PlayAccept();
						this.ChangeEntryPage(-1);
						return true;
					}
				}
			}
			return false;
		}
		
		private void ChangeTypeKey(int change, GUIBox origin)
		{
			origin.Audio.PlayCursorMove();
			if(this.showTypeBox)
			{
				int index = this.current + change;
				if(index < 0)
				{
					index = this.typeChoice.Length - 1;
				}
				else if(index >= this.typeChoice.Length)
				{
					index = 0;
				}
				
				if(this.box != null)
				{
					this.box.Content.Selection = index;
				}
				if(this.box2 == origin)
				{
					this.ShowAreas();
				}
			}
			else if(this.box2 == origin)
			{
				this.CreateTypeList();
				
				int index = 0;
				for(int i=0; i<this.areaTypes.Count; i++)
				{
					if(this.areaTypes[i] == this.tmpTypeID)
					{
						index = i;
						break;
					}
				}
				index += change;
				if(index < 0)
				{
					index = this.areaTypes.Count - 1;
				}
				else if(index >= this.areaTypes.Count)
				{
					index = 0;
				}
				this.tmpTypeID = this.areaTypes[index];
				this.ShowAreas();
			}
		}
		
		private void ChangeEntryPage(int change)
		{
			this.current4 += change;
			if(this.current4 < 0)
			{
				this.current4 = this.entryInfo.page.Length - 1;
			}
			else if(this.current4 >= this.entryInfo.page.Length)
			{
				this.current4 = 0;
			}
			this.ShowEntry();
		}
		
		
		/*
		============================================================================
		Choice creation functions
		============================================================================
		*/
		private void CreateTypeList()
		{
			if(this.allTypes)
			{
				if(this.showEmptyTypes)
				{
					this.areaTypes = new List<int>();
					for(int i=0; i<ORK.AreaTypes.Count; i++)
					{
						this.areaTypes.Add(i);
					}
				}
				else
				{
					this.areaTypes = ORK.Game.Bestiary.GetAreaTypes();
				}
			}
			else
			{
				if(this.showEmptyTypes)
				{
					this.areaTypes = new List<int>(this.availableTypeID);
				}
				else
				{
					this.areaTypes = new List<int>();
					for(int i=0; i<this.availableTypeID.Length; i++)
					{
						if(ORK.Game.Bestiary.HasAreaType(this.availableTypeID[i]))
						{
							this.areaTypes.Add(this.availableTypeID[i]);
						}
					}
				}
			}
			this.typeSorter.Sort(ref this.areaTypes, ORKDataType.AreaType);
		}
		
		private void CreateTypeChoices()
		{
			this.typeChoice = null;
			this.typeAction = null;
			
			this.CreateTypeList();
			
			List<ChoiceContent> cc = new List<ChoiceContent>();
			List<int> ca = new List<int>();
			
			// back first
			if(this.addBackType && this.backFirstType)
			{
				cc.Add(this.typeContentLayout.GetChoiceContent(ORK.MenuSettings.backButton));
				ca.Add(-1);
			}
			
			// types
			for(int i=0; i<this.areaTypes.Count; i++)
			{
				ChoiceContent content = this.typeContentLayout.GetChoiceContent(ORK.AreaTypes.Get(this.areaTypes[i]));
				if(this.showEmptyTypes)
				{
					content.Active = ORK.Game.Bestiary.HasAreaType(this.areaTypes[i]);
				}
				cc.Add(content);
				ca.Add(this.areaTypes[i]);
			}
			
			// back last
			if(this.addBackType && !this.backFirstType)
			{
				cc.Add(this.typeContentLayout.GetChoiceContent(ORK.MenuSettings.backButton));
				ca.Add(-1);
			}
			
			this.typeChoice = cc.ToArray();
			this.typeAction = ca.ToArray();
		}
		
		private void CreateAreaChoices()
		{
			this.areas = null;
			this.areaChoice = null;
			
			if(!this.showTypeBox && !this.mergeTypes && this.typeTabs)
			{
				this.CreateTypeChoices();
			}
			
			// areas
			if((this.showTypeBox || (!this.mergeTypes && this.typeTabs)) && 
				this.current >= 0 && this.current < this.typeAction.Length && 
				this.typeAction[this.current] != -1)
			{
				this.areas = ORK.Game.Bestiary.GetAreasByType(this.typeAction[this.current]);
			}
			else if(!this.showTypeBox && this.mergeTypes)
			{
				this.areas = ORK.Game.Bestiary.GetAreasByType(-1);
			}
			else
			{
				this.areas = ORK.Game.Bestiary.GetAreasByType(this.tmpTypeID);
			}
			
			if(this.areas != null)
			{
				this.areaSorter.Sort(ref this.areas);
				
				List<ChoiceContent> cc = new List<ChoiceContent>();
				
				// back first
				if(this.addBackArea && this.backFirstArea)
				{
					cc.Add(this.areaContentLayout.GetChoiceContent(ORK.MenuSettings.backButton));
					this.areas.Insert(0, null);
				}
				
				// areas
				for(int i=0; i<this.areas.Count; i++)
				{
					if(this.areas[i] != null)
					{
						ChoiceContent content = this.areaContentLayout.GetChoiceContent(this.areas[i]);
						if(this.showAreaPortraits)
						{
							content.portrait = this.areas[i].portrait;
						}
						cc.Add(content);
					}
				}
				
				// back last
				if(this.addBackArea && !this.backFirstArea)
				{
					cc.Add(this.areaContentLayout.GetChoiceContent(ORK.MenuSettings.backButton));
					this.areas.Add(null);
				}
				
				this.areaChoice = cc.ToArray();
			}
		}
		
		private void CreateBestiaryChoices()
		{
			this.entries = null;
			this.entryChoice = null;
			
			// bestiary entries
			if(this.areas != null && 
				this.current2 >= 0 && this.current2 < this.areas.Count && 
				this.areas[this.current2] != null)
			{
				this.entries = ORK.Game.Bestiary.GetEntriesByArea(this.areas[this.current2].ID);
			}
			else
			{
				this.entries = ORK.Game.Bestiary.GetEntriesByArea(-1);
			}
			
			if(this.entries != null)
			{
				this.bestiarySorter.Sort(ref this.entries);
				
				List<ChoiceContent> cc = new List<ChoiceContent>();
				
				// back first
				if(this.addBackBestiary && this.backFirstBestiary)
				{
					cc.Add(this.entryContentLayout.GetChoiceContent(ORK.MenuSettings.backButton));
					this.entries.Insert(0, null);
				}
				
				// entries
				for(int i=0; i<this.entries.Count; i++)
				{
					if(this.entries[i] != null)
					{
						ChoiceContent content = this.entryContentLayout.GetChoiceContent(this.entries[i]);
						if(this.showBestiaryPortrait)
						{
							content.portrait = ORK.Combatants.Get(this.entries[i].ID).GetPortrait(this.bestiaryPortraitType);
						}
						cc.Add(content);
					}
				}
				
				// back last
				if(this.addBackBestiary && !this.backFirstBestiary)
				{
					cc.Add(this.entryContentLayout.GetChoiceContent(ORK.MenuSettings.backButton));
					this.entries.Add(null);
				}
				
				this.entryChoice = cc.ToArray();
			}
		}
		
		
		/*
		============================================================================
		Screen functions
		============================================================================
		*/
		public override bool ShowFirstDescription()
		{
			if(this.box != null && this.typeChoice != null && 
				this.current >= 0 && this.current < this.typeChoice.Length)
			{
				this.screen.ShowDescription(
					this.typeChoice[this.current].description, 
					this.typeChoice[this.current].Content.text, 
					this.typeAction[this.current] != -1 ? 
						ORK.AreaTypes.Get(this.typeAction[this.current]) : null);
				return true;
			}
			if(this.box2 != null && this.areaChoice != null && 
				this.current2 >= 0 && this.current2 < this.areaChoice.Length)
			{
				this.screen.ShowDescription(
					this.areaChoice[this.current2].description, 
					this.areaChoice[this.current2].Content.text, 
					this.areas[this.current2]);
				return true;
			}
			if((this.box3 != null || this.box4 != null) && 
				this.entryChoice != null && 
				this.current3 >= 0 && this.current3 < this.entryChoice.Length)
			{
				this.screen.ShowDescription(
					this.entryChoice[this.current3].description, 
					this.entryChoice[this.current3].Content.text, 
					this.entries[this.current3]);
				return true;
			}
			return false;
		}
		
		public override bool FocusFirst()
		{
			if(this.box != null)
			{
				this.box.SetFocus();
				return true;
			}
			else if(this.box2 != null)
			{
				this.box2.SetFocus();
				return true;
			}
			else if(this.box3 != null)
			{
				this.box3.SetFocus();
				return true;
			}
			else if(this.box4 != null)
			{
				this.box4.SetFocus();
				return true;
			}
			return false;
		}
		
		public override bool IsFocused()
		{
			return (this.box != null && this.box.Focused) || 
				(this.box2 != null && this.box2.Focused) || 
				(this.box3 != null && this.box3.Focused) || 
				(this.box4 != null && this.box4.Focused);
		}
		
		public override void Refresh()
		{
			if(this.box != null)
			{
				this.ShowTypes();
			}
			if(this.box2 != null)
			{
				this.ShowAreas();
			}
			if(this.box3 != null)
			{
				this.ShowBestiary();
			}
			if(this.box4 != null)
			{
				this.ShowEntry();
			}
		}
		
		public override void Show(MenuScreen s)
		{
			this.nextBox = 0;
			this.screen = s;
			this.CreateTypeList();
			this.tmpTypeID = this.areaTypes.Count > 0 ? this.areaTypes[0] : 0;
			
			// bestiary and entry share the same box
			if(MenuBoxDisplay.Same.Equals(this.displayEntry))
			{
				this.guiBoxID3 = this.guiBoxID4;
			}
			// areas and bestiary entries share the same box
			if(MenuBoxDisplay.Same.Equals(this.displayBestiary))
			{
				this.guiBoxID2 = this.guiBoxID3;
			}
			// types and areas share the same box
			if(this.showTypeBox && 
				MenuBoxDisplay.Same.Equals(this.displayArea))
			{
				this.guiBoxID = this.guiBoxID2;
			}
			
			ORK.Game.Bestiary.Changed += this.Refresh;
			
			this.Show();
		}
		
		public override void CloseImmediate()
		{
			ORK.Game.Bestiary.Changed -= this.Refresh;
			
			if(this.box != null)
			{
				this.box.SetOutDone();
				this.box = null;
			}
			if(this.box2 != null)
			{
				this.box2.SetOutDone();
				this.box2 = null;
			}
			if(this.box3 != null)
			{
				this.box3.SetOutDone();
				this.box3 = null;
			}
			if(this.box4 != null)
			{
				this.box4.SetOutDone();
				this.box4 = null;
			}
		}
		
		public override void Close()
		{
			ORK.Game.Bestiary.Changed -= this.Refresh;
			
			this.exitFlag = true;
			if(this.box != null && !this.box.FadingOut && !this.box.FadedOut)
			{
				this.box.InitOut();
			}
			if(this.box2 != null && !this.box2.FadingOut && !this.box2.FadedOut)
			{
				this.box2.InitOut();
			}
			if(this.box3 != null && !this.box3.FadingOut && !this.box3.FadedOut)
			{
				this.box3.InitOut();
			}
			if(this.box4 != null && !this.box4.FadingOut && !this.box4.FadedOut)
			{
				this.box4.InitOut();
			}
		}
		
		
		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public void Show()
		{
			if(!this.screen.RememberSelection)
			{
				this.current = 0;
				this.current2 = 0;
				this.current3 = 0;
				this.current4 = 0;
			}
			
			// type choice and areas
			if(this.showTypeBox)
			{
				this.ShowTypes();
				
				if(MenuBoxDisplay.Multi.Equals(this.displayArea))
				{
					this.ShowAreas();
				}
				
				this.box.SetFocus();
				this.SelectionChanged(this.current, this.box);
			}
			// only areas
			else
			{
				this.ShowAreas();
				this.box2.SetFocus();
				this.SelectionChanged(this.current2, this.box2);
			}
		}
		
		public void FocusGained(GUIBox origin)
		{
			if(this.box == origin && 
				!this.box.FadingOut && !this.box.FadedOut)
			{
				if(MenuBoxDisplay.Sequence.Equals(this.displayArea))
				{
					if(this.box2 != null && !this.box2.FadingOut && !this.box2.FadedOut)
					{
						this.box2.InitOut();
					}
					if(this.box3 != null && !this.box3.FadingOut && !this.box3.FadedOut)
					{
						this.box3.InitOut();
					}
					if(this.box4 != null && !this.box4.FadingOut && !this.box4.FadedOut)
					{
						this.box4.InitOut();
					}
				}
				
				// bestiary box
				if(MenuBoxDisplay.Same.Equals(this.displayBestiary) && 
					this.box3 != null && !this.box3.FadingOut && !this.box3.FadedOut)
				{
					this.box2 = this.box3;
					this.box3 = null;
					this.ShowAreas();
					
					if(this.box4 != null && !this.box4.FadingOut && !this.box4.FadedOut)
					{
						this.box4.InitOut();
						this.box4 = null;
					}
				}
				else if(MenuBoxDisplay.Sequence.Equals(this.displayBestiary) && 
					this.box3 != null && !this.box3.FadingOut && !this.box3.FadedOut)
				{
					this.box3.InitOut();
					
					if(this.box4 != null && !this.box4.FadingOut && !this.box4.FadedOut)
					{
						this.box4.InitOut();
						this.box4 = null;
					}
				}
				else if(MenuBoxDisplay.One.Equals(this.displayBestiary) && 
					this.box3 != null && !this.box3.FadingOut && !this.box3.FadedOut)
				{
					this.nextBox = 5;
					this.box3.InitOut();
					
					if(this.box4 != null && !this.box4.FadingOut && !this.box4.FadedOut)
					{
						this.box4.InitOut();
						this.box4 = null;
					}
				}
				if(MenuBoxDisplay.Sequence.Equals(this.displayEntry) && 
					this.box4 != null && !this.box4.FadingOut && !this.box4.FadedOut)
				{
					this.box4.InitOut();
				}
				
				if(!this.box.FadingOut && this.typeChoice != null && 
					this.current >= 0 && this.current < this.typeChoice.Length)
				{
					this.screen.ShowDescription(
						this.typeChoice[this.current].description, 
						this.typeChoice[this.current].Content.text, 
						this.typeAction[this.current] != -1 ? 
							ORK.AreaTypes.Get(this.typeAction[this.current]) : null);
				}
			}
			else if(this.box2 == origin && 
				!this.box2.FadingOut && !this.box2.FadedOut)
			{
				if(MenuBoxDisplay.Sequence.Equals(this.displayBestiary))
				{
					if(this.box3 != null && !this.box3.FadingOut && !this.box3.FadedOut)
					{
						this.box3.InitOut();
					}
					if(this.box4 != null && !this.box4.FadingOut && !this.box4.FadedOut)
					{
						this.box4.InitOut();
					}
				}
				if(MenuBoxDisplay.Sequence.Equals(this.displayEntry) && 
					this.box4 != null && !this.box4.FadingOut && !this.box4.FadedOut)
				{
					this.box4.InitOut();
				}
				
				if(!this.box2.FadingOut && this.areaChoice != null && 
					this.current2 >= 0 && this.current2 < this.areaChoice.Length)
				{
					this.screen.ShowDescription(
						this.areaChoice[this.current2].description, 
						this.areaChoice[this.current2].Content.text, 
						this.areas[this.current2]);
				}
			}
			else if(this.box3 == origin && 
				!this.box3.FadingOut && !this.box3.FadedOut)
			{
				if(MenuBoxDisplay.Sequence.Equals(this.displayEntry) && 
					this.box4 != null && !this.box4.FadingOut && !this.box4.FadedOut)
				{
					this.box4.InitOut();
				}
				
				if(this.entryChoice != null && 
					this.current3 >= 0 && this.current3 < this.entryChoice.Length)
				{
					this.screen.ShowDescription(
						this.entryChoice[this.current3].description, 
						this.entryChoice[this.current3].Content.text, 
						this.entries[this.current3]);
				}
			}
			else if(this.box4 == origin && 
				!this.box4.FadingOut && !this.box4.FadedOut)
			{
				if(this.entryChoice != null && 
					this.current3 >= 0 && this.current3 < this.entryChoice.Length)
				{
					this.screen.ShowDescription(
						this.entryChoice[this.current3].description, 
						this.entryChoice[this.current3].Content.text, 
						this.entries[this.current3]);
				}
			}
		}
		
		public void FocusLost(GUIBox origin)
		{
			
		}
		
		private void ShowTypes()
		{
			this.CreateTypeChoices();
			
			if(this.box == null || this.box.FadingOut || this.box.FadedOut)
			{
				this.box = ORK.GUIBoxes.Create(this.guiBoxID);
				this.box.inPause = this.screen.pauseGame;
				this.box.InitIn();
			}
			
			ValueHelper.Limit(ref this.current, 0, this.typeChoice.Length - 1);
			
			if(this.box.Content == null)
			{
				this.box.Content = new DialogueContent("", 
					this.useTypeTitle ? this.typeTitle[ORK.Game.Language] : "", 
					this.typeChoice, this, this.current);
				((DialogueContent)this.box.Content).header = this.typeHeaderTexts.GetContent();
			}
			else
			{
				((DialogueContent)this.box.Content).Update("", 
					this.useTypeTitle ? this.typeTitle[ORK.Game.Language] : "", 
					this.typeChoice, this.current, null, null);
				((DialogueContent)this.box.Content).header = this.typeHeaderTexts.GetContent();
			}
			if(this.box.Focused)
			{
				this.SelectionChanged(this.current, this.box);
			}
		}
		
		private void ShowAreas()
		{
			this.CreateAreaChoices();
			
			if(this.box2 == null || this.box2.FadingOut || this.box2.FadedOut)
			{
				this.box2 = ORK.GUIBoxes.Create(this.guiBoxID2);
				this.box2.inPause = this.screen.pauseGame;
				this.box2.InitIn();
			}
			
			if(this.areaChoice == null)
			{
				this.current2 = 0;
			}
			else
			{
				ValueHelper.Limit(ref this.current2, 0, this.areaChoice.Length - 1);
			}
			
			if(this.box2.Content == null)
			{
				this.box2.Content = new DialogueContent("", this.GetTitleArea(), 
					this.areaChoice, this, this.current2);
				((DialogueContent)this.box2.Content).header = this.areaHeaderTexts.GetContent();
			}
			else
			{
				((DialogueContent)this.box2.Content).Update("", this.GetTitleArea(), 
					this.areaChoice, this.current2, null, null);
				((DialogueContent)this.box2.Content).header = this.areaHeaderTexts.GetContent();
			}
			
			if(!this.showTypeBox && !this.mergeTypes && this.typeTabs)
			{
				this.box2.Content.SetTabs(this.typeChoice);
			}
			
			if(MenuBoxDisplay.Multi.Equals(this.displayBestiary))
			{
				this.ShowBestiary();
			}
			if(this.box2.Focused)
			{
				this.SelectionChanged(this.current2, this.box2);
			}
		}
		
		private string GetTitleArea()
		{
			if(this.useTitleArea)
			{
				if(this.showTypeBox && this.typeChoice != null && 
					this.current >= 0 && this.current < this.typeChoice.Length && 
					this.typeAction[this.current] != -1)
				{
					return this.titleArea[ORK.Game.Language].Replace("%n", this.typeChoice[this.current].Content.text);
				}
				else if(!this.showTypeBox && !this.mergeTypes)
				{
					return this.titleArea[ORK.Game.Language].Replace("%n", ORK.AreaTypes.GetName(this.tmpTypeID));
				}
				else
				{
					return this.titleArea[ORK.Game.Language].Replace("%n", "");
				}
			}
			return "";
		}
		
		private void ShowBestiary()
		{
			this.CreateBestiaryChoices();
			
			if(this.box3 == null || this.box3.FadingOut || this.box3.FadedOut)
			{
				this.box3 = ORK.GUIBoxes.Create(this.guiBoxID3);
				this.box3.inPause = this.screen.pauseGame;
				this.box3.InitIn();
			}
			
			if(this.entryChoice == null)
			{
				this.current3 = 0;
			}
			else
			{
				ValueHelper.Limit(ref this.current3, 0, this.entryChoice.Length - 1);
			}
			
			if(this.box3.Content == null)
			{
				this.box3.Content = new DialogueContent("", this.GetTitleBestiary(), 
					this.entryChoice, this, this.current3);
				((DialogueContent)this.box3.Content).header = this.headerTexts.GetContent();
			}
			else
			{
				((DialogueContent)this.box3.Content).Update("", this.GetTitleBestiary(), 
					this.entryChoice, this.current3, null, null);
				((DialogueContent)this.box3.Content).header = this.headerTexts.GetContent();
			}
			
			if(MenuBoxDisplay.Multi.Equals(this.displayEntry))
			{
				this.ShowEntry();
			}
			if(this.box3.Focused)
			{
				this.SelectionChanged(this.current3, this.box3);
			}
		}
		
		private string GetTitleBestiary()
		{
			if(this.useTitleBestiary)
			{
				if(this.areaChoice != null && 
					this.current2 >= 0 && this.current2 < this.areaChoice.Length && 
					this.areaChoice[this.current2] != null)
				{
					return this.titleBestiary[ORK.Game.Language].Replace("%n", this.areaChoice[this.current2].Content.text);
				}
				else
				{
					return this.titleBestiary[ORK.Game.Language].Replace("%n", "");
				}
			}
			return "";
		}
		
		private void ShowEntry()
		{
			if(this.box4 == null || this.box4.FadingOut || this.box4.FadedOut)
			{
				this.box4 = ORK.GUIBoxes.Create(this.guiBoxID4);
				this.box4.inPause = this.screen.pauseGame;
				this.box4.InitIn();
			}
			
			Combatant entryCombatant = null;
			if(this.entries != null && this.current3 >= 0 && this.current3 < this.entries.Count)
			{
				entryCombatant = this.entries[this.current3].GetCombatant();
			}
			
			if(this.box4.Content == null)
			{
				this.box4.Content = this.entryInfo.GetPage(this, entryCombatant, 
					this.showEntryPortrait ? this.entryPortraitType : -1, this.current4, 
					this.showOkButton || this.showCancelButton);
			}
			else
			{
				this.entryInfo.UpdatePage(
					this.box4.Content as BestiaryHUDContent, this, entryCombatant, 
					this.showEntryPortrait ? this.entryPortraitType : -1, this.current4);
			}
		}
		
		public void Closed(GUIBox origin)
		{
			if(this.exitFlag)
			{
				if(this.box == origin)
				{
					this.box = null;
				}
				else if(this.box2 == origin)
				{
					this.box2 = null;
				}
				else if(this.box3 == origin)
				{
					this.box3 = null;
				}
				else if(this.box4 == origin)
				{
					this.box4 = null;
				}
				if(this.box == null && this.box2 == null && 
					this.box3 == null && this.box4 == null)
				{
					this.exitFlag = false;
				}
			}
			else
			{
				// type switch to areas
				if(this.box == origin)
				{
					this.box = null;
					if(MenuBoxDisplay.One.Equals(this.displayArea))
					{
						this.ShowAreas();
						this.box2.SetFocus();
						this.SelectionChanged(this.current2, this.box2);
					}
				}
				// areas
				else if(this.box2 == origin)
				{
					this.box2 = null;
					if(this.nextBox == 3 && MenuBoxDisplay.One.Equals(this.displayBestiary))
					{
						this.ShowBestiary();
					}
					else if(this.nextBox != 3 && this.showTypeBox && 
						MenuBoxDisplay.One.Equals(this.displayArea))
					{
						this.ShowTypes();
					}
				}
				// bestiary entries
				else if(this.box3 == origin)
				{
					this.box3 = null;
					if(this.nextBox == 2 && 
						MenuBoxDisplay.One.Equals(this.displayBestiary))
					{
						this.ShowAreas();
						this.box2.SetFocus();
						this.SelectionChanged(this.current2, this.box2);
					}
					else if(this.nextBox == 5 && 
						MenuBoxDisplay.One.Equals(this.displayBestiary))
					{
						this.ShowAreas();
						if(this.box != null)
						{
							this.box.SetFocus();
						}
					}
				}
				// entry
				else if(this.box4 == origin)
				{
					this.box4 = null;
					if(this.nextBox == 3 && 
						MenuBoxDisplay.One.Equals(this.displayEntry))
					{
						this.ShowBestiary();
						this.box3.SetFocus();
						this.SelectionChanged(this.current3, this.box3);
					}
				}
			}
		}
		
		public override void CombatantChoiceClosed(bool canceled)
		{
			this.Refresh();
		}
		
		public override void ChangeCombatant(Combatant old)
		{
			
		}
		
		/*
		============================================================================
		Selection functions
		============================================================================
		*/
		public void ChoiceSelected(int index, GUIBox origin)
		{
			// type
			if(this.box == origin && this.typeChoice != null && 
				index >= 0 && index < this.typeChoice.Length)
			{
				if(this.current != index)
				{
					this.SelectionChanged(index, origin);
				}
				
				this.current = index;
				
				if(this.typeAction[this.current] == -1)
				{
					this.Cancel(this.box);
				}
				else
				{
					this.nextBox = 2;
					if(MenuBoxDisplay.Same.Equals(this.displayArea))
					{
						this.box2 = this.box;
						this.box = null;
						this.ShowAreas();
						this.box2.SetFocus();
						this.SelectionChanged(this.current2, this.box2);
					}
					else if(MenuBoxDisplay.One.Equals(this.displayArea))
					{
						this.box.InitOut();
					}
					else if(MenuBoxDisplay.Multi.Equals(this.displayArea))
					{
						this.box2.SetFocus();
					}
					else if(MenuBoxDisplay.Sequence.Equals(this.displayArea))
					{
						this.ShowAreas();
						this.box2.SetFocus();
						this.SelectionChanged(this.current2, this.box2);
					}
				}
			}
			// areas
			else if(this.box2 == origin && this.areaChoice != null && 
				index >= 0 && index < this.areaChoice.Length)
			{
				this.current2 = index;
				if(this.areas[this.current2] == null)
				{
					this.Cancel(this.box2);
				}
				else
				{
					this.nextBox = 3;
					if(MenuBoxDisplay.Same.Equals(this.displayBestiary))
					{
						this.box3 = this.box2;
						this.box2 = null;
						this.ShowBestiary();
					}
					else if(MenuBoxDisplay.One.Equals(this.displayBestiary))
					{
						this.box2.InitOut();
					}
					else if(MenuBoxDisplay.Multi.Equals(this.displayBestiary))
					{
						this.box3.SetFocus();
					}
					else if(MenuBoxDisplay.Sequence.Equals(this.displayBestiary))
					{
						this.ShowBestiary();
					}
				}
			}
			// bestiary entries
			else if(this.box3 == origin && this.entryChoice != null && 
				index >= 0 && index < this.entryChoice.Length)
			{
				this.current3 = index;
				if(this.entries[this.current3] == null)
				{
					this.Cancel(this.box3);
				}
				else
				{
					this.nextBox = 4;
					if(MenuBoxDisplay.Same.Equals(this.displayEntry))
					{
						this.box4 = this.box3;
						this.box3 = null;
						this.ShowEntry();
					}
					else if(MenuBoxDisplay.One.Equals(this.displayEntry))
					{
						this.box3.InitOut();
					}
					else if(MenuBoxDisplay.Multi.Equals(this.displayEntry))
					{
						this.box4.SetFocus();
					}
					else if(MenuBoxDisplay.Sequence.Equals(this.displayEntry))
					{
						this.ShowEntry();
					}
				}
			}
			// entry
			else if(this.box4 == origin)
			{
				if(this.entryInfo.acceptNext)
				{
					this.ChangeEntryPage(1);
				}
			}
		}
		
		public void SelectionChanged(int index, GUIBox origin)
		{
			// type
			if(this.box == origin)
			{
				if(this.typeChoice != null && 
					index >= 0 && index < this.typeChoice.Length)
				{
					this.screen.ShowDescription(
						this.typeChoice[index].description, 
						this.typeChoice[index].Content.text, 
						this.typeAction[index] != -1 ? 
							ORK.AreaTypes.Get(this.typeAction[index]) : null);
				}
				else
				{
					this.screen.ShowDescription("", "", null);
				}
				
				this.current = index;
				if(MenuBoxDisplay.Multi.Equals(this.displayArea))
				{
					this.ShowAreas();
				}
			}
			// areas
			else if(this.box2 == origin)
			{
				if(this.areaChoice != null && 
					index >= 0 && index < this.areaChoice.Length)
				{
					this.screen.ShowDescription(
						this.areaChoice[index].description, 
						this.areaChoice[index].Content.text, 
						this.areas[index]);
				}
				else
				{
					this.screen.ShowDescription("", "", null);
				}
				this.current2 = index;
				if(MenuBoxDisplay.Multi.Equals(this.displayBestiary))
				{
					this.ShowBestiary();
				}
			}
			// bestiary entries
			else if(this.box3 == origin)
			{
				if(this.entryChoice != null && 
					index >= 0 && index < this.entryChoice.Length)
				{
					this.screen.ShowDescription(
						this.entryChoice[index].description, 
						this.entryChoice[index].Content.text, 
						this.entries[index]);
				}
				else
				{
					this.screen.ShowDescription("", "", null);
				}
				this.current3 = index;
				
				if(MenuBoxDisplay.Multi.Equals(this.displayEntry))
				{
					this.ShowEntry();
				}
			}
		}
		
		public void TabChanged(int index, GUIBox box)
		{
			if(this.box2 == box)
			{
				this.current = index;
				this.ShowAreas();
			}
		}
		
		public void Canceled(GUIBox origin)
		{
			origin.Audio.PlayCancel();
			this.Cancel(origin);
		}
		
		private void Cancel(GUIBox origin)
		{
			// type
			if(this.box == origin)
			{
				this.screen.Close();
			}
			// area
			else if(this.box2 == origin)
			{
				if(this.showTypeBox)
				{
					this.nextBox = 1;
					if(MenuBoxDisplay.Same.Equals(this.displayArea))
					{
						this.box = this.box2;
						this.box2 = null;
						this.ShowTypes();
						
						if(this.box3 != null && !this.box3.FadingOut && !this.box3.FadedOut)
						{
							this.box3.InitOut();
						}
					}
					else if(MenuBoxDisplay.One.Equals(this.displayArea))
					{
						this.box2.InitOut();
						
						if(this.box3 != null && !this.box3.FadingOut && !this.box3.FadedOut)
						{
							this.box3.InitOut();
						}
					}
					else if(MenuBoxDisplay.Multi.Equals(this.displayArea))
					{
						this.box.SetFocus();
					}
					else if(MenuBoxDisplay.Sequence.Equals(this.displayArea))
					{
						this.box2.InitOut();
						this.box.SetFocus();
					}
				}
				else
				{
					this.screen.Close();
				}
			}
			// bestiary
			else if(this.box3 == origin)
			{
				this.nextBox = 2;
				if(MenuBoxDisplay.Same.Equals(this.displayBestiary))
				{
					this.box2 = this.box3;
					this.box2.Content = new DialogueContent("", this.GetTitleArea(), 
						this.areaChoice, this, this.current2);
					((DialogueContent)this.box2.Content).header = this.areaHeaderTexts.GetContent();
					this.box3 = null;
				}
				else if(MenuBoxDisplay.One.Equals(this.displayBestiary))
				{
					this.box3.InitOut();
				}
				else if(MenuBoxDisplay.Multi.Equals(this.displayBestiary))
				{
					this.box2.SetFocus();
				}
				else if(MenuBoxDisplay.Sequence.Equals(this.displayBestiary))
				{
					this.box3.InitOut();
					this.box2.SetFocus();
				}
			}
			// entry
			else if(this.box4 == origin)
			{
				this.nextBox = 3;
				if(MenuBoxDisplay.Same.Equals(this.displayEntry))
				{
					this.box3 = this.box4;
					this.box3.Content = new DialogueContent("", this.GetTitleBestiary(), 
						this.entryChoice, this, this.current3);
					((DialogueContent)this.box3.Content).header = this.headerTexts.GetContent();
					this.box4 = null;
				}
				else if(MenuBoxDisplay.One.Equals(this.displayEntry))
				{
					this.box4.InitOut();
				}
				else if(MenuBoxDisplay.Multi.Equals(this.displayEntry))
				{
					this.box3.SetFocus();
				}
				else if(MenuBoxDisplay.Sequence.Equals(this.displayEntry))
				{
					this.box4.InitOut();
					this.box3.SetFocus();
				}
			}
		}
	}
}
