
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ConsoleTextStatusValue : BaseData
	{
		[ORKEditorHelp("Console Type", "Select the console type this text will be displayed in.", "")]
		[ORKEditorInfo(ORKDataType.ConsoleType)]
		public int typeID = 0;
		
		[ORKEditorHelp("Text", "The text used to display status value changes.", "")]
		[ORKEditorInfo(isTextArea=true, separator=true, 
			label=new string[] {"%un = user name, %n = status value name, %i = status value icon, % = value (positive number)"})]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public string[] text = ArrayHelper.CreateArray(ORK.Languages.Count, "");
		
		public ConsoleTextStatusValue()
		{
			
		}
		
		public ConsoleTextStatusValue(string text)
		{
			this.text = ArrayHelper.CreateArray(ORK.Languages.Count, text);
		}
		
		public void Print(Combatant user, IContentSimple content, int change)
		{
			if(ORK.ConsoleSettings.statusRange.InRange(user))
			{
				ORK.Game.Console.AddLine(
					this.text[ORK.Game.Language].
						Replace("%un", user.GetName()).
						Replace("%n", content != null ? content.GetName() : "").
						Replace("%i", content != null ? content.GetIconTextCode() : "").
						Replace("%", change.ToString()), 
					this.typeID);
			}
		}
	}
}
