
using UnityEngine;
using ORKFramework.Display;
using System.Collections.Generic;

namespace ORKFramework
{
	public class EquipmentHUD : BaseData
	{
		[ORKEditorHelp("Only Available Parts", "Only equipment parts that are available " +
			"for the combatant will be displayed.\n" +
			"If a part isn't available, it wont be displayed." +
			"If disabled, all equipment parts can be displayed.", "")]
		public bool onlyAvailable = true;
		
		[ORKEditorHelp("List Parts", "All equipment parts of the combatant will be displayed.\n" +
			"If disabled, only the selected equipment part will be displayed.", "")]
		public bool list = true;
		
		[ORKEditorHelp("Offset", "The offset of each listed equipment part.", "")]
		[ORKEditorLayout("list", true)]
		public Vector2 off = new Vector2(0, 30);
		
		[ORKEditorHelp("Set Size", "Set the size of the individual equipment part manually.\n" +
			"If disabled, the size defined by the bounds is used.", "")]
		public bool setSize = false;
		
		[ORKEditorHelp("Size", "The width (X) and height (Y) of each equipment part.", "")]
		[ORKEditorLayout("setSize", true, endCheckGroup=true)]
		public Vector2 size = new Vector2(100, 20);
		
		
		// equipment part
		[ORKEditorHelp("Equipment Part", "Select the equipment part that will be displayed.\n" +
			"If the equipment part isn't available, nothing will be displayed.", "")]
		[ORKEditorInfo(ORKDataType.EquipmentPart)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int id = 0;
		
		
		// empty
		[ORKEditorHelp("Empty Part", "Define the name that is used when an " +
			"empty equipment part is displayed (i.e. nothing is equipped on the equipment part).", "")]
		[ORKEditorInfo(expandWidth=true, separator=true, labelText="Empty Equipment Part")]
		[ORKEditorArray(ORKDataType.Language)]
		public string[] emptyPart = ArrayHelper.CreateArray<string>(ORK.Languages.Count, "Empty");
		
		
		// text
		[ORKEditorInfo(separator=true, label=new string[] {
			"%n = equipment name, %d = equipment description, %i = equipment icon", 
			"%pn = part name, %pd = part description, %pi = part icon"
		})]
		public StatusTextHUD text = new StatusTextHUD();
		
		public EquipmentHUD()
		{
			
		}
		
		
		/*
		============================================================================
		Create label functions
		============================================================================
		*/
		public void CreateLabels(out List<BaseLabel> label, Combatant combatant, bool isBestiary, Rect bounds)
		{
			label = new List<BaseLabel>();
			
			if(this.list)
			{
				if(this.onlyAvailable)
				{
					List<int> avail = combatant.Equipment.GetAvailableParts();
					for(int i=0; i<avail.Count; i++)
					{
						this.CreatePart(ref label, avail[i], combatant.Equipment[avail[i]], 
							isBestiary ? combatant.Bestiary : null, 
							new Rect(this.off.x * i, this.off.y * i, 
								this.setSize ? this.size.x : bounds.width, 
								this.setSize ? this.size.y : bounds.height));
					}
				}
				else
				{
					for(int i=0; i<ORK.EquipmentParts.Count; i++)
					{
						this.CreatePart(ref label, i, combatant.Equipment[i], 
							isBestiary ? combatant.Bestiary : null, 
							new Rect(this.off.x * i, this.off.y * i, 
								this.setSize ? this.size.x : bounds.width, 
								this.setSize ? this.size.y : bounds.height));
					}
				}
			}
			else if(this.onlyAvailable)
			{
				if(combatant.Equipment[this.id].Available)
				{
					this.CreatePart(ref label, this.id, combatant.Equipment[this.id], 
						isBestiary ? combatant.Bestiary : null, bounds);
				}
			}
			else
			{
				this.CreatePart(ref label, this.id, combatant.Equipment[this.id], 
					isBestiary ? combatant.Bestiary : null, bounds);
			}
		}
		
		private void CreatePart(ref List<BaseLabel> label, int partID, 
			EquipPartSlot part, BestiaryEntry bestiary, Rect bounds)
		{
			string tmpText = "";
			
			if(bestiary == null || bestiary.IsComplete || 
				bestiary.status.equipment)
			{
				if(part.Equipped && part.Equipment != null)
				{
					tmpText = TextHelper.ReplaceSpecials(this.text.text[ORK.Game.Language].
						Replace("%pn", ORK.EquipmentParts.GetName(partID)).
						Replace("%pd", ORK.EquipmentParts.GetDescription(partID)).
						Replace("%pi", TextCode.EquipmentPartIcon + partID + "#").
						Replace("%n", part.Equipment.GetName()).
						Replace("%d", part.Equipment.GetDescription()).
						Replace("%i", part.Equipment.GetIconTextCode()));
				}
				else
				{
					tmpText = TextHelper.ReplaceSpecials(this.text.text[ORK.Game.Language].
						Replace("%pn", ORK.EquipmentParts.GetName(partID)).
						Replace("%pd", ORK.EquipmentParts.GetDescription(partID)).
						Replace("%pi", TextCode.EquipmentPartIcon + partID + "#").
						Replace("%n", this.emptyPart[ORK.Game.Language]).
						Replace("%d", "").
						Replace("%i", ""));
				}
			}
			else
			{
				tmpText = TextHelper.ReplaceSpecials(this.text.text[ORK.Game.Language].
					Replace("%pn", ORK.EquipmentParts.GetName(partID)).
					Replace("%pd", ORK.EquipmentParts.GetDescription(partID)).
					Replace("%pi", TextCode.EquipmentPartIcon + partID + "#").
					Replace("%n", ORK.GameSettings.bestiary.equipmentText[ORK.Game.Language]).
					Replace("%d", "").
					Replace("%i", ""));
			}
			
			label.AddRange(new MultiContent(tmpText, null, null, bounds, 
				this.text.lineSpacing, this.text.alignment, 
				this.text.vAlignment, BoxHeightAdjustment.Auto, false, 
				this.text.textFormat).label);
		}
	}
}
