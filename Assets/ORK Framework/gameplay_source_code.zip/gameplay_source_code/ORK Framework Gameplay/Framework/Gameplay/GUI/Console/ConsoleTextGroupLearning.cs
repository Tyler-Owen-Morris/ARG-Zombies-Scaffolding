
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ConsoleTextGroupLearning : BaseData
	{
		[ORKEditorHelp("Console Type", "Select the console type this text will be displayed in.", "")]
		[ORKEditorInfo(ORKDataType.ConsoleType)]
		public int typeID = 0;
		
		[ORKEditorHelp("Text", "The text used to display learning/forgetting a group ability.", "")]
		[ORKEditorInfo(isTextArea=true, separator=true, 
			label=new string[] {"%un = member name(s), %n = ability name, %i = ability icon"})]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public string[] text = ArrayHelper.CreateArray(ORK.Languages.Count, "");
		
		public ConsoleTextGroupLearning()
		{
			
		}
		
		public ConsoleTextGroupLearning(string text)
		{
			this.text = ArrayHelper.CreateArray(ORK.Languages.Count, text);
		}
		
		public void PrintNoRange(List<Combatant> owners, IContentSimple content)
		{
			ORK.Game.Console.AddLine(
				this.text[ORK.Game.Language].
					Replace("%un", ORK.ConsoleSettings.learningGroupNames.GetNames(owners)).
					Replace("%n", content.GetName()).
					Replace("%i", content.GetIconTextCode()), 
				this.typeID);
		}
		
		public void PrintLearnRange(List<Combatant> owners, IContentSimple content)
		{
			for(int i=0; i<owners.Count; i++)
			{
				if(ORK.ConsoleSettings.learningRange.InRange(owners[i]))
				{
					this.PrintNoRange(owners, content);
					break;
				}
			}
		}
		
		public void PrintForgetRange(List<Combatant> owners, IContentSimple content)
		{
			for(int i=0; i<owners.Count; i++)
			{
				if(ORK.ConsoleSettings.forgettingRange.InRange(owners[i]))
				{
					this.PrintNoRange(owners, content);
					break;
				}
			}
		}
	}
}
