
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Add To Bestiary", "Adds a combatant's entry to the bestiary.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Bestiary Steps")]
	public class AddToBestiaryStep : BaseEventStep
	{
		[ORKEditorHelp("Complete Entry", "A complete entry (i.e. with all status information) will be added to the bestiary.\n" +
			"If disabled, only a blank entry (i.e. without status information) will be added.", "")]
		public bool complete = false;
		
		[ORKEditorHelp("Ignore Not Scanable", "The combatant's 'Not Scanable' setting will be ignored.", "")]
		public bool ignoreNotScanable = false;
		
		[ORKEditorHelp("Ignore No Entry", "The combatant's 'No Bestiary Entry' setting will be ignored.", "")]
		public bool ignoreNoEntry = false;
		
		// object
		[ORKEditorHelp("Use Object", "Use an event object (e.g. actor) for the combatant.\n" +
			"If the object doesn't have a combatant, nothing will be added to the bestiary.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useObject = false;
		
		[ORKEditorInfo(separator=true, labelText="Object Settings")]
		[ORKEditorLayout("useObject", true, autoInit=true)]
		public EventObjectSetting usedObject;
		
		
		// combatant
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, autoInit=true)]
		public BestiaryLearnSetting entry = new BestiaryLearnSetting();
		
		
		// areas
		[ORKEditorHelp("Current Area", "The current area will be used when adding the bestiary entry.\n" +
			"If disabled, you can define areas that will be used.\n" +
			"Bestiary entries can be separated by areas in menu screens - " +
			"when encountering an enemy, the current area will be added to combatant's entry.", "")]
		[ORKEditorInfo(separator=true, labelText="Area Settings")]
		public bool currentArea = true;
		
		[ORKEditorHelp("Area", "Select the area the combatant's bestiary will be available in.", "")]
		[ORKEditorInfo(ORKDataType.Area, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Area", "Adds an area to the bestiary entry.", "", 
			"Remove", "Removes this area.", "", isHorizontal=true)]
		[ORKEditorLayout("currentArea", false, endCheckGroup=true, autoInit=true, autoSize=1)]
		public int[] areaID;
		
		public AddToBestiaryStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.useObject)
			{
				List<Combatant> list = this.usedObject.GetCombatant(baseEvent);
				for(int i=0; i<list.Count; i++)
				{
					if(this.complete)
					{
						ORK.Game.Bestiary.SetComplete(list[i], 
							this.currentArea ? new int[] {ORK.Game.AreaID} : this.areaID, 
							this.ignoreNotScanable, this.ignoreNoEntry);
					}
					else
					{
						ORK.Game.Bestiary.AddBlank(list[i], 
							this.currentArea ? new int[] {ORK.Game.AreaID} : this.areaID, 
							this.ignoreNoEntry);
					}
				}
			}
			else
			{
				this.entry.Add(this.complete, 
					this.currentArea ? new int[] {ORK.Game.AreaID} : this.areaID, 
					this.ignoreNotScanable, this.ignoreNoEntry);
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.complete ? "Complete: " : "") + 
				(this.useObject ? 
					this.usedObject.GetInfoText() : 
					ORK.Combatants.GetName(this.entry.combatantID));
		}
	}
	
	[ORKEditorHelp("Remove From Bestiary", "Removes a combatant's entry from the bestiary.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Bestiary Steps")]
	public class RemoveFromBestiaryStep : BaseEventStep
	{
		// object
		[ORKEditorHelp("Use Object", "Use an event object (e.g. actor) for the combatant.\n" +
			"If the object doesn't have a combatant, nothing will be removed from the bestiary.", "")]
		public bool useObject = false;
		
		[ORKEditorInfo(separator=true, labelText="Object Settings")]
		[ORKEditorLayout("useObject", true, autoInit=true)]
		public EventObjectSetting usedObject;
		
		
		// combatant
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, autoInit=true)]
		public BestiaryLearnSetting entry = new BestiaryLearnSetting();
		
		public RemoveFromBestiaryStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.useObject)
			{
				List<Combatant> list = this.usedObject.GetCombatant(baseEvent);
				for(int i=0; i<list.Count; i++)
				{
					ORK.Game.Bestiary.Remove(list[i]);
				}
			}
			else
			{
				this.entry.Remove();
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.useObject ? 
				this.usedObject.GetInfoText() : 
				ORK.Combatants.GetName(this.entry.combatantID);
		}
	}
	
	[ORKEditorHelp("Check Bestiary", "Checks if a combatant's entry is in the bestiary.\n" +
		"If the entry is found, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Bestiary Steps")]
	public class CheckBestiaryStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Complete Entry", "The combatant's entry must be complete (i.e. all status information known).\n" +
			"If disabled, the combatant only needs to have an entry in the bestiary.", "")]
		public bool isComplete = false;
		
		// object
		[ORKEditorHelp("Use Object", "Use an event object (e.g. actor) for the combatant.\n" +
			"If the object doesn't have a combatant, 'Failed' will be executed.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useObject = false;
		
		[ORKEditorInfo(separator=true, labelText="Object Settings")]
		[ORKEditorLayout("useObject", true, autoInit=true)]
		public EventObjectSetting usedObject;
		
		[ORKEditorHelp("All Combatants", "All combatants must be checked valid.\n" +
			"If disabled, a single combatant's valid check results in 'Success'.", "")]
		public bool allCombatants = false;
		
		
		// combatant
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, autoInit=true)]
		public BestiaryLearnSetting entry = new BestiaryLearnSetting();
		
		public CheckBestiaryStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			bool found = false;
			if(this.useObject)
			{
				List<Combatant> list = this.usedObject.GetCombatant(baseEvent);
				for(int i=0; i<list.Count; i++)
				{
					if(this.isComplete)
					{
						found = ORK.Game.Bestiary.IsComplete(list[i]);
					}
					else
					{
						found = ORK.Game.Bestiary.IsKnown(list[i]);
					}
					
					if(found && !this.allCombatants)
					{
						break;
					}
					else if(!found && this.allCombatants)
					{
						break;
					}
				}
			}
			else
			{
				if(this.isComplete)
				{
					found = this.entry.IsComplete();
				}
				else
				{
					found = this.entry.IsKnown();
				}
			}
			
			if(found)
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.isComplete ? "Complete: " : "") + 
				(this.useObject ? 
					this.usedObject.GetInfoText() : 
					ORK.Combatants.GetName(this.entry.combatantID));
		}
	}[ORKEditorHelp("Bestiary Dialogue", "Displays a dialogue with bestiary information of a selected game object or combatant.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Bestiary Steps", "Dialogue Steps")]
	public class BestiaryDialogueStep : BaseEventStep
	{
		public BestiaryChoice dialogue = new BestiaryChoice();
		
		public BestiaryDialogueStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			this.dialogue.Show(baseEvent, this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.dialogue.useObject ? 
					this.dialogue.usedObject.GetInfoText() : 
					ORK.Combatants.GetName(this.dialogue.entry.combatantID);
		}
	}
}
