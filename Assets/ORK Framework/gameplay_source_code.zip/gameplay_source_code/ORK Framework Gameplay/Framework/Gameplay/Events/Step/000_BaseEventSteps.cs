
using UnityEngine;
using ORKFramework;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	public static class EventStepHelper
	{
		public static Dictionary<System.Type, NodeInfo> GetSteps(System.Type eventType)
		{
			Dictionary<System.Type, NodeInfo> list = new Dictionary<System.Type, NodeInfo>();
			
			System.Reflection.Assembly[] assembly = System.AppDomain.CurrentDomain.GetAssemblies();
			for(int i=0; i<assembly.Length; i++)
			{
				EventStepHelper.AddFromAssembly(eventType, assembly[i], ref list);
			}
			
			return list;
		}
		
		private static void AddFromAssembly(System.Type eventType, 
			System.Reflection.Assembly assembly, ref Dictionary<System.Type, NodeInfo> list)
		{
			System.Type[] types = assembly.GetTypes();
			for(int i=0; i<types.Length; i++)
			{
				if(types[i].Namespace == "ORKFramework.Events.Steps")
				{
					ORKEventStepAttribute step = null;
					System.Object[] attr = types[i].GetCustomAttributes(typeof(ORKEventStepAttribute), true);
					if(attr.Length > 0)
					{
						step = attr[0] as ORKEventStepAttribute;
					}
					
					if(step != null && step.Available(eventType))
					{
						string[] help = new string[0];
						attr = types[i].GetCustomAttributes(typeof(ORKEditorHelpAttribute), true);
						if(attr.Length > 0)
						{
							help = (attr[0] as ORKEditorHelpAttribute).text;
						}
						
						string[] subMenu = new string[0];
						attr = types[i].GetCustomAttributes(typeof(ORKNodeInfoAttribute), true);
						if(attr.Length > 0)
						{
							subMenu = (attr[0] as ORKNodeInfoAttribute).subMenu;
						}
						if(!list.ContainsKey(types[i]))
						{
							list.Add(types[i], new NodeInfo(help, subMenu));
						}
					}
				}
			}
		}
	}
	
	public abstract class BaseEventStep : CoreEventStep
	{
		[ORKEditorHelp("Enabled", "This step is enabled and will be executed.\n" +
			"If disabled, the step wont execute and the next step ('Next' or 'Success') will be executed.", "")]
		[ORKEditorInfo(hide=true)]
		public bool active = true;
		
		[ORKEditorInfo(hide=true)]
		public int next = -1;
		
		public abstract void Execute(BaseEvent baseEvent);
		
		public virtual void Continue(BaseEvent baseEvent)
		{
			
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeName()
		{
			return "";
		}
		
		public override string GetNodeDetails()
		{
			return "";
		}
		
		public override string GetNextName(int index)
		{
			return "Next";
		}
		
		
		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override int GetNextCount()
		{
			return 1;
		}
		
		public override int GetNext(int index)
		{
			return this.next;
		}
		
		public override void SetNext(int index, int next)
		{
			this.next = next;
		}
		
		
		/*
		============================================================================
		Enable functions
		============================================================================
		*/
		public override bool IsEnabled
		{
			get{ return this.active;}
		}
		
		public virtual bool ExecuteOnStop
		{
			get{ return false;}
		}
	}
	
	public abstract class BaseEventCheckStep : BaseEventStep
	{
		[ORKEditorInfo(hide=true)]
		public int nextFail = -1;
		
		
		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Success";
			}
			else if(index == 1)
			{
				return "Failed";
			}
			return "";
		}
		
		public override int GetNextCount()
		{
			return 2;
		}
		
		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index == 1)
			{
				return this.nextFail;
			}
			return -1;
		}
		
		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index == 1)
			{
				this.nextFail = next;
			}
		}
	}
	
	[ORKEditorHelp("Wait", "Waits for a defined time.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Base Steps")]
	public class WaitStep : BaseEventStep
	{
		[ORKEditorHelp("Time (s)", "The time in seconds to wait before executing the next step.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float time = 1;
		
		[ORKEditorHelp("Random", "Wait for a random amount of time between two defined values ('Time' and 'Time 2').\n" +
			"If disabled, the step waits for the time defined in 'Time'.", "")]
		public bool random = false;
		
		[ORKEditorHelp("Time 2 (s)", "The 2nd time in seconds - the wait time will be between 'Time' and 'Time 2'.", "")]
		[ORKEditorLimit("time", false)]
		[ORKEditorLayout("random", true, endCheckGroup=true)]
		public float time2 = 1;
		
		public WaitStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.random)
			{
				baseEvent.StartTime(Random.Range(this.time, this.time2), this.next);
			}
			else
			{
				baseEvent.StartTime(this.time, this.next);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.random ? this.time + " - " + this.time2 + "s" : this.time + "s");
		}
	}
	
	[ORKEditorHelp("Random", "Randomly executes a next step out of a list of defined steps.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Base Steps")]
	public class RandomStep : BaseEventStep
	{
		[ORKEditorInfo(hide=true, instanceCallback="buttons:randomstep")]
		public int[] random = new int[] {-1};
		
		public RandomStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			baseEvent.StepFinished(this.random[Random.Range(0, this.random.Length)]);
		}
		
		
		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			return "Random " + index;
		}
		
		public override int GetNextCount()
		{
			return this.random.Length;
		}
		
		public override int GetNext(int index)
		{
			return this.random[index];
		}
		
		public override void SetNext(int index, int next)
		{
			this.random[index] = next;
		}
	}
	
	[ORKEditorHelp("Wait For Input", "Waits for an input key to be pressed, " +
		"either for a set amount of time, or until the key has been pressed.\n" +
		"If waiting for time, 'Success' will be executed if the key was pressed in time, else 'Failed'.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Base Steps")]
	public class WaitForInputStep : BaseEventStep
	{
		[ORKEditorHelp("Any Key", "Any key (keyboard, mouse, etc.) can be used.", "")]
		public bool any = false;
		
		[ORKEditorHelp("Input Key", "Select the input key that will be used.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("any", false, endCheckGroup=true)]
		public int id = 0;
		
		[ORKEditorHelp("Wait", "The event will wait for a set amount of time for the key press.\n" +
			"If disabled, the event will wait until the key has been pressed.", "")]
		public bool wait = false;
		
		[ORKEditorHelp("Time (s)", "The time in seconds to wait for the key to be pressed.", "")]
		[ORKEditorLayout("wait", true)]
		[ORKEditorLimit(0.0f, false)]
		public float time = 1;
		
		[ORKEditorLayout(endCheckGroup=true, setDefault=true, defaultValue=-1)]
		[ORKEditorInfo(hide=true)]
		public int nextFail = -1;
		
		public WaitForInputStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.wait)
			{
				if(this.any)
				{
					baseEvent.WaitForButton(new int[0], this.time, new int[] {this.next}, this.nextFail);
				}
				else
				{
					baseEvent.WaitForButton(new int[] {this.id}, this.time, new int[] {this.next}, this.nextFail);
				}
			}
			else
			{
				if(this.any)
				{
					baseEvent.WaitForButton(new int[0], -1, new int[] {this.next}, this.next);
				}
				else
				{
					baseEvent.WaitForButton(new int[] {this.id}, -1, new int[] {this.next}, this.next);
				}
			}
		}
		
		
		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Success";
			}
			else if(index == 1)
			{
				return "Failed";
			}
			return "";
		}
		
		public override int GetNextCount()
		{
			return this.wait ? 2 : 1;
		}
		
		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index == 1)
			{
				return this.nextFail;
			}
			return -1;
		}
		
		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index == 1)
			{
				this.nextFail = next;
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.any ? "Any Key" : ORK.InputKeys.GetName(this.id)) + 
				(this.wait ? ", " + this.time + "s" : "");
		}
	}
	
	[ORKEditorHelp("Wait For Input Fork", "Waits for an input key (out of multiple keys) to be pressed, " +
		"either for a set amount of time, or until the key has been pressed.\n" +
		"The next step of the input key that's pressed first will be executed.\n" +
		"If waiting for time and no key was pressed in time, 'Failed' will be executed.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Base Steps")]
	public class WaitForInputForkStep : BaseEventStep
	{
		[ORKEditorHelp("Wait", "The event will wait for a set amount of time for a key press.\n" +
			"If disabled, the event will wait until a key has been pressed.", "")]
		public bool wait = false;
		
		[ORKEditorHelp("Time (s)", "The time in seconds to wait for a key to be pressed.", "")]
		[ORKEditorLayout("wait", true, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, false)]
		public float time = 1;
		
		[ORKEditorArray(false, "Add Input Key", "Adds an input key.", "", 
			"Remove", "Removes this input key.", "", noRemoveCount=1, isHorizontal=true)]
		public InputKeyNextNode[] inputKey = new InputKeyNextNode[] { new InputKeyNextNode()};
		
		public WaitForInputForkStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			int[] ks = new int[this.inputKey.Length];
			int[] ns = new int[this.inputKey.Length];
			
			for(int i=0; i<this.inputKey.Length; i++)
			{
				ks[i] = this.inputKey[i].inputKeyID;
				ns[i] = this.inputKey[i].next;
			}
			
			baseEvent.WaitForButton(ks, this.wait ? this.time : -1, ns, this.next);
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(this.wait)
			{
				if(index == 0)
				{
					return "Failed";
				}
				else if(index > 0)
				{
					return "Input Key " + (index - 1) + ": " + ORK.InputKeys.GetName(this.inputKey[index - 1].inputKeyID);
				}
			}
			else
			{
				return "Input Key " + index + ": " + ORK.InputKeys.GetName(this.inputKey[index].inputKeyID);
			}
			return "";
		}
		
		public override int GetNextCount()
		{
			return this.inputKey.Length + (this.wait ? 1 : 0);
		}
		
		public override int GetNext(int index)
		{
			if(this.wait)
			{
				if(index == 0)
				{
					return this.next;
				}
				else if(index > 0)
				{
					return this.inputKey[index - 1].next;
				}
			}
			else
			{
				return this.inputKey[index].next;
			}
			return -1;
		}
		
		public override void SetNext(int index, int next)
		{
			if(this.wait)
			{
				if(index == 0)
				{
					this.next = next;
				}
				else if(index > 0)
				{
					this.inputKey[index - 1].next = next;
				}
			}
			else
			{
				this.inputKey[index].next = next;
			}
		}
	}
	
	[ORKEditorHelp("Auto Save Game", "Saves the game to the AUTO save game file or creates a temporary retry save game.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleStartEvent), typeof(BattleEndEvent))]
	[ORKNodeInfo("Base Steps")]
	public class AutoSaveGameStep : BaseEventStep
	{
		[ORKEditorHelp("Save To Retry", "Creates a temporary retry save game.\n" +
			"The retry save game will be lost when loading it or quitting the game.\n" +
			"If disabled, the game will use the AUTO save game file to create a permanently save game.", "")]
		public bool retry = false;
		
		public AutoSaveGameStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.retry)
			{
				ORK.SaveGame.Save(SaveGameHandler.RETRY_INDEX);
			}
			else
			{
				ORK.SaveGame.Save(SaveGameHandler.AUTOSAVE_INDEX - ORK.Game.AutoSaveSlot);
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.retry ? "Retry" : "AUTO";
		}
	}
	
	[ORKEditorHelp("Auto Load Game", "Loads the game from the AUTO save game file or a temporary retry save game.\n" +
		"The event ends after this step.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleStartEvent), typeof(BattleEndEvent))]
	[ORKNodeInfo("Base Steps")]
	public class AutoLoadGameStep : BaseEventStep
	{
		[ORKEditorHelp("Load From Retry", "Loads a temporary retry save game.\n" +
			"If no retry save game is available, the last AUTO save game is used.", "")]
		public bool retry = false;
		
		public AutoLoadGameStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.retry && ORK.SaveGame.RetryAvailable())
			{
				ORK.SaveGame.Load(SaveGameHandler.RETRY_INDEX);
			}
			else
			{
				ORK.SaveGame.Load(SaveGameHandler.AUTOSAVE_INDEX - ORK.Game.AutoSaveSlot);
			}
			baseEvent.StepFinished(baseEvent.step.Length);
		}
		
		public override int GetNextCount()
		{
			return 0;
		}
		
		public override int GetNext(int index)
		{
			return -1;
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.retry ? "Retry" : "AUTO") + 
				": Ends the event";
		}
	}
	
	[ORKEditorHelp("Game Over", "Ends the game and calls the game over screen.\n" +
		"The event ends after this step.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Base Steps")]
	public class GameOverStep : BaseEventStep
	{
		public GameOverStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			baseEvent.SetGameOver();
			baseEvent.StepFinished(baseEvent.step.Length);
		}
		
		public override int GetNextCount()
		{
			return 0;
		}
		
		public override int GetNext(int index)
		{
			return -1;
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return "Ends the event";
		}
	}
	
	[ORKEditorHelp("Comment", "Leave a comment in your event.\n" +
		"This step does nothing and is only for commentary purposes.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Base Steps")]
	public class CommentStep : BaseEventStep
	{
		[ORKEditorHelp("Comment", "The comment.", "")]
		[ORKEditorInfo(isTextArea=true)]
		public string comment = "";
		
		public CommentStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.comment;
		}
	}
	
	[ORKEditorHelp("Re-Find Objects", "Search for actors and waypoints again.\n" +
		"Only actors or waypoints that have 'Find Object' enabled will be searched again.", "")]
	[ORKEventStep(typeof(GameEvent))]
	[ORKNodeInfo("Base Steps")]
	public class ReFindObjectsStep : BaseEventStep
	{
		[ORKEditorHelp("Find Actors", "Actors will be searched again.", "")]
		public bool findActors = true;
		
		[ORKEditorHelp("Find Waypoints", "Waypoints will be searched again.", "")]
		public bool findWaypoints = true;
		
		public ReFindObjectsStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(baseEvent is GameEvent)
			{
				if(this.findActors)
				{
					((GameEvent)baseEvent).ReFindActors();
				}
				if(this.findWaypoints)
				{
					((GameEvent)baseEvent).ReFindWaypoints();
				}
			}
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Block Input Key", "Blocks or unblocks an input key.\n" +
		"A blocked input key wont receive any input.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Base Steps")]
	public class BlockInputKeyStep : BaseEventStep
	{
		[ORKEditorHelp("Block/Unblock", "If enabled, the input key will be blocked.\n" +
			"If disabled, the input key will be unblocked.", "")]
		public bool block = false;
		
		[ORKEditorHelp("All Keys", "Block or unblock all input keys.\n" +
			"If disabled, only a selected input key will be blocked or unblocked.", "")]
		public bool all = false;
		
		[ORKEditorHelp("Input Key", "Select the input key that will be blocked or unblocked.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("all", false, endCheckGroup=true)]
		public int id = 0;
		
		public BlockInputKeyStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.all)
			{
				for(int i=0; i<ORK.InputKeys.Count; i++)
				{
					ORK.InputKeys.Get(i).Blocked = this.block;
				}
			}
			else
			{
				ORK.InputKeys.Get(this.id).Blocked = this.block;
			}
			
			baseEvent.StepFinished(this.next);
		}
		
		public override bool ExecuteOnStop
		{
			get{ return true;}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.block ? "Block " : "Unblock ") + 
				(this.all ? "All Keys" : ORK.InputKeys.GetName(this.id));
		}
	}
	
	[ORKEditorHelp("Block Control Map", "Blocks or unblocks a control map.\n" +
		"A blocked control map can't be used.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Base Steps")]
	public class BlockControlMapStep : BaseEventStep
	{
		[ORKEditorHelp("Block/Unblock", "If enabled, the control map will be blocked.\n" +
			"If disabled, the control map will be unblocked.", "")]
		public bool block = false;
		
		[ORKEditorHelp("All Control Maps", "Block or unblock all control maps.\n" +
			"If disabled, only a selected control map will be blocked or unblocked.", "")]
		public bool all = false;
		
		[ORKEditorHelp("Control Map", "Select the control map that will be blocked or unblocked.", "")]
		[ORKEditorInfo(ORKDataType.ControlMap)]
		[ORKEditorLayout("all", false, endCheckGroup=true)]
		public int id = 0;
		
		public BlockControlMapStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.all)
			{
				for(int i=0; i<ORK.ControlMaps.Count; i++)
				{
					ORK.ControlMaps.Get(i).Blocked = this.block;
				}
			}
			else
			{
				ORK.ControlMaps.Get(this.id).Blocked = this.block;
			}
			
			baseEvent.StepFinished(this.next);
		}
		
		public override bool ExecuteOnStop
		{
			get{ return true;}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.block ? "Block " : "Unblock ") + 
				(this.all ? "All Control Maps" : ORK.ControlMaps.GetName(this.id));
		}
	}
	
	[ORKEditorHelp("Search Objects", "Searches for game objects in the scene and " +
		"adds or removes them to the 'Found Objects' list, or removes all found objects from the list.\n" +
		"Found objects can be used in event steps by using the 'Found Objects' selection.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Base Steps")]
	public class SearchObjectsStep : BaseEventStep
	{
		[ORKEditorHelp("Change Type", "Select how the found objects will be changed:\n" +
			"- Add: The objects will be added to the found objects.\n" +
			"- Remove: The objects will be removed from the found objects.\n" +
			"- Clear: All found objects will be removed.", "")]
		public ListChangeType changeType = ListChangeType.Add;
		
		
		// find settings
		[ORKEditorInfo(separator=true, labelText="Find Objects")]
		[ORKEditorLayout("changeType", ListChangeType.Clear, 
			elseCheckGroup=true, autoInit=true)]
		public FindObjectSetting findObject;
		
		
		// searching object
		[ORKEditorHelp("Search from Object", 
			"Search using a different object than the event object for range checks.\n" +
			"If disabled, the event object (e.g. the user of an action or " +
			"the game object with the event interaction) will be used.", "")]
		[ORKEditorInfo(separator=true, labelText="Search Origin")]
		public bool fromObject = false;
		
		[ORKEditorLayout("fromObject", true, endCheckGroup=true, endGroups=2, autoInit=true)]
		public EventObjectSetting searchObject;
		
		public SearchObjectsStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(ListChangeType.Clear.Equals(this.changeType))
			{
				baseEvent.ChangeFoundObjects(null, this.changeType);
			}
			else
			{
				baseEvent.ChangeFoundObjects(
					this.findObject.Find(this.fromObject ? 
						TransformHelper.GetFirstObject(this.searchObject.GetObject(baseEvent)) : 
						baseEvent.GameObject), 
					this.changeType);
			}
			
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.changeType.ToString();
		}
	}
	
	[ORKEditorHelp("Raycast Object", "Adds the hit game object of a raycast to the 'Found Objects' list.\n" +
		"If something was hit, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Base Steps")]
	public class RaycastObjectStep : BaseEventCheckStep, IStepUpdate
	{
		[ORKEditorHelp("Change Type", "Select how the found objects will be changed:\n" +
			"- Add: The objects will be added to the found objects.\n" +
			"- Remove: The objects will be removed from the found objects.\n" +
			"- Clear: All found objects will be removed before adding the object.", "")]
		public ListChangeType changeType = ListChangeType.Add;
		
		[ORKEditorHelp("Use Root", "The hit game object's root will be used.\n" +
			"If 'Path to Child' is used, the child will be searched from the root.", "")]
		public bool useRoot = false;
		
		[ORKEditorHelp("Path to Child", "A child object of the hit game object is used.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string pathToChild = "";
		
		// input
		[ORKEditorHelp("Use Input", "Use mouse/touch input to select the target of the raycast.\n" +
			"If disabled, the raycast will be cast using the defined settings.", "")]
		[ORKEditorInfo(separator=true, labelText="Input Settings")]
		public bool useInput = false;
		
		[ORKEditorLayout("useInput", true, autoInit=true)]
		public MouseTouchControl mouseTouch;
		
		// wait
		[ORKEditorHelp("Wait", "The event will wait for a set amount of time for the mouse/touch input.\n" +
			"If disabled, the event will wait until the mouse/touch input has been received.", "")]
		[ORKEditorLayout(setDefault=true, defaultValue=false)]
		public bool wait = false;
		
		[ORKEditorHelp("Time (s)", "The time in seconds to wait for the mouse/touch input.", "")]
		[ORKEditorLayout("wait", true, endCheckGroup=true, endGroups=2)]
		[ORKEditorLimit(0.0f, false)]
		public float time = 1;
		
		
		// raycast settings
		[ORKEditorHelp("Distance", "The distance the raycast will use.\n" +
			"If nothing is hit within this distance, no target will be found.", "")]
		[ORKEditorInfo(separator=true, labelText="Raycast Settings")]
		public float distance = 100.0f;
		
		[ORKEditorHelp("Layer Mask", "Select the layer the raycast will use.\n" +
			"Only objects on this layer can be hit by the raycast.", "")]
		public LayerMask layerMask = -1;
		
		[ORKEditorHelp("Ray Origin", "The origin position of the raycast.\n" +
			"- User: A game object (e.g. an actor) is the origin.\n" +
			"- Screen: The screen is the origin. If you use mouse/touch control, " +
			"the point you clicked/touched the screen is the origin, else the center of the screen.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75)]
		public TargetRayOrigin rayOrigin = TargetRayOrigin.User;
		
		[ORKEditorHelp("Use Mouse Position", "Use the current mouse position as target for the raycast.", "")]
		[ORKEditorLayout("useInput", false, endCheckGroup=true)]
		public bool useMousePosition = false;
		
		[ORKEditorHelp("Origin Offset", "The offset will be added to the origin position of the raycast.", "")]
		public Vector3 originOffset = Vector3.zero;
		
		
		// user
		[ORKEditorHelp("Ignore User", "The game object of the user of will be ignored by the raycast.", "")]
		[ORKEditorLayout("rayOrigin", TargetRayOrigin.User)]
		public bool ignoreUser = false;
		
		[ORKEditorLayout(autoInit=true)]
		public EventObjectSetting userObject;
		
		[ORKEditorHelp("Direction", "The direction in local space the raycast will be sent to.\n" +
			"E.g. X=0, Y=0, Z=1 will send the raycast forward.\n" +
			"This setting is only used when not using mouse/touch input.", "")]
		[ORKEditorLayout(new string[] {"useInput", "useMousePosition"}, 
			new System.Object[] {false, false}, 
			needed=Needed.All, endCheckGroup=true, endGroups=2)]
		public Vector3 rayDirection = Vector3.forward;
		
		public RaycastObjectStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.useInput)
			{
				baseEvent.WaitForStep(this, this.wait ? this.time : -1, this.nextFail);
			}
			else
			{
				bool found = false;
				Ray ray = new Ray(Vector3.zero, Vector3.forward);
				
				if(TargetRayOrigin.User.Equals(this.rayOrigin))
				{
					int userIndex = -1;
					List<GameObject> list = this.userObject.GetObject(baseEvent);
					for(int i=0; i<list.Count; i++)
					{
						if(list[i] != null)
						{
							ray = new Ray(list[i].transform.position + this.originOffset, 
								this.useMousePosition ? 
									VectorHelper.GetDirection(list[i].transform.position + this.originOffset, 
										this.ScreenRayPoint(this.GetMousePosition(), baseEvent)) : 
									list[i].transform.TransformDirection(this.rayDirection));
							userIndex = i;
							break;
						}
					}
					
					if(userIndex >= 0)
					{
						if(this.ignoreUser)
						{
							RaycastOutput[] hit = RaycastHelper.RaycastAll(ray.origin, ray.direction, this.distance, this.layerMask);
							if(hit.Length > 0)
							{
								for(int i=0; i<hit.Length; i++)
								{
									if(!this.ignoreUser || list[userIndex].transform.root != hit[i].transform.root)
									{
										this.SelectObject(hit[i].transform.gameObject, baseEvent);
										found = true;
										break;
									}
								}
							}
						}
					}
				}
				else
				{
					Vector3 tmp = Vector3.zero;
					if(this.useMousePosition)
					{
						tmp = this.GetMousePosition();
					}
					else
					{
						tmp = ORK.GameSettings.GetScreenCenter() + this.originOffset;
						tmp = ORK.Core.GUIMatrix.MultiplyPoint3x4(tmp);
						tmp.y = Screen.height - tmp.y;
					}
					
					Transform cam = baseEvent.GetCamera();
					if(cam != null && cam.GetComponent<Camera>() != null)
					{
						ray = cam.GetComponent<Camera>().ScreenPointToRay(tmp);
					}
					else if(Camera.main != null)
					{
						ray = Camera.main.ScreenPointToRay(tmp);
					}
					RaycastOutput hit = null;
					if(RaycastHelper.Raycast(ray.origin, ray.direction, out hit, this.distance, this.layerMask))
					{
						found = true;
						this.SelectObject(hit.transform.gameObject, baseEvent);
					}
				}
				
				if(found)
				{
					baseEvent.StepFinished(this.next);
				}
				else
				{
					baseEvent.StepFinished(this.nextFail);
				}
			}
		}
		
		public bool Tick(float delta, BaseEvent baseEvent, ref int nextStep)
		{
			Vector3 point = Vector3.zero;
			if(this.mouseTouch.Interacted(ref point))
			{
				bool found = false;
				Ray ray = new Ray(Vector3.zero, Vector3.forward);
				
				if(TargetRayOrigin.User.Equals(this.rayOrigin))
				{
					int userIndex = -1;
					List<GameObject> list = this.userObject.GetObject(baseEvent);
					for(int i=0; i<list.Count; i++)
					{
						if(list[i] != null)
						{
							Vector3 origin = list[i].transform.position + this.originOffset;
							ray = new Ray(origin, VectorHelper.GetDirection(origin, point));
							userIndex = i;
							break;
						}
					}
					
					if(userIndex >= 0)
					{
						if(this.ignoreUser)
						{
							RaycastOutput[] hit = RaycastHelper.RaycastAll(ray.origin, ray.direction, this.distance, this.layerMask);
							if(hit.Length > 0)
							{
								for(int i=0; i<hit.Length; i++)
								{
									if(!this.ignoreUser || list[userIndex].transform.root != hit[i].transform.root)
									{
										this.SelectObject(hit[i].transform.gameObject, baseEvent);
										found = true;
										break;
									}
								}
							}
						}
					}
				}
				else
				{
					Transform cam = baseEvent.GetCamera();
					if(cam != null && cam.GetComponent<Camera>() != null)
					{
						ray = cam.GetComponent<Camera>().ScreenPointToRay(point + this.originOffset);
					}
					else if(Camera.main != null)
					{
						ray = Camera.main.ScreenPointToRay(point + this.originOffset);
					}
					RaycastOutput hit = null;
					if(RaycastHelper.Raycast(ray.origin, ray.direction, out hit, this.distance, this.layerMask))
					{
						found = true;
						this.SelectObject(hit.transform.gameObject, baseEvent);
					}
				}
				
				if(found)
				{
					nextStep = this.next;
				}
				return true;
			}
			return false;
		}
		
		private void SelectObject(GameObject gameObject, BaseEvent baseEvent)
		{
			if(this.useRoot)
			{
				gameObject = gameObject.transform.root.gameObject;
			}
			if(this.pathToChild != "")
			{
				gameObject = TransformHelper.GetChildObject(this.pathToChild, gameObject);
			}
			
			List<GameObject> list = new List<GameObject>();
			list.Add(gameObject);
			
			if(ListChangeType.Clear.Equals(this.changeType))
			{
				baseEvent.ChangeFoundObjects(null, ListChangeType.Clear);
				baseEvent.ChangeFoundObjects(list, ListChangeType.Add);
			}
			else
			{
				baseEvent.ChangeFoundObjects(list, this.changeType);
			}
		}
		
		private Vector3 GetMousePosition()
		{
			Vector3 pos = this.originOffset + (Vector3)ORK.Control.MousePosition;
			pos = ORK.Core.GUIMatrix.MultiplyPoint3x4(pos);
			pos.y = Screen.height - pos.y;
			return pos;
		}
		
		private Vector3 ScreenRayPoint(Vector3 point, BaseEvent baseEvent)
		{
			Ray ray = new Ray(Vector3.zero, Vector3.forward);
			
			Transform cam = baseEvent.GetCamera();
			if(cam != null && cam.GetComponent<Camera>() != null)
			{
				ray = cam.GetComponent<Camera>().ScreenPointToRay(point);
			}
			else if(Camera.main != null)
			{
				ray = Camera.main.ScreenPointToRay(point);
			}
			
			RaycastOutput hit = null;
			if(RaycastHelper.Raycast(ray.origin, ray.direction, out hit, this.distance, this.layerMask))
			{
				point = hit.point;
			}
			else
			{
				point = ray.GetPoint(this.distance);
			}
			
			return point;
		}
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.changeType.ToString();
		}
	}
	
	[ORKEditorHelp("Add Combatant", "Adds a combatant to a game object.\n" +
		"This is only done if the game object doesn't already have a combatant.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Base Steps")]
	public class AddCombatantStep : BaseEventStep
	{
		[ORKEditorInfo(labelText="Object Settings")]
		public EventObjectSetting usedObject = new EventObjectSetting();
		
		
		// combatant settings
		[ORKEditorHelp("Battle Type", "Select the battle system type that will be used in a battle with this combatant.", "")]
		[ORKEditorInfo(separator=true, labelText="Combatant Settings")]
		public BattleSystemType battleType = BattleSystemType.TurnBased;
		
		[ORKEditorHelp("Faction", "Select the faction the combatant will be part of.", "")]
		[ORKEditorInfo(ORKDataType.Faction)]
		public int factionID = 0;
		
		public CombatantGroupMember combatantSetting = new CombatantGroupMember();
		
		public AddCombatantStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<GameObject> list = this.usedObject.GetObject(baseEvent);
			
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null && 
					list[i].GetComponent<CombatantComponent>() == null)
				{
					Combatant combatant = this.combatantSetting.Create(new Group(this.factionID));
					combatant.GameObject = list[i];
					combatant.Group.BattleType = this.battleType;
				}
			}
			
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.usedObject.GetInfoText() + ": " +
				ORK.Combatants.GetName(this.combatantSetting.id);
		}
	}
}
