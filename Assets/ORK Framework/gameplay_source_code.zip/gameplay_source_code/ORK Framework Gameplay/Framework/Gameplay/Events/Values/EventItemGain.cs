
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Events
{
	public class EventItemGain : BaseData
	{
		[ORKEditorHelp("Type", "Select the type, either an item, weapon, armor or money.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public ItemDropType type = ItemDropType.Item;
		
		[ORKEditorHelp("Selection", "Select the item, currency or equipment (based on the selected type).", "")]
		[ORKEditorInfo(isPopup=true, itemFieldName="type")]
		public int id = 0;
		
		[ORKEditorHelp("Level", "Select the level of the equipment.\n" +
			"If the level exceeds the maximum level of the equipment, the maximum level is used.", "")]
		[ORKEditorLimit(1, false)]
		[ORKEditorLayout(new string[] {"type", "type"}, 
			new System.Object[] {ItemDropType.Weapon, ItemDropType.Armor}, needed=Needed.One, 
			endCheckGroup=true)]
		public int level = 1;
		
		[ORKEditorInfo(separator=true, labelText="Quantity")]
		public EventInteger quantityValue = new EventInteger(1);
		
		[ORKEditorInfo(separator=true, labelText="Chance (%)")]
		public EventFloat chanceValue = new EventFloat(100);
		
		public EventItemGain()
		{
			
		}
		
		public override void SetData(DataObject data)
		{
			base.SetData(data);
			if(data.Contains<int>("quantity"))
			{
				int tmp = 1;
				data.Get("quantity", ref tmp);
				this.quantityValue.type = NumberValueType.Value;
				this.quantityValue.value = tmp;
			}
			if(data.Contains<float>("chance"))
			{
				float tmp = 100;
				data.Get("chance", ref tmp);
				this.chanceValue.type = NumberValueType.Value;
				this.chanceValue.value = tmp;
			}
		}
		
		public ItemGain GetItemGain(BaseEvent baseEvent)
		{
			ItemGain itemGain = new ItemGain();
			itemGain.type = this.type;
			itemGain.id = this.id;
			itemGain.level = this.level;
			itemGain.quantity = (int)this.quantityValue.GetValue(baseEvent);
			itemGain.chance = this.chanceValue.GetValue(baseEvent);
			return itemGain;
		}
	}
}
