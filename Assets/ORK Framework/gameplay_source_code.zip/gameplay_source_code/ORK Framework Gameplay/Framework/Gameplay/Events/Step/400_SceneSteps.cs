
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Load Scene", "Loads a scene and spawns the player.\n" +
		"If used in a battle start event, the battle arena will be placed at the spawn position and all combatants will spawn at their battle spots.\n" +
		"The scene needs to be added to the build settings of your project (read the Unity documentation for details).", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleStartEvent), typeof(BattleEndEvent))]
	[ORKNodeInfo("Scene Steps")]
	public class LoadSceneStep : BaseEventStep
	{
		[ORKEditorHelp("Load Stored Scene", "Loads the currently stored scene.\n" +
			"If no stored scene is available, nothing happens.", "")]
		public bool stored = false;
		
		// scene target
		[ORKEditorArray(true, "Add Target Scene", "Adds a target scene to the list.\n" +
			"If a more than one scene is available, one of the scenes is chosen at random.", "", 
			"Remove", "Removes the target scene.", "", noRemoveCount=1)]
		[ORKEditorLayout("stored", false, endCheckGroup=true, autoInit=true, autoSize=1)]
		public SceneTarget[] target = new SceneTarget[] {new SceneTarget()};
		
		
		// screen fade
		[ORKEditorHelp("Fade Out", "The screen will fade out.", "")]
		[ORKEditorInfo(separator=true, labelText="Fade Out Screen")]
		public bool useFadeOut = true;
		
		[ORKEditorLayout("useFadeOut", true, endCheckGroup=true, autoInit=true)]
		public FadeColorSettings fadeOut = new FadeColorSettings(0.5f, 0, 1);
		
		[ORKEditorHelp("Wait Fade In", "Wait for the fade in to finish before executing the next step.", "")]
		[ORKEditorInfo(separator=true, labelText="Fade In Screen")]
		public bool wait = false;
		
		[ORKEditorHelp("Fade In", "The screen will fade in.", "")]
		public bool useFadeIn = true;
		
		[ORKEditorLayout("useFadeIn", true, endCheckGroup=true, autoInit=true)]
		public FadeColorSettings fadeIn = new FadeColorSettings(0.5f, 1, 0);
		
		public LoadSceneStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(!this.stored || ORK.Game.GetStoredScene() != null)
			{
				SceneChanger changer = new GameObject().AddComponent<SceneChanger>();
				if(this.stored)
				{
					changer.target = new SceneTarget[] {ORK.Game.GetStoredScene()};
				}
				else
				{
					changer.target = this.target;
				}
				changer.useFadeOut = this.useFadeOut;
				changer.fadeOut = this.fadeOut;
				changer.waitFaidIn = this.wait;
				changer.useFadeIn = this.useFadeIn;
				changer.fadeIn = this.fadeIn;
				
				if(baseEvent is GameEvent)
				{
					((GameEvent)baseEvent).ChangeScene(changer, this.next);
				}
				else if(baseEvent is BattleStartEvent)
				{
					((BattleStartEvent)baseEvent).ChangeScene(changer, this.next);
				}
				else if(baseEvent is BattleEndEvent)
				{
					((BattleEndEvent)baseEvent).ChangeScene(changer, this.next);
				}
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.stored ? "Stored scene" : "") + (this.wait ? " (wait)" : "");
		}
	}
	
	[ORKEditorHelp("Store Scene", "Stores the current scene and player position/rotation.\n" +
		"The stored scene can be used in load scene steps.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleStartEvent), typeof(BattleEndEvent))]
	[ORKNodeInfo("Scene Steps")]
	public class StoreSceneStep : BaseEventStep
	{
		[ORKEditorHelp("Clear Scene", "Removes the currently stored scene.", "")]
		public bool clear = false;
		
		public StoreSceneStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.clear)
			{
				ORK.Game.ClearStoredScene();
			}
			else
			{
				ORK.Game.StoreScene();
			}
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Set Scene Position", "Set the default player position/rotation in a scene.\n" +
		"The scene position can be used to spawn the player by events, scene changers and teleports.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleStartEvent), typeof(BattleEndEvent))]
	[ORKNodeInfo("Scene Steps")]
	public class SetScenePositionStep : BaseEventStep
	{
		// scene
		[ORKEditorHelp("Current Scene", "The position for the current scene will be set.", "")]
		public bool curScene = true;
		
		[ORKEditorInfo(labelText="Scene Name")]
		[ORKEditorLayout("curScene", false, endCheckGroup=true, autoInit=true)]
		public StringValue name;
		
		
		// position
		[ORKEditorHelp("Clear Position", "Removes the scene position.", "")]
		public bool clear = false;
		
		[ORKEditorHelp("Object Position", "The position will be set to the current position of a game object.\n" +
		    "If multiple objects are used (e.g. multiple spawned prefabs), the center will be used.\n" +
			"If disabled, you have to define the position.", "")]
		[ORKEditorLayout("clear", false)]
		public bool curPos = true;

		[ORKEditorInfo(separator=true, labelText="Object")]
		[ORKEditorLayout("curPos", true, autoInit=true)]
		public EventObjectSetting onObject;
		
		[ORKEditorInfo(separator=true, labelText="Position")]
		[ORKEditorLayout(elseCheckGroup=true, autoInit=true)]
		public EventVector3 pos = new EventVector3();
		
		[ORKEditorHelp("Y Rotation", "Set the rotation along the Y-axis that will be used as scene position.", "")]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2)]
		public float yRot = 0;
		
		public SetScenePositionStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			string sc = this.curScene ? Application.loadedLevelName : this.name.GetValue();
			if(this.clear)
			{
				ORK.Game.Scene.SetScenePosition(sc, null);
			}
			else
			{
				SceneTarget target = new SceneTarget(sc, -1);
				target.type = SceneTargetType.Position;
				if(this.curPos)
				{
					List<GameObject> list = this.onObject.GetObject(baseEvent);
					target.position = TransformHelper.GetCenterPosition(list);
					target.yRot = TransformHelper.GetAverageEulerAngles(list).y;
				}
				else
				{
					target.position = this.pos.GetValue(baseEvent);
					target.yRot = this.yRot;
				}
				ORK.Game.Scene.SetScenePosition(sc, target);
			}
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Remove Scene Data", "Item drops and collected item flags can be removed in a defined scene, or in all scenes.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleStartEvent), typeof(BattleEndEvent))]
	[ORKNodeInfo("Scene Steps")]
	public class RemoveSceneDataStep : BaseEventStep
	{
		// scene
		[ORKEditorHelp("All Scenes", "Removes the data from all scenes.", "")]
		public bool all = false;
		
		[ORKEditorInfo(separator=true, labelText="Scene Name")]
		[ORKEditorLayout("all", false, endCheckGroup=true, autoInit=true)]
		public StringValue name;
		
		
		// remove data
		[ORKEditorHelp("Remove Item Drops", "All item drops in the scene(s) will be removed.", "")]
		[ORKEditorInfo(separator=true)]
		public bool drops = false;
		
		[ORKEditorHelp("Remove Collected Items", "All flags of collected items will be removed.\n" +
			"Already collected items (using scene ID in the item collector) will reappear when entering the scene(s).", "")]
		public bool collects = false;
		
		[ORKEditorHelp("Remove Finished Battles", "All flags of finished battles will be removed.\n" +
			"Already finished battles (using scene ID in the battle component) will reappear when entering the scene(s).", "")]
		public bool battles = false;
		
		[ORKEditorHelp("Remove Scene Position", "The scene position will be removed.", "")]
		public bool position = false;
		
		[ORKEditorHelp("Remove Spawned Combatants", "Combatants spawned by " +
			"'Combatant Spawner' components will be removed.", "")]
		public bool spawner = false;
		
		public RemoveSceneDataStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.all)
			{
				ORK.Game.Scene.ClearScene("", this.drops, this.collects, 
					this.battles, this.position, this.spawner);
			}
			else
			{
				ORK.Game.Scene.ClearScene(this.name.GetValue(), this.drops, this.collects, 
					this.battles, this.position, this.spawner);
			}
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Add To Item Box", "Adds items to an item box using it's box ID.\n" +
		"The box ID can be found in the item collector inspector of the item box in the scene.\n" +
		"Requires the item box content saving at least game-wide (i.e. not type 'None').", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleStartEvent), typeof(BattleEndEvent))]
	[ORKNodeInfo("Scene Steps", "Inventory Steps")]
	public class AddToItemBoxStep : BaseEventStep
	{
		// scene
		[ORKEditorHelp("All Boxes", "Add the items to all item boxes.\n" +
			"Only affects item boxes which have their content stored.", "")]
		public bool all = false;
		
		[ORKEditorInfo(separator=true, labelText="Box ID")]
		[ORKEditorLayout("all", false, endCheckGroup=true, autoInit=true)]
		public StringValue name = new StringValue();
		
		
		// items
		[ORKEditorInfo(separator=true, labelText="Add Items")]
		[ORKEditorArray(true, "Add Item", "Adds an item to the list.", "", 
			"Remove", "Removes this item from the list.", "", noRemoveCount=1)]
		public ItemGain[] item = new ItemGain[] {new ItemGain()};
		
		public AddToItemBoxStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.all)
			{
				ORK.Game.Scene.AddToItemBox("", this.item);
			}
			else
			{
				ORK.Game.Scene.AddToItemBox(this.name.GetValue(), this.item);
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.all ? "All" : this.name.GetInfoText();
		}
	}
	
	[ORKEditorHelp("Remove Item Box Data", "Removes the stored content of an item box or sets the box empty, using it's box ID.\n" +
		"The box ID can be found in the item collector inspector of the item box in the scene\n" +
		"If not set empty, the item box will be refilled when entering the scene(s) - " +
		"if it's still in the game (e.g. due to variable conditions).", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleStartEvent), typeof(BattleEndEvent))]
	[ORKNodeInfo("Scene Steps", "Inventory Steps")]
	public class RemoveItemBoxDataStep : BaseEventStep
	{
		// scene
		[ORKEditorHelp("All Boxes", "Removes the data from all item boxes.", "")]
		public bool all = false;
		
		[ORKEditorInfo(separator=true, labelText="Box ID")]
		[ORKEditorLayout("all", false, endCheckGroup=true, autoInit=true)]
		public StringValue name = new StringValue();
		
		
		// remove data
		[ORKEditorHelp("Set Empty", "The item box(es) will be set to be empty instead of removed.\n" +
			"The content of the item box wont be refilled when entering the scene(s).\n" +
			"If disabled, the data of the item box will be removed completely and it'll be refilled.", "")]
		[ORKEditorInfo(separator=true)]
		public bool empty = false;
		
		public RemoveItemBoxDataStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.all)
			{
				ORK.Game.Scene.ClearBox("", this.empty);
			}
			else
			{
				ORK.Game.Scene.ClearBox(this.name.GetValue(), this.empty);
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.all ? "All" : this.name.GetInfoText() + 
				(this.empty ? " (empty)" : "");
		}
	}
	
	[ORKEditorHelp("Check Item Box", "Checks the number of items in an item box using it's box ID.\n" +
		"The box ID can be found in the item collector inspector of the item box in the scene.\n" +
		"Requires the item box content saving at least game-wide (i.e. not type 'None').\n" +
		"If the item box doesn't exist, the number of items will be 0.\n" +
		"If the check is valid, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleStartEvent), typeof(BattleEndEvent))]
	[ORKNodeInfo("Scene Steps", "Inventory Steps")]
	public class CheckItemBoxStep : BaseEventCheckStep
	{
		// box
		[ORKEditorInfo(labelText="Box ID")]
		public StringValue name = new StringValue();
		
		
		// check
		[ORKEditorHelp("Check Type", "Checks if the number of items is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the number of items is between two defind values, including the values.\n" +
			"Range exclusive checks if the number of items is between two defined values, excluding the values.\n" +
			"Approximately checks if the number of items is similar to the defined value.", "")]
		[ORKEditorInfo(separator=true)]
		public VariableValueCheck check = VariableValueCheck.IsEqual;
		
		[ORKEditorInfo(separator=true, labelText="Check Value")]
		public EventFloat checkValue = new EventFloat();
		
		[ORKEditorInfo(separator=true, labelText="Check Value 2")]
		[ORKEditorLayout(new string[] {"check", "check"}, 
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive}, 
			needed=Needed.One, endCheckGroup=true, autoInit=true)]
		public EventFloat checkValue2;
		
		public CheckItemBoxStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(ValueHelper.CheckVariableValue(
				ORK.Game.Scene.GetItemBoxQuantity(this.name.GetValue()), 
				this.checkValue.GetValue(baseEvent), 
				this.checkValue2 != null ? this.checkValue2.GetValue(baseEvent) : 0, 
				this.check))
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.name.GetInfoText() + " " + 
				this.check.ToString() + " " + 
				this.checkValue.GetInfoText() + 
				(this.checkValue2 != null ? " ~ " + this.checkValue2.GetInfoText() : "");
		}
	}
	
	[ORKEditorHelp("Check Scene", "Checks if the current scene is a defined scene (name).\n" +
		"If the current scene is the defined scene, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Scene Steps", "Check Steps")]
	public class CheckSceneStep : BaseEventCheckStep
	{
		[ORKEditorInfo(separator=true, labelText="Scene Name")]
		public StringValue name = new StringValue();
		
		public CheckSceneStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(Application.loadedLevelName == this.name.GetValue())
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
	}
	
	[ORKEditorHelp("Navigation Marker", "Adds or removes a navigation marker.\n" +
		"Navigation markers are displayed by navigation HUDs.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Scene Steps")]
	public class NavigationMarkerStep : BaseEventStep
	{
		[ORKEditorHelp("Remove All Markers", "All navigation markers will be removed.", "")]
		public bool removeAll = false;
		
		[ORKEditorHelp("Marker Name", "The name of the marker.\n" +
			"The name is used to identify the marker - " +
			"if you add another marker with the same name, the old marker will be overridden.", "")]
		[ORKEditorLayout("removeAll", false)]
		public string name = "";
		
		[ORKEditorHelp("Remove", "The marker will be removed.", "")]
		public bool remove = false;
		
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("remove", false, endCheckGroup=true, endGroups=2, autoInit=true)]
		public NavigationMarker marker;
		
		public NavigationMarkerStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.removeAll)
			{
				ORK.Game.Scene.ClearNavigationMarkers();
			}
			else if(this.remove)
			{
				ORK.Game.Scene.RemoveNavigationMarker(this.name);
			}
			else
			{
				ORK.Game.Scene.SetNavigationMarker(this.name, this.marker);
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			if(this.removeAll)
			{
				return "Remove All Markers";
			}
			else if(this.remove)
			{
				return "Remove " + this.name;
			}
			else if(this.name != "" && this.marker != null)
			{
				return this.name + (this.marker.sceneName != "" ? " (" + this.marker.sceneName + ")" : "");
			}
			return "";
		}
	}
}
