
using UnityEngine;
using ORKFramework;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.Events
{
	public class ChoiceOption : BaseData
	{
		[ORKEditorInfo(hide=true)]
		public int next = -1;
		
		
		// text/icon
		[ORKEditorInfo(labelText="Choice Text/Icon")]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		public ChoiceLanguageContent[] content = ArrayHelper.CreateArray<ChoiceLanguageContent>(ORK.Languages.Count);
		
		
		// variable conditions
		[ORKEditorHelp("Use Variable Conditions", "A variable condition is used to decide if this choice is available.", "")]
		[ORKEditorInfo("Variable Conditions", "Variable conditions can be used to determine if this choice is displayed.", "")]
		public bool useCondition = false;
		
		[ORKEditorHelp("Variable Origin", "Select the origin of the variables:\n" +
			"- Local: Local variables are only used in a running event and don't interfere with global variables. " +
			"The variable will be gone once the event ends.\n" +
			"- Global: Global variables are persistent and available everywhere, everytime. " +
			"They can be saved in save games.\n" +
			"- Object: Object variables are bound to objects in the scene by an object ID. " +
			"They can be saved in save games.", "")]
		[ORKEditorLayout("useCondition", true)]
		public VariableOrigin origin = VariableOrigin.Global;
		
		// object variables
		[ORKEditorHelp("Use Object", "Use the 'Object Variables' component of game objects to check the object variables.\n" +
			"The check will be made on every 'Object Variables' component that is found. " +
			"If no component is found, the check failed.\n" +
			"If disabled, you need to define the object ID used to check the object variables.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("origin", VariableOrigin.Object)]
		public bool useObject = true;
		
		[ORKEditorInfo(separator=true, labelText="Object")]
		[ORKEditorLayout("useObject", true, autoInit=true)]
		public EventObjectSetting fromObject;
		
		[ORKEditorHelp("Object ID", "Define the object ID of the object variables.\n" +
			"If the object ID doesn't exist yet, it will be created - usually resulting in a failed check.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, endGroups=2)]
		public string objectID = "";
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public VariableCondition condition = new VariableCondition();
		
		
		// quest conditions
		[ORKEditorHelp("Use Quest Conditions", "Quest or task status conditions are used to decide if this choice is available.", "")]
		[ORKEditorInfo("Quest Conditions", "Quest and task status conditions can be used to " +
			"determine if this choice is displayed.", "")]
		public bool useQuestCondition = false;
		
		[ORKEditorInfo(endFoldout=true, separator=true)]
		[ORKEditorLayout("useQuestCondition", true, endCheckGroup=true, autoInit=true)]
		public QuestCondition questCondition;
		
		
		// status requirements
		[ORKEditorHelp("Use Status Requirements", "Status requirements are used to decide if this choice is available.", "")]
		[ORKEditorInfo("Status Requirements", "Status requirements can be used to determine if this choice is displayed.", "")]
		public bool useStatusRequirements = false;
		
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("useStatusRequirements", true, autoInit=true)]
		public EventObjectSetting statusObject;
		
		[ORKEditorHelp("Needed", "Either all or only one requirement must be met.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75)]
		public Needed statReqNeeded = Needed.All;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add Status Requirement", "Adds a status requirement.", "", 
			"Remove", "Removes the status requirement", "", isCopy=true, isMove=true, 
			foldout=true, foldoutText=new string[] {
				"Status Requirement", "Define the status requirement that must be valid.", ""
		})]
		[ORKEditorLayout(endCheckGroup=true)]
		public StatusRequirement[] statusRequirement = new StatusRequirement[0];
		
		
		// item
		[ORKEditorHelp("Add Item", "An item, weapon or armor is added to the inventory if this choice is selected.", "")]
		[ORKEditorInfo("Add Item Settings", "Selecthing this choice can automatically add an " +
			"item, weaon, armor or currency to the player's inventory.", "")]
		public bool addItem = false;
		
		[ORKEditorLayout("addItem", true, endCheckGroup=true)]
		[ORKEditorInfo(endFoldout=true, callbackAfter="info:choiceitem")]
		public ItemGain item = new ItemGain();
		
		public ChoiceOption()
		{
			
		}
		
		public ChoiceContent GetContent(BaseEvent baseEvent)
		{
			ChoiceContent cc = this.content[ORK.Game.Language].GetChoiceContent(baseEvent);
			if(this.addItem && cc.Content != null && 
				cc.Content.text != "")
			{
				cc.Content.text = cc.Content.text.
					Replace("%n", this.item.GetName()).
					Replace("%", this.item.quantity.ToString());
			}
			return cc;
		}
		
		
		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool Available(BaseEvent baseEvent)
		{
			return this.CheckVariableConditions(baseEvent) && 
				this.CheckQuestConditions() && 
				this.CheckStatusRequirements(baseEvent);
		}
		
		public bool CheckVariableConditions(BaseEvent baseEvent)
		{
			VariableHandler handler = null;
			if(this.useCondition)
			{
				if(VariableOrigin.Local.Equals(this.origin))
				{
					handler = baseEvent.Variables;
				}
				else if(VariableOrigin.Global.Equals(this.origin))
				{
					handler = ORK.Game.Variables;
				}
				else if(VariableOrigin.Object.Equals(this.origin))
				{
					if(this.useObject)
					{
						List<GameObject> list = this.fromObject.GetObject(baseEvent);
						for(int i=0; i<list.Count; i++)
						{
							if(list[i] != null)
							{
								ObjectVariablesComponent comp = list[i].GetComponentInChildren<ObjectVariablesComponent>();
								if(comp != null)
								{
									handler = comp.GetHandler();
								}
							}
						}
					}
					else
					{
						handler = ORK.Game.Scene.GetObjectVariables(this.objectID);
					}
				}
			}
			
			return !this.useCondition || (handler != null && this.condition.CheckVariables(handler));
		}
		
		public bool CheckQuestConditions()
		{
			return !this.useQuestCondition || this.questCondition.Check();
		}
		
		public bool CheckStatusRequirements(BaseEvent baseEvent)
		{
			return !this.useStatusRequirements || StatusRequirement.Check(
				ComponentHelper.GetFirstCombatant(this.statusObject.GetObject(baseEvent)), 
				this.statusRequirement, this.statReqNeeded);
		}
	}
}
