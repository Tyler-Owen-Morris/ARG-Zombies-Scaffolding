
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Set String PlayerPrefs", "Sets a string value to a PlayerPrefs variable.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("PlayerPrefs Steps")]
	public class SetStringPlayerPrefsStep : BaseEventStep
	{
		[ORKEditorInfo(labelText="PlayerPrefs Variable")]
		public StringValue key = new StringValue();
		
		[ORKEditorInfo(separator=true, labelText="String Value")]
		public StringValue value = new StringValue();
		
		public SetStringPlayerPrefsStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			PlayerPrefs.SetString(this.key.GetValue(), this.value.GetValue());
			PlayerPrefs.Save();
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Set Int PlayerPrefs", "Sets an integer value to a PlayerPrefs variable.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("PlayerPrefs Steps")]
	public class SetIntPlayerPrefsStep : BaseEventStep
	{
		[ORKEditorInfo(labelText="PlayerPrefs Variable")]
		public StringValue key = new StringValue();
		
		[ORKEditorInfo(separator=true, labelText="Integer Value")]
		public EventInteger value = new EventInteger();
		
		public SetIntPlayerPrefsStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			PlayerPrefs.SetInt(this.key.GetValue(), this.value.GetValue(baseEvent));
			PlayerPrefs.Save();
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Set Float PlayerPrefs", "Sets a float value to a PlayerPrefs variable.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("PlayerPrefs Steps")]
	public class SetFloatPlayerPrefsStep : BaseEventStep
	{
		[ORKEditorInfo(labelText="PlayerPrefs Variable")]
		public StringValue key = new StringValue();
		
		[ORKEditorInfo(separator=true, labelText="Float Value")]
		public EventFloat value = new EventFloat();
		
		public SetFloatPlayerPrefsStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			PlayerPrefs.SetFloat(this.key.GetValue(), this.value.GetValue(baseEvent));
			PlayerPrefs.Save();
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Remove PlayerPrefs", "Removes a PlayerPrefs variable.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("PlayerPrefs Steps")]
	public class RemovePlayerPrefsStep : BaseEventStep
	{
		[ORKEditorHelp("Remove All", "All PlayerPrefs variables are removed.\n" +
			"If disabled, only a selected PlayerPrefs variable will be removed.", "")]
		public bool all = false;
		
		[ORKEditorInfo(separator=true, labelText="PlayerPrefs Variable")]
		[ORKEditorLayout("all", false, endCheckGroup=true, autoInit=true)]
		public StringValue key;
		
		public RemovePlayerPrefsStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.all)
			{
				PlayerPrefs.DeleteAll();
			}
			else
			{
				PlayerPrefs.DeleteKey(this.key.GetValue());
			}
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Has PlayerPrefs", "Checks if a PlayerPrefs variable exists.\n" +
		"If the check is true, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("PlayerPrefs Steps", "Check Steps")]
	public class HasPlayerPrefsStep : BaseEventCheckStep
	{
		[ORKEditorInfo(separator=true, labelText="PlayerPrefs Variable")]
		public StringValue key = new StringValue();
		
		public HasPlayerPrefsStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(PlayerPrefs.HasKey(this.key.GetValue()))
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
	}
}
