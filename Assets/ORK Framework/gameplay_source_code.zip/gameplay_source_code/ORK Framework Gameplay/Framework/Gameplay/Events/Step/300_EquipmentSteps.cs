
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Change Equipment", "Changes the equipment of a combatant.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Equipment Steps")]
	public class ChangeEquipmentStep : BaseEventStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will change equipment.\n" +
			"If the actor doesn't have a combatant, no one will change equipment.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorHelp("Unequip All", "All equipment of the combatant will be unequipped.", "")]
		public bool all = false;
		
		[ORKEditorHelp("Equipment Part", "Select the equipment part that will be changed.", "")]
		[ORKEditorInfo(ORKDataType.EquipmentPart)]
		[ORKEditorLayout("all", false)]
		public int id2 = 0;
		
		[ORKEditorHelp("Equip", "Select how the equipment part will be changed:\n" +
			"- None: The equipment part will be unequipped.\n" +
			"- Weapon: A weapon will be equipped.\n" +
			"- Armor: An armor will be equipped.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public EquipSet equip = EquipSet.None;
		
		[ORKEditorHelp("Equipment", "Select the equipment that will be equipped.", "")]
		[ORKEditorInfo(isPopup=true, itemFieldName="equip")]
		[ORKEditorLayout("equip", EquipSet.None, elseCheckGroup=true, endCheckGroup=true)]
		public int id3 = 0;
		
		[ORKEditorHelp("Level", "Select the level of the equipment.\n" +
			"If the level exceeds the maximum level of the equipment, the maximum level is used.", "")]
		[ORKEditorLimit(1, false)]
		[ORKEditorLayout(endCheckGroup=true)]
		public int lvl = 1;
		
		public ChangeEquipmentStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					if(this.all)
					{
						list[i].Equipment.UnequipAll(list[i].Inventory);
					}
					else
					{
						if(EquipSet.None.Equals(this.equip))
						{
							list[i].Equipment.Unequip(this.id2, list[i].Inventory, true);
						}
						else
						{
							list[i].Equipment.Equip(this.id2, 
								new EquipShortcut(this.equip, this.id3, this.lvl, 1), 
								null, true);
						}
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Check Equipment", "Checks the equipment of a combatant.\n" +
		"If the check is true, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Equipment Steps", "Check Steps")]
	public class CheckEquipmentStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will be checked.\n" +
			"If the actor doesn't have a combatant, next step fail will be executed.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorHelp("Equipment Part", "Select the equipment part that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.EquipmentPart)]
		public int id2 = 0;
		
		[ORKEditorHelp("Equip", "Select how the equipment part will be checked:\n" +
			"- None: The equipment part has to be unequipped.\n" +
			"- Weapon: A weapon has to be equipped.\n" +
			"- Armor: An armor has to be equipped.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public EquipSet equip = EquipSet.None;
		
		[ORKEditorHelp("Check Equipment Part", "Checks the equipment part to be " +
			"equipped with a weapon or equipped with an armor - doesn't check for a specific equipment.\n" +
			"If disabled, you'll have to define the weapon/armor that should be checked for.", "")]
		[ORKEditorLayout("equip", EquipSet.None, elseCheckGroup=true)]
		public bool checkPart = false;
		
		[ORKEditorHelp("Equipment", "Select the equipment that will be checked for.", "")]
		[ORKEditorInfo(isPopup=true, itemFieldName="equip")]
		[ORKEditorLayout("checkPart", false, endCheckGroup=true, endGroups=2)]
		public int id3 = 0;
		
		public CheckEquipmentStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			bool check = false;
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					if((EquipSet.None.Equals(this.equip) && !list[i].Equipment[this.id2].Equipped) ||
						(!EquipSet.None.Equals(this.equip) && list[i].Equipment[this.id2].Equipped && 
							list[i].Equipment[this.id2].Equipment.Type.Equals(this.equip) && 
							(this.checkPart || list[i].Equipment[this.id2].Equipment.ID == this.id3)))
					{
						check = true;
						break;
					}
				}
			}
			if(check)
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.EquipmentParts.GetName(this.id2);
		}
	}
	
	[ORKEditorHelp("Equipment Fork", "Checks a selected equipment part of a combatant.\n" +
		"If an equipment condition is valid, it's next step will be executed.\n" +
		"If no condition is valid, 'Failed' will be executed.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Equipment Steps", "Check Steps")]
	public class EquipmentForkStep : BaseEventStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will be checked.\n" +
			"If the actor doesn't have a combatant, next step fail will be executed.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorHelp("Equipment Part", "Select the equipment part that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.EquipmentPart)]
		public int id2 = 0;
		
		
		// checks
		[ORKEditorArray(false, "Add Check", "Adds a new equipment condition.", "", 
			"Remove", "Removes the equipment condition.", "", isMove=true, isCopy=true, 
			noRemoveCount=1, foldout=true, foldoutText=new string[] {
				"Equipment Condition", "Define the game variable condition that must be valid.", ""
		})]
		public EquipmentConditionNextNode[] condition = new EquipmentConditionNextNode[] {new EquipmentConditionNextNode()};
		
		public EquipmentForkStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			int check = this.next;
			
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i=0; i<list.Count; i++)
			{
				bool found = false;
				if(list[i] != null)
				{
					for(int j=0; j<this.condition.Length; j++)
					{
						if((EquipSet.None.Equals(this.condition[j].equip) && 
								!list[i].Equipment[this.id2].Equipped) ||
							(!EquipSet.None.Equals(this.condition[j].equip) && 
								list[i].Equipment[this.id2].Equipped && 
								list[i].Equipment[this.id2].Equipment.Type.Equals(this.condition[j].equip) && 
								list[i].Equipment[this.id2].Equipment.ID == this.condition[j].id))
						{
							check = this.condition[j].next;
							found = true;
							break;
						}
					}
				}
				if(found)
				{
					break;
				}
			}
			
			baseEvent.StepFinished(check);
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.EquipmentParts.GetName(this.id2);
		}
		
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Failed";
			}
			else if(index > 0)
			{
				return "Condition " + (index - 1) + ": " + this.condition[index - 1].GetInfoText();
			}
			return "";
		}
		
		public override int GetNextCount()
		{
			return this.condition.Length + 1;
		}
		
		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index > 0)
			{
				return this.condition[index - 1].next;
			}
			return -1;
		}
		
		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index > 0)
			{
				this.condition[index - 1].next = next;
			}
		}
	}
	
	[ORKEditorHelp("Lock Equipment Part", "Locks or unlocks an equipment part of a combatant.\n" +
		"Locked equipment parts can't change equipment.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Equipment Steps")]
	public class LockEquipmentPartStep : BaseEventStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will lock/unlock an equipment part.\n" +
			"If the actor doesn't have a combatant, no one will lock/unlock an equipment part.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorHelp("Lock All", "All equipment parts of the combatant will be locked/unlocked.", "")]
		public bool all = false;
		
		[ORKEditorHelp("Equipment Part", "Select the equipment part that will be locked/unlocked.", "")]
		[ORKEditorInfo(ORKDataType.EquipmentPart)]
		[ORKEditorLayout("all", false, endCheckGroup=true)]
		public int id2 = 0;
		
		[ORKEditorHelp("Lock/Unlock", "If enabled, the equipment part will be locked.\n" +
			"If disabled, the equipment part will be unlocked.", "")]
		public bool lockPart = true;
		
		public LockEquipmentPartStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					if(this.all)
					{
						list[i].Equipment.LockAll(this.lockPart);
					}
					else
					{
						list[i].Equipment[this.id2].Locked = this.lockPart;
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.all ? "All" : ORK.EquipmentParts.GetName(this.id2);
		}
	}
	
	[ORKEditorHelp("Check Part Locked", "Checks if an equipment part of a combatant is locked.\n" +
		"If the equipment part is locked, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Equipment Steps", "Check Steps")]
	public class CheckPartLockedStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will be checked.\n" +
			"If the actor doesn't have a combatant, next step fail will be executed.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorHelp("Equipment Part", "Select the equipment part that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.EquipmentPart)]
		public int id2 = 0;
		
		public CheckPartLockedStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			bool check = false;
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					if(list[i].Equipment[this.id2].Locked)
					{
						check = true;
						break;
					}
				}
			}
			if(check)
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.EquipmentParts.GetName(this.id2);
		}
	}
	
	[ORKEditorHelp("Check Part Available", "Checks if an equipment part of a combatant is available.\n" +
		"An equipment part is available when a combatant can equip a weapon or armor on it (ignoring locked state) - " +
		"i.e. the equipment part either comes from combatant/class settings or " +
		"was made available by events, items, abilities, equipment or status effects." +
		"If the equipment part is available, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Equipment Steps", "Check Steps")]
	public class CheckPartAvailableStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will be checked.\n" +
			"If the actor doesn't have a combatant, next step fail will be executed.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorHelp("Equipment Part", "Select the equipment part that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.EquipmentPart)]
		public int id2 = 0;
		
		public CheckPartAvailableStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			bool check = false;
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					if(list[i].Equipment[this.id2].Available)
					{
						check = true;
						break;
					}
				}
			}
			if(check)
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.EquipmentParts.GetName(this.id2);
		}
	}
	
	[ORKEditorHelp("Change Equipment Part", "Adds or removes an equipment part to/from a combatant.\n" +
		"This can be used to add extra equipment parts that aren't available due to combatant/class settings.\n" +
		"When removing, only previously added equipment parts can be removed - " +
		"to remove an equipment part granted by combatant/class settings, use the 'Change Blocked Part' step.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Equipment Steps")]
	public class ChangeEquipmentPartStep : BaseEventStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will change equipment parts.\n" +
			"If the actor doesn't have a combatant, no one will change equipment parts.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorHelp("Equipment Part", "Select the equipment part that will be changed.", "")]
		[ORKEditorInfo(ORKDataType.EquipmentPart)]
		public int id2 = 0;
		
		[ORKEditorHelp("Change", "Select if an equipment part is added or removed.", "")]
		public SimpleChangeType change = SimpleChangeType.Add;
		
		public ChangeEquipmentPartStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					if(SimpleChangeType.Add.Equals(this.change))
					{
						list[i].Equipment.AddEquipmentPart(this.id2);
					}
					else if(SimpleChangeType.Remove.Equals(this.change))
					{
						list[i].Equipment.RemoveEquipmentPart(this.id2);
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.change.ToString() + " " + ORK.EquipmentParts.GetName(this.id2);
		}
	}
	
	[ORKEditorHelp("Change Blocked Part", "Adds or removes a blocked equipment part to/from a combatant.\n" +
		"A blocked part isn't available to the combatant and will automatically unequip its equipment.\n" +
		"This can be used to remove equipment parts granted by combatant/class settings.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Equipment Steps")]
	public class ChangeBlockedPartStep : BaseEventStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will change blocked equipment parts.\n" +
			"If the actor doesn't have a combatant, no one will change blocked equipment parts.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorHelp("Equipment Part", "Select the equipment part that will be changed.", "")]
		[ORKEditorInfo(ORKDataType.EquipmentPart)]
		public int id2 = 0;
		
		[ORKEditorHelp("Change", "Select if a blocked equipment part is added or removed.", "")]
		public SimpleChangeType change = SimpleChangeType.Add;
		
		public ChangeBlockedPartStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					if(SimpleChangeType.Add.Equals(this.change))
					{
						list[i].Equipment.AddBlockedEquipmentPart(this.id2);
					}
					else if(SimpleChangeType.Remove.Equals(this.change))
					{
						list[i].Equipment.RemoveBlockedEquipmentPart(this.id2);
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.change.ToString() + " " + ORK.EquipmentParts.GetName(this.id2);
		}
	}
	
	[ORKEditorHelp("Change Equip Durability", "Changes the durability of an equipment " +
		"currently equipped on an equipment part (or all parts) of a combatant.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Equipment Steps")]
	public class ChangeEquipDurabilityStep : BaseEventStep
	{
		[ORKEditorHelp("All Parts", "Change the durability on all currently equipped equipment.\n" +
			"If disabled, only the equipment of a selected equipment part will be changed.", "")]
		public bool allParts = false;
		
		[ORKEditorHelp("Equipment Part", "Select the equipment part that will be changed.", "")]
		[ORKEditorInfo(ORKDataType.EquipmentPart)]
		[ORKEditorLayout("allParts", false, endCheckGroup=true)]
		public int partID = 0;
		
		
		// change by
		[ORKEditorHelp("Reset To Max", "Resets the durability to it's maximum.", "")]
		[ORKEditorInfo(separator=true, labelText="Durability Change")]
		public bool reset = false;
		
		[ORKEditorLayout("reset", false)]
		public EventFloat value = new EventFloat();
		
		[ORKEditorHelp("Operator", "Select how the durability will be changed:\n" +
			"- Add: The value will be added to the current durability.\n" +
			"- Sub: The value will be subtracted from the current durability.\n" +
			"- Set: The durability will be set to the value.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50)]
		[ORKEditorLayout(endCheckGroup=true)]
		public SimpleOperator op = SimpleOperator.Add;
		
		
		// object
		[ORKEditorInfo(separator=true, labelText="Used Object")]
		public EventObjectSetting usedObject = new EventObjectSetting();
		
		public ChangeEquipDurabilityStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			float tmpValue = this.reset ? 0 : this.value.GetValue(baseEvent);
			
			List<Combatant> list = this.usedObject.GetCombatant(baseEvent);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					if(this.allParts)
					{
						for(int j=0; j<ORK.EquipmentParts.Count; j++)
						{
							this.Change(list[i], tmpValue, j);
						}
					}
					else
					{
						this.Change(list[i], tmpValue, this.partID);
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		private void Change(Combatant combatant, float value, int index)
		{
			if(combatant.Equipment[index].Equipped && 
				combatant.Equipment[index].Equipment != null)
			{
				if(this.reset)
				{
					combatant.Equipment[index].Equipment.ResetDurability(combatant);
				}
				else
				{
					combatant.Equipment[index].Equipment.ChangeDurability(
						combatant, value, this.op);
				}
			}
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.usedObject.GetInfoText() + ": " +
				(this.allParts ? 
						"All Parts " : 
						ORK.EquipmentParts.GetName(this.partID) + " ") + 
				(this.reset ? 
						"Reset" : 
						this.op.ToString() + " " + this.value.GetInfoText());
		}
	}
	
	[ORKEditorHelp("Check Equip Durability", "Checks the durability of an equipment " +
		"currently equipped on an equipment part (or all parts) of a combatant.\n" +
		"Only equipment that uses durability will be checked." +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Equipment Steps", "Check Steps")]
	public class CheckEquipDurabilityStep : BaseEventCheckStep
	{
		[ORKEditorHelp("All Parts", "Check the durability on all currently equipped equipment.\n" +
			"If disabled, only the equipment of a selected equipment part will be checked.", "")]
		public bool allParts = false;
		
		[ORKEditorHelp("Needed", "Either all or only one equipment's check must be valid.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout("allParts", true)]
		public Needed needed = Needed.One;
		
		[ORKEditorHelp("Equipment Part", "Select the equipment part that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.EquipmentPart)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int partID = 0;
		
		
		// check by
		[ORKEditorHelp("Check", "Check if the durability is equal, not equal, less or greater than the defined value.\n" +
			"Range inclusive checks if the durability is between two defind values, including the values.\n" +
			"Range exclusive checks if the durability is between two defined values, excluding the values.\n" +
			"Approximately checks if the durability is similar to the defined value.", "")]
		[ORKEditorInfo(separator=true, labelText="Check Settings")]
		public VariableValueCheck check = VariableValueCheck.IsEqual;
		
		[ORKEditorInfo(labelText="Check Value", separator=true)]
		public EventFloat value = new EventFloat();
		
		[ORKEditorInfo(labelText="Check Value 2", separator=true)]
		[ORKEditorLayout(new string[] {"check", "check"}, 
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive}, 
			needed=Needed.One, endCheckGroup=true, autoInit=true)]
		public EventFloat value2;
		
		
		// object
		[ORKEditorInfo(separator=true, labelText="Used Object")]
		public EventObjectSetting usedObject = new EventObjectSetting();
		
		[ORKEditorHelp("Needed", "Either all or only one combatant's check must be valid.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public Needed neededCom = Needed.One;
		
		public CheckEquipDurabilityStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			bool valid = false;
			float tmpValue = this.value.GetValue(baseEvent);
			float tmpValue2 = this.value2 != null ? this.value2.GetValue(baseEvent) : 0;
			
			List<Combatant> list = this.usedObject.GetCombatant(baseEvent);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					if(this.allParts)
					{
						if(this.CheckDurability(list[i], tmpValue, tmpValue2))
						{
							valid = true;
							if(Needed.One.Equals(this.neededCom))
							{
								break;
							}
						}
						else if(Needed.All.Equals(this.neededCom))
						{
							valid = false;
							break;
						}
					}
					else if(list[i].Equipment[this.partID].Equipped && 
						list[i].Equipment[this.partID].Equipment != null && 
						list[i].Equipment[this.partID].Equipment.Durability != -1)
					{
						if(ValueHelper.CheckVariableValue(
							list[i].Equipment[this.partID].Equipment.Durability, 
							tmpValue, tmpValue2, this.check))
						{
							valid = true;
							if(Needed.One.Equals(this.neededCom))
							{
								break;
							}
						}
						else if(Needed.All.Equals(this.neededCom))
						{
							valid = false;
							break;
						}
					}
				}
			}
			
			if(valid)
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		private bool CheckDurability(Combatant combatant, float tmpValue, float tmpValue2)
		{
			for(int i=0; i<ORK.EquipmentParts.Count; i++)
			{
				if(combatant.Equipment[i].Equipped && 
					combatant.Equipment[i].Equipment != null && 
					combatant.Equipment[i].Equipment.Durability != -1)
				{
					if(ValueHelper.CheckVariableValue(
						combatant.Equipment[i].Equipment.Durability, 
						tmpValue, tmpValue2, this.check))
					{
						if(Needed.One.Equals(this.needed))
						{
							return true;
						}
					}
					else if(Needed.All.Equals(this.needed))
					{
						return false;
					}
				}
			}
			return Needed.All.Equals(this.needed);
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.usedObject.GetInfoText() + ": " +
				(this.allParts ? 
						"All Parts " : 
						ORK.EquipmentParts.GetName(this.partID) + " ") + 
				this.check.ToString() + " " + this.value.GetInfoText() +
				(this.value2 != null ? " - " + this.value2.GetInfoText() : "");
		}
	}
	
	[ORKEditorHelp("Change Inventory Durability", "Changes the durability of equipment " +
		"currently placed in the inventory of a combatant.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Equipment Steps", "Inventory Steps")]
	public class ChangeInventoryDurabilityStep : BaseEventStep
	{
		[ORKEditorHelp("Weapons", "Change the durability of weapons.", "")]
		public bool weapons = true;
		
		[ORKEditorHelp("Armors", "Change the durability of armors.", "")]
		public bool armors = true;
		
		[ORKEditorHelp("Any Part", "Change the durability of equipment that can be equipped on any equipment part.\n" +
			"If disabled, only equipment that can be equipped on a selected equipment part will be changed.", "")]
		public bool anyPart = false;
		
		[ORKEditorHelp("Equipment Part", "Select the equipment part the equipment can be equipped on.", "")]
		[ORKEditorInfo(ORKDataType.EquipmentPart)]
		[ORKEditorLayout("anyPart", false, endCheckGroup=true)]
		public int partID = 0;
		
		
		// change by
		[ORKEditorHelp("Reset To Max", "Resets the durability to it's maximum.", "")]
		[ORKEditorInfo(separator=true, labelText="Durability Change")]
		public bool reset = false;
		
		[ORKEditorLayout("reset", false)]
		public EventFloat value = new EventFloat();
		
		[ORKEditorHelp("Operator", "Select how the durability will be changed:\n" +
			"- Add: The value will be added to the current durability.\n" +
			"- Sub: The value will be subtracted from the current durability.\n" +
			"- Set: The durability will be set to the value.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50)]
		[ORKEditorLayout(endCheckGroup=true)]
		public SimpleOperator op = SimpleOperator.Add;
		
		
		// object
		[ORKEditorInfo(separator=true, labelText="Used Object")]
		public EventObjectSetting usedObject = new EventObjectSetting();
		
		public ChangeInventoryDurabilityStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			float tmpValue = this.reset ? 0 : this.value.GetValue(baseEvent);
			
			List<EquipShortcut> changed = new List<EquipShortcut>();
			List<Combatant> list = this.usedObject.GetCombatant(baseEvent);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					List<EquipShortcut> equip = list[i].Inventory.GetEquipmentByPart(
						this.anyPart ? -1 : this.partID, this.weapons, this.armors);
					for(int j=0; j<equip.Count; j++)
					{
						if(!changed.Contains(equip[j]))
						{
							if(this.reset)
							{
								equip[j].ResetDurability(list[i]);
							}
							else
							{
								equip[j].ChangeDurability(list[i], tmpValue, this.op);
							}
							changed.Add(equip[j]);
						}
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.usedObject.GetInfoText() + ": " +
				(this.anyPart ? 
						"Any Part " : 
						ORK.EquipmentParts.GetName(this.partID) + " ") + 
				(this.reset ? 
						"Reset" : 
						this.op.ToString() + " " + this.value.GetInfoText());
		}
	}
	
	[ORKEditorHelp("Check Inventory Durability", "Checks the durability of equipment " +
		"currently placed in the inventory of a combatant.\n" +
		"Only equipment that uses durability will be checked." +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Equipment Steps", "Inventory Steps", "Check Steps")]
	public class CheckInventoryDurabilityStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Weapons", "Check the durability of weapons.", "")]
		public bool weapons = true;
		
		[ORKEditorHelp("Armors", "Check the durability of armors.", "")]
		public bool armors = true;
		
		[ORKEditorHelp("Any Part", "Check the durability of equipment that can be equipped on any equipment part.\n" +
			"If disabled, only equipment that can be equipped on a selected equipment part will be checked.", "")]
		public bool anyPart = false;
		
		[ORKEditorHelp("Equipment Part", "Select the equipment part that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.EquipmentPart)]
		[ORKEditorLayout("anyPart", false, endCheckGroup=true)]
		public int partID = 0;
		
		[ORKEditorHelp("Needed", "Either all or only one equipment's check must be valid.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public Needed needed = Needed.One;
		
		
		// check by
		[ORKEditorHelp("Check", "Check if the durability is equal, not equal, less or greater than the defined value.\n" +
			"Range inclusive checks if the durability is between two defind values, including the values.\n" +
			"Range exclusive checks if the durability is between two defined values, excluding the values.\n" +
			"Approximately checks if the durability is similar to the defined value.", "")]
		[ORKEditorInfo(separator=true, labelText="Check Settings")]
		public VariableValueCheck check = VariableValueCheck.IsEqual;
		
		[ORKEditorInfo(labelText="Check Value", separator=true)]
		public EventFloat value = new EventFloat();
		
		[ORKEditorInfo(labelText="Check Value 2", separator=true)]
		[ORKEditorLayout(new string[] {"check", "check"}, 
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive}, 
			needed=Needed.One, endCheckGroup=true, autoInit=true)]
		public EventFloat value2;
		
		
		// object
		[ORKEditorInfo(separator=true, labelText="Used Object")]
		public EventObjectSetting usedObject = new EventObjectSetting();
		
		[ORKEditorHelp("Needed", "Either all or only one combatant's check must be valid.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public Needed neededCom = Needed.One;
		
		public CheckInventoryDurabilityStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			bool valid = false;
			float tmpValue = this.value.GetValue(baseEvent);
			float tmpValue2 = this.value2 != null ? this.value2.GetValue(baseEvent) : 0;
			
			List<Combatant> list = this.usedObject.GetCombatant(baseEvent);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					if(this.CheckDurability(list[i], tmpValue, tmpValue2))
					{
						valid = true;
						if(Needed.One.Equals(this.neededCom))
						{
							break;
						}
					}
					else if(Needed.All.Equals(this.neededCom))
					{
						valid = false;
						break;
					}
				}
			}
			
			if(valid)
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		private bool CheckDurability(Combatant combatant, float tmpValue, float tmpValue2)
		{
			List<EquipShortcut> equip = combatant.Inventory.GetEquipmentByPart(
				this.anyPart ? -1 : this.partID, this.weapons, this.armors);
			for(int i=0; i<equip.Count; i++)
			{
				if(equip[i].Durability != -1)
				{
					if(ValueHelper.CheckVariableValue(equip[i].Durability, 
						tmpValue, tmpValue2, this.check))
					{
						if(Needed.One.Equals(this.needed))
						{
							return true;
						}
					}
					else if(Needed.All.Equals(this.needed))
					{
						return false;
					}
				}
			}
			return Needed.All.Equals(this.needed);
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.usedObject.GetInfoText() + ": " +
				(this.anyPart ? 
						"Any Part " : 
						ORK.EquipmentParts.GetName(this.partID) + " ") + 
				this.check.ToString() + " " + this.value.GetInfoText() +
				(this.value2 != null ? " - " + this.value2.GetInfoText() : "");
		}
	}
}
