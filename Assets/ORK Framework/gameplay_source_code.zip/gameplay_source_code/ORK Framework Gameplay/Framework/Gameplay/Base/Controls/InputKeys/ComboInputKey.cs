
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ComboInputKey : BaseData
	{
		[ORKEditorHelp("Input Key", "Select the input key used for this combo key.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int inputKeyID = 0;
		
		[ORKEditorHelp("Timeout (s)", "Select the time in seconds the player has to press the next combo key.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float timeout = 1;
		
		
		// ignore keys
		[ORKEditorHelp("Ignore Input Key", "Select the input key that will be ignored " +
			"while waiting for this combo key to be pressed.", "")]
		[ORKEditorInfo(ORKDataType.InputKey, separator=true, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Ignore Input Key", "Adds an input key that will be ignored.", "",
			"Remove", "Removes this input key.", "", isHorizontal=true)]
		public int[] ignoreKeyID = new int[0];
		
		
		// in-game
		private List<int> ignore;
		
		public ComboInputKey()
		{
			
		}
		
		public bool GetButton()
		{
			return ORK.InputKeys.Get(this.inputKeyID).GetButton();
		}
		
		public bool OtherButton(int parentKeyID)
		{
			if(this.ignore == null)
			{
				this.ignore = new List<int>();
				this.ignore.Add(parentKeyID);
				this.ignore.Add(this.inputKeyID);
				if(this.ignoreKeyID.Length > 0)
				{
					this.ignore.AddRange(this.ignoreKeyID);
				}
			}
			
			for(int i=0; i<ORK.InputKeys.Count; i++)
			{
				if(!this.ignore.Contains(i) && 
					ORK.InputKeys.Get(i).GetButton())
				{
					return true;
				}
			}
			return false;
		}
	}
}
