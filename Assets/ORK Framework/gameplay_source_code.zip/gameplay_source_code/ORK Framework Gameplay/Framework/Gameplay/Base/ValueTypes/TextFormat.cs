
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public struct TextFormat : IBaseData
	{
		[ORKEditorHelp("Text Color", "The color used for the text.", "")]
		[ORKEditorInfo(ORKDataType.Color)]
		public int colorID;
		
		
		// shadow
		[ORKEditorHelp("Show Shadow", "A shadow is displayed for the text.", "")]
		[ORKEditorInfo(separator=true, labelText="Shadow Settings")]
		public bool showShadow;
		
		[ORKEditorHelp("Shadow Color", "The color used for the text shadow.", "")]
		[ORKEditorInfo(ORKDataType.Color)]
		[ORKEditorLayout("showShadow", true)]
		public int shadowColorID;
		
		[ORKEditorHelp("Shadow Offset", "The offset of the shadow to the text.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public Vector2 shadowOffset;
		
		
		// outline
		[ORKEditorHelp("Show Outline", "An outline is displayed around the text.", "")]
		[ORKEditorInfo(separator=true, labelText="Outline Settings")]
		[ORKEditorLayout("gui:newui")]
		public bool showOutline;
		
		[ORKEditorHelp("Outline Color", "The color used for the text outline.", "")]
		[ORKEditorInfo(ORKDataType.Color)]
		[ORKEditorLayout("showOutline", true)]
		public int outlineColorID;
		
		[ORKEditorHelp("Outline Offset", "The offset of the outline to the text.", "")]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2)]
		public Vector2 outlineOffset;
		
		
		// font
		[ORKEditorHelp("Font", "Select the font that will be used.\n" +
			"The default font will be used if none is selected.", "")]
		[ORKEditorInfo(separator=true, labelText="Font Settings")]
		public Font font;
		
		[ORKEditorHelp("Font Size", "The font size that will be used.", "")]
		[ORKEditorLimit(0, false)]
		public int fontSize;
		
		[ORKEditorHelp("Font Style", "Select the font style that will be used.", "")]
		public FontStyle fontStyle;
		
		public TextFormat(int colorID, int shadowColorID)
		{
			this.colorID = colorID;
			
			// shadow
			this.shadowColorID = shadowColorID;
			this.showShadow = this.shadowColorID >= 0;
			this.shadowOffset = new Vector2(1, 1);
			
			// outline
			this.outlineColorID = shadowColorID;
			this.showOutline = this.outlineColorID >= 0;
			this.outlineOffset = new Vector2(1, 1);
			
			// font
			this.font = null;
			this.fontSize = 20;
			this.fontStyle = FontStyle.Normal;
		}
		
		
		/*
		============================================================================
		Static text colors
		============================================================================
		*/
		public static TextFormat Default
		{
			get{ return new TextFormat(0, 1);}
		}
		
		
		/*
		============================================================================
		Color functions
		============================================================================
		*/
		public Color GetTextColor()
		{
			return ORK.Colors.Get(this.colorID).color;
		}
		
		public Color GetShadowColor()
		{
			return ORK.Colors.Get(this.shadowColorID).color;
		}
		
		public Color GetOutlineColor()
		{
			return ORK.Colors.Get(this.outlineColorID).color;
		}
		
		
		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public Rect GetShadowRect(Vector2 position, Vector2 size)
		{
			return new Rect(position.x + this.shadowOffset.x, position.y + this.shadowOffset.y, size.x, size.y);
		}
		
		public void Show(GUIContent content, Rect bounds)
		{
			GUIStyle guiStyle = new GUIStyle("label");
			if(this.font != null)
			{
				guiStyle.font = this.font;
			}
			guiStyle.fontSize = this.fontSize;
			guiStyle.fontStyle = this.fontStyle;
			
			if(this.showShadow && content.text != null && content.text != "")
			{
				guiStyle.normal.textColor = ORK.Colors.Get(this.shadowColorID).color;
				GUI.Label(
					new Rect(bounds.x + this.shadowOffset.x, 
						bounds.y + this.shadowOffset.y, 
						bounds.width,
						bounds.height), 
					content, guiStyle); 
			}
			guiStyle.normal.textColor = ORK.Colors.Get(this.colorID).color;
			GUI.Label(bounds, content, guiStyle);
		}
		
		
		/*
		============================================================================
		Data handling functions
		============================================================================
		*/
		public DataObject GetData()
		{
			DataObject data = new DataObject();
			data.Set("colorID", this.colorID);
			
			data.Set("showShadow", this.showShadow);
			data.Set("shadowColorID", this.shadowColorID);
			data.Set("shadowOffset", ArrayHelper.ToArray(this.shadowOffset));
			
			data.Set("showOutline", this.showOutline);
			data.Set("outlineColorID", this.outlineColorID);
			data.Set("outlineOffset", ArrayHelper.ToArray(this.outlineOffset));
			
			data.Set("font", this.font);
			data.Set("fontSize", this.fontSize);
			data.Set("fontStyle", this.fontStyle);
			return data;
		}

		public void SetData(DataObject data)
		{
			if(data != null)
			{
				data.Get("colorID", ref this.colorID);
				data.Get("showShadow", ref this.showShadow);
				data.Get("shadowColorID", ref this.shadowColorID);
				
				float[] tmp = null;
				if(data.Get("shadowOffset", out tmp))
				{
					this.shadowOffset = ArrayHelper.GetVector2(tmp);
				}
				
				data.Get("showOutline", ref this.showOutline);
				data.Get("outlineColorID", ref this.outlineColorID);
				
				tmp = null;
				if(data.Get("outlineOffset", out tmp))
				{
					this.outlineOffset = ArrayHelper.GetVector2(tmp);
				}
				
				data.Get("font", ref this.font);
				data.Get("fontSize", ref this.fontSize);
				data.Get("fontStyle", ref this.fontStyle);
			}
		}
	}
}
