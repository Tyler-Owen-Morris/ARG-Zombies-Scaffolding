
using UnityEngine;
using ORKFramework;
using ORKFramework.Events;
using System.Collections.Generic;

namespace ORKFramework.Animations
{
	public class AnimationSetting : BaseIndexData
	{
		[ORKEditorHelp("Name", "The name of this animation settings.", "")]
		[ORKEditorInfo("Base Settings", "Set the base settings of this animation settings.", "", 
			expandWidth=true, endFoldout=true)]
		public string name = "";
		
		
		// legacy animations
		[ORKEditorInfo("Legacy Settings", "Settings and animations for legacy animations.\n" +
			"If a combatant uses the legacy animation system, this settings and animations will be used.", "", endFoldout=true)]
		[ORKEditorArray(false, "Add Legacy Animation", "Adds a legacy animation.", "", 
			"Remove", "Removes this legacy animation.", "", isCopy=true, isMove=true, 
			removeType=ORKDataType.AnimationType, removeCheckField="typeID", 
			foldout=true, foldoutText=new string[] {"Legacy Animation", "Define the legacy animation's settings.\n" +
				"An animation type that isn't defined by the animation settings will not be used/overridden by this animation settings.", ""})]
		public LegacyAnimation[] legacy = new LegacyAnimation[0];
		
		
		// mecanim animations
		// mecanim base settings
		[ORKEditorHelp("Set Animator Speed", "Set the speed of the mecanim animator.", "")]
		[ORKEditorInfo("Mecanim Settings", "Settings and animations for mecanim.\n" +
			"If a combatant uses the mecanim animation system, this settings and animations will be used.", "")]
		public bool mSetSpeed = false;
		
		[ORKEditorInfo("Speed Value", "Define the playback speed.\n" +
			"1 is the normal playback speed, above 1 will play faster, below 1 will play slower.", "", 
			endFoldout=true, separatorForce=true)]
		[ORKEditorLayout("mSetSpeed", true, endCheckGroup=true, autoInit=true)]
		public FloatValue mSpeedValue;
		
		[ORKEditorHelp("Set Horizontal Speed", "Set the horizontal speed of the combatant to a parameter of the animator.\n" +
			"Requires a float parameter and is set every Update call.", "")]
		[ORKEditorInfo(separator=true, labelText="Auto Move Speed Parameters")]
		public bool mSetAutoHorizontal = false;
		
		[ORKEditorHelp("Horizontal Parameter", "The name of the float parameter " +
			"used to set the horizontal movement speed of the combatant.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout("mSetAutoHorizontal", true, endCheckGroup=true)]
		public string mAutoHoriziontal = "";
		
		[ORKEditorHelp("Set Vertical Speed", "Set the vertical speed of the combatant to a parameter of the animator.\n" +
			"Requires a float parameter and is set every Update call.", "")]
		public bool mSetAutoVertical = false;
		
		[ORKEditorHelp("Vertical Parameter", "The name of the float parameter " +
			"used to set the vertical movement speed of the combatant.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout("mSetAutoVertical", true, endCheckGroup=true)]
		public string mAutoVertical = "";
		
		// mecanim animations
		[ORKEditorArray(false, "Add Mecanim Animation", "Adds a mecanim animation.\n" +
			"Mecanim animations are used to set parameters of the animator to trigger the animation.", "", 
			"Remove", "Removes this mecanim animation.", "", isCopy=true, isMove=true, 
			removeType=ORKDataType.AnimationType, removeCheckField="typeID", 
			foldout=true, foldoutText=new string[] {"Mecanim Animation", "Define the mecanim animation's settings.\n" +
				"Mecanim animations are used to set parameters of the animator to trigger the animation.\n" +
				"An animation type that isn't defined by the animation settings will not be used/overridden by this animation settings.", ""})]
		public MecanimAnimation[] mecanim = new MecanimAnimation[0];
		
		// mecanim state checks
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add State Check", "Adds a mecanim animation state check.\n" +
			"State checks are used to set parameters when a defined animation is playing.", "", 
			"Remove", "Removes this state check.", "", isCopy=true, isMove=true, 
			foldout=true, foldoutText=new string[] {"State Check", "Define the active state that will be checked and the parameters that will be set.\n" +
				"State checks are used to set parameters when a defined animation is playing.\n" +
				"The state check is executed every Update call on each combatant using mecanim animations.", ""})]
		public MecanimStateCheck[] mecanimStateCheck = new MecanimStateCheck[0];
		
		
		// custom animations
		[ORKEditorInfo("Custom Settings", "Settings and animations for custom animations.\n" +
			"If a combatant uses a custom animation system, this settings and animations will be used.", "", endFoldout=true)]
		[ORKEditorArray(false, "Add Custom Animation", "Adds a custom animation.", "", 
			"Remove", "Removes this custom animation.", "", isCopy=true, isMove=true, 
			removeType=ORKDataType.AnimationType, removeCheckField="typeID", 
			foldout=true, foldoutText=new string[] {"Custom Animation", "Define the custom animation's settings.\n" +
				"Custom animations will use reflection to call functions of the custom animation component defined by the combatant.\n" +
				"An animation type that isn't defined by the animation settings will not be used/overridden by this animation settings.", ""})]
		public CustomAnimation[] custom = new CustomAnimation[0];

		public AnimationSetting()
		{
			
		}
		
		public AnimationSetting(string name)
		{
			this.name = name;
		}
		
		
		/*
		============================================================================
		Legacy animation functions
		============================================================================
		*/
		public void LegacyInit(Combatant combatant, Animation animation)
		{
			for(int i=0; i<this.legacy.Length; i++)
			{
				this.legacy[i].Init(combatant, animation);
			}
		}
		
		public bool LegacyPlay(out AnimInfo info, Animation animation, int typeID, Combatant user)
		{
			for(int i=0; i<this.legacy.Length; i++)
			{
				if(this.legacy[i].typeID == typeID)
				{
					user.Animations.LegacyRemoveStop(this.legacy[i].name);
					info = this.legacy[i].Play(animation);
					return true;
				}
			}
			info = AnimInfo.None;
			return false;
		}
		
		public bool LegacyStop(Animation animation, int typeID, Combatant user)
		{
			for(int i=0; i<this.legacy.Length; i++)
			{
				if(this.legacy[i].typeID == typeID || typeID == -1)
				{
					this.legacy[i].Stop(animation, user);
					return true;
				}
			}
			return false;
		}
		
		
		/*
		============================================================================
		Mecanim animation functions
		============================================================================
		*/
		public void MecanimInit(Combatant combatant, Animator animator, ref string horizontalParameter, ref string verticalParameter)
		{
			if(this.mSetSpeed)
			{
				animator.speed = this.mSpeedValue.GetValue(combatant, combatant) * ORK.Game.AnimationFactor;
			}
			if(this.mSetAutoHorizontal && horizontalParameter == "")
			{
				horizontalParameter = this.mAutoHoriziontal;
			}
			if(this.mSetAutoVertical && verticalParameter == "")
			{
				verticalParameter = this.mAutoVertical;
			}
		}
		
		public bool MecanimPlay(out AnimInfo info, Animator animator, int typeID)
		{
			for(int i=0; i<this.mecanim.Length; i++)
			{
				if(this.mecanim[i].typeID == typeID)
				{
					info = this.mecanim[i].Play(animator);
					return true;
				}
			}
			info = AnimInfo.None;
			return false;
		}
		
		public bool MecanimStop(Animator animator, int typeID)
		{
			for(int i=0; i<this.mecanim.Length; i++)
			{
				if(this.mecanim[i].typeID == typeID || typeID == -1)
				{
					this.mecanim[i].Stop(animator);
					return true;
				}
			}
			return false;
		}
		
		public void CheckMecanimStates(Animator animator)
		{
			for(int i=0; i<this.mecanimStateCheck.Length; i++)
			{
				this.mecanimStateCheck[i].Check(animator);
			}
		}
		
		
		/*
		============================================================================
		Custom animation functions
		============================================================================
		*/
		public void CustomInit(Component behaviour)
		{
			/*for(int i=0; i<this.custom.Length; i++)
			{
				this.custom[i].Init(combatant, behaviour);
			}*/
		}
		
		public bool CustomPlay(out AnimInfo info, Component behaviour, int typeID)
		{
			info = new AnimInfo(AnimationSystem.Custom, "", 0);
			for(int i=0; i<this.custom.Length; i++)
			{
				if(this.custom[i].typeID == typeID)
				{
					this.custom[i].Play(behaviour);
					return true;
				}
			}
			return false;
		}
		
		public bool CustomStop(Component behaviour, int typeID)
		{
			for(int i=0; i<this.custom.Length; i++)
			{
				if(this.custom[i].typeID == typeID || typeID == -1)
				{
					this.custom[i].Stop(behaviour);
					return true;
				}
			}
			return false;
		}
	}
}
