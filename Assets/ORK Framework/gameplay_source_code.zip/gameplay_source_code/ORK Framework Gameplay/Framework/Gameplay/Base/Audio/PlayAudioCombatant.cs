
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	[System.Serializable]
	public class PlayAudioCombatant : BaseData
	{
		[ORKEditorHelp("Use Sound Type", "The combatant's defined sound of a selected sound type will be used.", "")]
		[ORKEditorInfo(separator=true, labelText="Audio Settings")]
		public bool useSoundType = false;
		
		[ORKEditorHelp("Sound Type", "Select the sound type that will be played.", "")]
		[ORKEditorInfo(ORKDataType.SoundType)]
		[ORKEditorLayout("useSoundType", true)]
		public int soundTypeID = 0;
		
		[ORKEditorHelp("Audio Clip", "The selected audio clip will be played.", "")]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public AudioClip audioClip;
		
		[ORKEditorHelp("Volume", "The volume used to play the audio clip.", "")]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float volume = 1;
		
		public PlayAudioCombatant()
		{
			
		}
		
		public void Play(Combatant combatant)
		{
			if(combatant != null)
			{
				AudioClip clip = null;
				
				if(this.useSoundType)
				{
					clip = combatant.Animations.GetAudioClip(this.soundTypeID);
				}
				else if(this.audioClip != null)
				{
					clip = this.audioClip;
				}
				
				if(clip != null && combatant.GameObject != null)
				{
					AudioSource src = combatant.GetAudioSource();
					if(src != null)
					{
						src.PlayOneShot(clip, this.volume * ORK.Game.SoundVolume);
					}
				}
			}
		}
	}
}
