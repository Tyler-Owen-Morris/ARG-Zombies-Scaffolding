
namespace ORKFramework
{
	public class BaseLanguageData : BaseIndexData
	{
		[ORKEditorInfo("Content Information", "Set the name, description and icon.", "", endFoldout=true, hide=true)]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		public LanguageInfo[] languageInfo;
		
		public BaseLanguageData()
		{
			
		}
		
		public BaseLanguageData(string name)
		{
			this.languageInfo = new LanguageInfo[ORK.Languages.Count];
			for(int i=0; i<this.languageInfo.Length; i++)
			{
				this.languageInfo[i] = new LanguageInfo(name);
			}
		}
	}
}
