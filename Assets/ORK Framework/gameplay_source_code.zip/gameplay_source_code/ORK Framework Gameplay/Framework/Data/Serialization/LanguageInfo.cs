
using UnityEngine;

namespace ORKFramework
{
	public class LanguageInfo : BaseData
	{
		[ORKEditorHelp("Name", "Define the name.", "")]
		[ORKEditorInfo(expandWidth=true, callbackBefore="textcodes:name")]
		public string name = "";

		[ORKEditorHelp("Description", "Define the description.", "")]
		[ORKEditorInfo(isTextArea=true, callbackBefore="textcodes:description")]
		public string description = "";

		[ORKEditorHelp("Icon", "Select the icon.", "")]
		public Texture2D icon;
		
		public LanguageInfo()
		{
			
		}
		
		public LanguageInfo(string n)
		{
			this.name = n;
		}
		
		public string GetName()
		{
			return this.name;
		}
		
		public string GetDescription()
		{
			return this.description;
		}
		
		public Texture2D GetIcon()
		{
			return this.icon;
		}
		
		public GUIContent GetContent()
		{
			return new GUIContent(this.name, this.icon);
		}
	}
}
