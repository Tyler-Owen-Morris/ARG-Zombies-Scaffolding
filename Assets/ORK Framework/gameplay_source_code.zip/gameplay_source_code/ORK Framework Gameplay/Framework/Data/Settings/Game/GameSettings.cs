
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GameSettings : BaseSettings
	{
		// base settings
		// interaction settings
		[ORKEditorHelp("Max. Event Steps", "The maximum number of event steps executed without an update cycle.\n" +
			"This setting influences how fast game/battle event steps (without a wait time) will execute after the previous step - " +
			"the lower the number, the slower the event execution.\n" +
			"Reduce this number if you experience stack overflow errors in events.", "")]
		[ORKEditorInfo("Base Settings", "Base game settings, e.g. default screen size.", "", 
			labelText="Interaction Settings")]
		[ORKEditorLimit(0, false)]
		public int maxSteps = 100;
		
		[ORKEditorHelp("Max Click Distance", "The maximum distance in world units to allow " +
			"starting an 'Interaction' type interaction by clicking/touching the game object.\n" +
			"Set to 0 to not allow clicking.\n\n" +
			"Set to -1 to allow clicking without checking the distance." +
			"This setting can be overridden by the individual interactions.", "")]
		[ORKEditorLimit(-1.0f, false)]
		public float maxClickDistance = 3;
		
		// gui settings
		[ORKEditorHelp("Default Screen Size", "The width and height of the screen size you are designing for.\n" +
			"This setting is used to calculate the GUIMatrix and affect every GUI and HUD.\n" +
			"If you run your game on a different screen resolution, ORK will scale all GUI and HUD elements to fit the new screen size.", "")]
		[ORKEditorInfo(separator=true, labelText="Screen/GUI Settings")]
		public Vector2 defaultScreen = new Vector2(1280.0f, 800.0f);
		
		[ORKEditorHelp("GUI Padding", "The padding added to GUI at the borders of the screen - " +
			"left (x), top (y), right (z) and bottom (w).", "")]
		public Vector4 guiPadding = Vector4.zero;
		
		[ORKEditorHelp("GUI Scale Mode", "Select how the GUI will be changed to match different screen resolutions:\n" +
			"- Stretch To Fill: The GUI will be stretched to fill the complete screen. " +
			"The GUI always fits the screen, but can be distorted.\n" +
			"- Scale And Crop: The GUI will be scaled to match the biggest value (width or height) of the screen. " +
			"Some parts of the GUI can be placed outside of the screen.\n" +
			"- Scale To Fit: The GUI will be scaled to match the smallest value (width or height) of the screen. " +
			"The GUI always fits the screen.\n" +
			"- No Scale: The GUI wont be scaled. Some parts of the GUI can be placed outside of the screen.", "")]
		public GUIScaleMode guiScaleMode = GUIScaleMode.StretchToFill;
		
		[ORKEditorHelp("GUI Anchor", "Select the anchor of the GUI when scaling/placing " +
			"for different resolutions and aspect ratios.", "")]
		[ORKEditorLayout("guiScaleMode", GUIScaleMode.StretchToFill, elseCheckGroup=true, endCheckGroup=true)]
		public TextAnchor guiAnchor = TextAnchor.UpperLeft;
		
		[ORKEditorHelp("Secure Drag", "Drag windows can't be dragged outside the screen.", "")]
		public bool secureWindowDrag = true;
		
		// random range
		[ORKEditorHelp("Min. Random Range", "The minimum number used for calculating a random number " +
			"for chance checks (e.g. hit chance, counter chance, item drop chance, etc.).", "")]
		[ORKEditorInfo(separator=true, labelText="Chance Settings")]
		public float minRandomRange = 0;
		
		[ORKEditorHelp("Max. Random Range", "The maximum number used for calculating a random number " +
			"for chance checks (e.g. hit chance, counter chance, item drop chance, etc.).", "")]
		public float maxRandomRange = 100;
		
		// raycast settings
		[ORKEditorHelp("Raycast Type", "Select the type of raycast that is used:\n" +
			"- Only 3D: Only 3D raycasts are used.\n" +
			"- Only 2D: Only 2D raycasts are used.\n" +
			"- First 3D: Uses a 3D raycast first, if no object is found, a 2D raycast are used.\n" +
			"- First 2D: Uses a 2D raycast first, if no object is found, a 3D raycast is used.", "")]
		[ORKEditorInfo(separator=true, labelText="Raycast Settings")]
		public RaycastType raycastType = RaycastType.Only3D;
		
		// data encryption
		[ORKEditorHelp("Encrypt Data", "The ORK project data files will be encrypted.\n" +
			"If disabled, the files are saved in plain text.", "")]
		[ORKEditorInfo(separator=true, labelText="Data Settings", endFoldout=true)]
		public bool encryptData = false;
		
		
		// area notification display
		[ORKEditorHelp("Show Once", "Area notifications will only be displayed when first entering an area.\n" +
			"Once the player visited an area, the notification will not be displayed again.", "")]
		[ORKEditorInfo("Area Settings", "The default layout for area notifications.\n" +
			"The layout can be overridden by each area.", "")]
		public bool showAreasOnce = false;
		
		[ORKEditorHelp("Queue Area Notifications", "Area notifications will be queued " +
			"(i.e. they will be displayed in sequence).\n" +
			"If disabled, a new area notification will replace a currently displayed area notification.", "")]
		public bool queueAreaNotifications = false;
		
		[ORKEditorInfo(separator=true, endFoldout=true, labelText="Notification Layout")]
		public AreaNotificationLayout areaNotificationLayout = new AreaNotificationLayout();
		
		
		// quest settings
		[ORKEditorHelp("Active Quests", "Define the number of quests that can be active at the same time.\n" +
			"If the number of active quests is succeeded (e.g. by activating an inactive quest or adding a new quest), " +
			"one of the currently active quests will be set inactive.", "")]
		[ORKEditorInfo("Quest Settings", "The basic quest settings, layout and notifications are defined here.", "")]
		[ORKEditorLimit(1, false)]
		public int activeQuests = 5;
		
		[ORKEditorHelp("Display Initial Tasks", "Display the notifications of a quest's initial tasks when adding the quest.\n" +
			"Initial tasks are tasks that will be activated when the quest is added.", "")]
		public bool displayInitialTasks = false;
		
		[ORKEditorHelp("Queue Quest Notifications", "Quest notifications will be queued " +
			"(i.e. they will be displayed in sequence).\n" +
			"If disabled, a new quest notification will replace a currently displayed quest notification.", "")]
		public bool queueQuestNotifications = false;
		
		[ORKEditorHelp("Queue Task Notifications", "Task notifications will be queued " +
			"(i.e. they will be displayed in sequence).\n" +
			"If disabled, a new task notification will replace a currently displayed task notification.", "")]
		public bool queueTaskNotifications = false;
		
		[ORKEditorInfo("Default Quest Layout", "The quest layout is used to display " +
			"quest information (e.g. tasks, rewards) in menus and dialogues." +
			"The default quest layout can be overridden by each quest individually.", "", 
			endFoldout=true)]
		public QuestLayout questLayout = new QuestLayout();
		
		// quest notifications
		[ORKEditorInfo(endFoldout=true)]
		public QuestNotificationSettings questNotifications = new QuestNotificationSettings();
		
		
		// player group
		[ORKEditorHelp("Battle Group Size", "The maximum size of the player's battle group.\n" +
			"Enemies can form as large battle groups as you like", "")]
		[ORKEditorInfo("Player/Group Settings", "Player group spawn and player components.", "")]
		[ORKEditorLimit(1, false)]
		public int maxBattleGroup = 3;
		
		[ORKEditorHelp("Default Faction", "Select the default faction a player group will belong to.\n" +
			"The faction of a player group can be changed using the event system.", "")]
		[ORKEditorInfo(ORKDataType.Faction)]
		public int playerFactionID = 0;
		
		[ORKEditorHelp("Spawn Group", "Group members will spawn if the player is spawned.\n" +
			"The members will spawn when spawning the player and changing the group.", "")]
		[ORKEditorInfo(separator=true, labelText="Group Spawn Settings")]
		public bool spawnGroup = false;
		
		[ORKEditorHelp("Only in Battles", "The group will be spawned only when you enter a battle area.\n" +
			"This is only used in REALTIME type battles, TURN and ACTIVE type battles will automatically spawn the " +
			"battle party members at their battle spots.", "")]
		public bool onlyInBattleArea = false;
		
		[ORKEditorHelp("Distance", "The distance to the player the other group members will be spawned.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLimit(0.0f, false)]
		public float spawnDistance = 3;
		
		
		// statistics
		[ORKEditorInfo("Statistic Settings", "Select which statistics the game will keep.", "", endFoldout=true)]
		public GameStatistic statistic = new GameStatistic();
		
		
		// bestiary
		[ORKEditorInfo("Bestiary Settings", "Define if the bestiary is used and how information on enemies is learned.\n" +
			"The bestiary provides information about encountered enemy combatants, e.g. status values and attack/defence attributes.", "", 
			endFoldout=true)]
		public BestiarySettings bestiary = new BestiarySettings();
		
		
		// game over
		[ORKEditorInfo("Game Over Settings", "Game over scene and retry/load choice.", "", endFoldout=true)]
		public GameOverChoice gameOver = new GameOverChoice();
		
		
		// initial game variables
		[ORKEditorInfo("Initial Game Variables", 
			"Define game variables that will be automatically set when starting the game.\n" +
			"The variables will be set when ORK is initialized, " +
			"i.e. before the main menu - you can use this to set up custom options.\n" +
			"The variables will be kept when starting a new game - " +
			"but keep in mind that loading a saved game will clear all previous game variables.", "", 
			endFoldout=true)]
		public VariableSetter initialVariables = new VariableSetter();
		
		public GameSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
		}
		
		public override void SetRealIDs()
		{
			
		}
		
		
		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get{ return "gameSettings"; }
		}
		
		
		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			return "";
		}

		public override string[] GetNames(bool addIndex)
		{
			return new string[0];
		}

		public override int Count
		{
			get
			{
				return 0;
			}
		}
		
		
		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			return -1;
		}
		
		public override int Copy(int index)
		{
			return -1;
		}
		
		public override void Remove(int index)
		{
			
		}
		
		public override void Move(int index, bool down)
		{
			
		}
		
		public void CheckDragWindowPosition(ref Rect windowRect)
		{
			if(windowRect.x < 0)
			{
				windowRect.x = 0;
			}
			else if((windowRect.x + windowRect.width) > this.defaultScreen.x)
			{
				windowRect.x = this.defaultScreen.x - windowRect.width;
			}
			if(windowRect.y < 0)
			{
				windowRect.y = 0;
			}
			else if((windowRect.y + windowRect.height) > this.defaultScreen.y)
			{
				windowRect.y = this.defaultScreen.y - windowRect.height;
			}
		}
		
		public Vector3 GetScreenCenter()
		{
			return new Vector3(this.defaultScreen.x / 2, this.defaultScreen.y / 2, 0);
		}
		
		
		/*
		============================================================================
		Chance/Random functions
		============================================================================
		*/
		public float GetRandom()
		{
			return Random.Range(this.minRandomRange, this.maxRandomRange);
		}
		
		public bool CheckRandom(float chance)
		{
			float rnd = this.GetRandom();
			if(rnd > this.minRandomRange && rnd <= chance)
			{
				return true;
			}
			return false;
		}
	}
}
