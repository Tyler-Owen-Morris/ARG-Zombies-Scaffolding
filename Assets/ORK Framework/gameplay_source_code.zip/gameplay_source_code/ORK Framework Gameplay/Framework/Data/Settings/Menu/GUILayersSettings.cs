
using UnityEngine;

namespace ORKFramework
{
	public class GUILayersSettings : BaseSettings
	{
		public ORKGUILayer[] data = new ORKGUILayer[] {new ORKGUILayer("Default Layer")};
		
		public GUILayersSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}
		
		public override void SetRealIDs()
		{
			this.SetRealIDs(this.data);
		}
		
		
		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get{ return "guiLayers"; }
		}
		
		
		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			if(index >= 0 && index < this.data.Length)
			{
				return this.data[index].name;
			}
			else
			{
				return "GUI Layer(" + index + ") not found";
			}
		}

		public override string[] GetNames(bool addIndex)
		{
			string[] names = new string[this.data.Length];
			for(int i=0; i<names.Length; i++)
			{
				if(addIndex)
				{
					names[i] = i + ": " + this.data[i].name;
				}
				else
				{
					names[i] = this.data[i].name;
				}
			}
			return names;
		}
		
		public override int Count
		{
			get{ return this.data.Length;}
		}
		
		
		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			ArrayHelper.Add(ref this.data, new ORKGUILayer("New"));
			DataHelper.Added(ORKDataType.GUILayer);
			return this.data.Length-1;
		}
		
		public override int Copy(int index)
		{
			ArrayHelper.Add(ref this.data, this.GetCopy(index));
			DataHelper.Added(ORKDataType.GUILayer);
			return this.data.Length-1;
		}
		
		public ORKGUILayer GetCopy(int index)
		{
			ORKGUILayer t = new ORKGUILayer("");
			if(index >= 0 && index < this.data.Length)
			{
				t.SetData(this.data[index].GetData());
			}
			return t;
		}
		
		public override void Remove(int index)
		{
			ArrayHelper.RemoveAt(ref this.data, index);
			DataHelper.Removed(ORKDataType.GUILayer, index);
		}
		
		public ORKGUILayer Get(int index)
		{
			if(index >= 0 && index < this.Count)
			{
				return this.data[index];
			}
			else
			{
				return this.data[0];
			}
		}
		
		public override void Move(int index, bool down)
		{
			if(down)
			{
				ArrayHelper.MoveDown(ref this.data, index);
			}
			else
			{
				ArrayHelper.MoveUp(ref this.data, index);
			}
			DataHelper.Moved(ORKDataType.GUILayer, down, index);
		}
	}
}

