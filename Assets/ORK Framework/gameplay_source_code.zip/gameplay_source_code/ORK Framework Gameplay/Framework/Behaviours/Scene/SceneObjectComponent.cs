
using UnityEngine;
using ORKFramework;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Scenes/Scene Object")]
	public class SceneObjectComponent : MonoBehaviour
	{
		[ORKEditorInfo(ORKDataType.SceneObject)]
		public int sceneObjectID = 0;
		
		
		// variable conditions
		public bool autoDestroy = true;
		
		public bool repeatDestroy = false;
		
		public float destroyCheckTime = 1;
		
		public bool checkObjectVariables = false;
		
		public VariableCondition variableCondition = new VariableCondition();
		
		
		// ingame
		protected bool isInvoking = false;
		
		public SceneObject GetSceneObject()
		{
			if(this.CheckVariables())
			{
				return ORK.SceneObjects.Get(this.sceneObjectID);
			}
			else
			{
				return null;
			}
		}
		
		
		/*
		============================================================================
		Auto start functions
		============================================================================
		*/
		void Start()
		{
			if(!this.CheckAutoDestroy())
			{
				SceneObject sceneObject = ORK.SceneObjects.Get(this.sceneObjectID);
				if(sceneObject.useObjectVariables)
				{
					sceneObject.objectVariables.AddComponent(this.gameObject);
				}
			}
		}
		
		
		/*
		============================================================================
		Variable functions
		============================================================================
		*/
		public bool CheckVariables()
		{
			if(this.checkObjectVariables)
			{
				ObjectVariablesComponent comp = ComponentHelper.
					GetInChildren<ObjectVariablesComponent>(this.gameObject);
				if(comp != null)
				{
					return this.variableCondition.CheckVariables(comp.GetHandler());
				}
			}
			else
			{
				return this.variableCondition.CheckVariables();
			}
			return false;
		}
		
		
		/*
		============================================================================
		Auto destroy functions
		============================================================================
		*/
		protected bool CheckAutoDestroy()
		{
			if(this.autoDestroy)
			{
				if(!this.CheckVariables())
				{
					GameObject.Destroy(this.gameObject);
					return true;
				}
				else if(this.repeatDestroy && !this.isInvoking)
				{
					this.isInvoking = true;
					this.InvokeRepeating("AutoDestroy", this.destroyCheckTime, this.destroyCheckTime);
				}
			}
			return false;
		}
		
		protected void AutoDestroy()
		{
			if(this.CheckAutoDestroy())
			{
				GameObject.Destroy(this.gameObject);
				this.CancelInvoke("AutoDestroy");
				this.isInvoking = false;
			}
		}
		
	
		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "SceneObject.psd");
		}
	}
}
