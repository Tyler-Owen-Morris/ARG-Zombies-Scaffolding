
using ORKFramework;
using System.Collections;
using UnityEngine;

namespace ORKFramework.Behaviours
{
	public abstract class BaseInteraction : BaseConditionComponent
	{
		private bool registered = false;
		
		
		// start type
		public EventStartType startType = EventStartType.None;
		
		public bool inBlockedControl = false;
		
		public string customType = "";
		
		
		// auto start
		public float autoStartAfter = 0;
		
		
		// click/touch interaction
		public bool allowClick = true;
		
		public bool overrideClickDistance = false;
		
		public float maxClickDistance = 3;
		
		
		// key press interaction
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int keyToPress = 0;
		
		public bool keyPressInTrigger = false;
		
		public bool keyPressWhileColliding = false;
		
		
		// item drop interaction
		public ItemGain dropItem = new ItemGain();
		
		public bool consumeDrop = false;
		
		
		// trigger enter/exit
		public bool useOtherObject = false;
		
		public EventStartObject startObjectCheck;
		
		
		// orientation settings
		public bool useFront = true;
		
		public bool useBack = true;
		
		public bool useLeft = true;
		
		public bool useRight = true;
		
		
		// ingame
		protected int isInTrigger = 0;
		
		protected int isColliding = 0;
		
		protected bool eventStarted = false;
		
		
		/*
		============================================================================
		Register functions
		============================================================================
		*/
		void OnEnable()
		{
			if(!this.registered && ORK.Instantiated)
			{
				ORK.Game.Interactions.Add(this);
				this.registered = true;
			}
		}
		
		void OnDisable()
		{
			if(this.registered && ORK.Instantiated)
			{
				ORK.Game.Interactions.Remove(this);
				this.registered = false;
			}
		}
		
		public bool EventStarted
		{
			get{ return this.eventStarted;}
		}
		
		
		/*
		============================================================================
		Interaction type functions
		============================================================================
		*/
		public abstract InteractionType Type
		{
			get;
		}
		
		/*
		============================================================================
		Start event functions
		============================================================================
		*/
		public IEnumerator StartEvent(GameObject startingObject, float delay)
		{
			yield return new WaitForSeconds(delay);
			this.StartEvent(startingObject);
		}
		
		public virtual void StartEvent(GameObject startingObject)
		{
			
		}
		
		
		/*
		============================================================================
		Auto start functions
		============================================================================
		*/
		void Start()
		{
			if(!this.CheckAutoDestroy())
			{
				this.AutoStart();
			}
		}
		
		public void AutoStart()
		{
			if(EventStartType.Autostart.Equals(this.startType) && 
				this.CheckConditions())
			{
				if(this.autoStartAfter > 0)
				{
					this.StartCoroutine(this.StartEvent(this.gameObject, this.autoStartAfter));
				}
				else
				{
					
					this.StartEvent(this.gameObject);
				}
			}
		}
		
		
		/*
		============================================================================
		Interaction functions
		============================================================================
		*/
		public virtual bool CanInteract(EventStartType type, GameObject gameObject)
		{
			return this.startType.Equals(type) && 
				(this.inBlockedControl || ORK.Control.CanInteract) && 
				this.CheckOrientation(gameObject) && 
				this.CheckConditions() && this.gameObject.activeInHierarchy;
		}
		
		public bool CheckOrientation(GameObject gameObject)
		{
			if(gameObject != null)
			{
				Orientation orientation = VectorHelper.GetOrientation(this.transform, gameObject.transform);
		
				return Orientation.None.Equals(orientation) || 
					(Orientation.Front.Equals(orientation) && this.useFront) || 
					(Orientation.Back.Equals(orientation) && this.useBack) || 
					(Orientation.Left.Equals(orientation) && this.useLeft) || 
					(Orientation.Right.Equals(orientation) && this.useRight);
			}
			return true;
		}
		
		public virtual bool Interact()
		{
			if(this.CanInteract(EventStartType.Interact, ORK.Game.GetPlayer()))
			{
				this.StartEvent(ORK.Game.GetPlayer());
				return true;
			}
			return false;
		}
		
		public virtual void TouchInteract()
		{
			this.OnMouseUp();
		}
		
		void OnMouseUp()
		{
			if(this.CanInteract(EventStartType.Interact, ORK.Game.GetPlayer()) && this.allowClick)
			{
				GameObject p = ORK.Game.GetPlayer();
				
				float clickDistance = this.overrideClickDistance ? 
					this.maxClickDistance : ORK.GameSettings.maxClickDistance;
				
				if(clickDistance == -1 || 
					(p != null && clickDistance > 0 && 
					Vector3.Distance(p.transform.position, this.transform.position) < clickDistance))
				{
					this.StartEvent(ORK.Game.GetPlayer());
				}
			}
		}
		
		public virtual bool DropInteract(DragInfo drag)
		{
			if(this.CanInteract(EventStartType.Drop, ORK.Game.GetPlayer()) && 
				this.CheckDrop(drag))
			{
				this.StartEvent(ORK.Game.GetPlayer());
				return true;
			}
			return false;
		}
		
		public bool CheckDrop(DragInfo drag)
		{
			if(drag != null && drag.Shortcut != null)
			{
				if(this.dropItem.CheckDrop(drag.Shortcut))
				{
					if(this.consumeDrop && this.dropItem.CheckChance())
					{
						ORK.Game.ActiveGroup.Inventory.Remove(drag.Shortcut, 1, true, true);
					}
					// TODO: ability drops?
					drag.Origin.Dropped(drag);
					return true;
				}
			}
			return false;
		}
		
		public bool CheckStartObject(GameObject gameObject)
		{
			return gameObject != null && 
				((!this.useOtherObject && 
					(gameObject == ORK.Game.GetPlayer() || 
						(ORK.Game.GetPlayer() != null && 
						gameObject.transform.root == ORK.Game.GetPlayer().transform.root))) || 
				(this.useOtherObject && this.startObjectCheck.CheckObject(gameObject)));
		}
		
		
		/*
		============================================================================
		Trigger functions
		============================================================================
		*/
		void OnTriggerEnter(Collider other)
		{
			if(this.CheckStartObject(other.gameObject))
			{
				this.isInTrigger++;
				if(this.CanInteract(EventStartType.TriggerEnter, other.gameObject))
				{
					this.StartEvent(other.gameObject);
				}
			}
		}
		
		void OnTriggerExit(Collider other)
		{
			if(this.CheckStartObject(other.gameObject))
			{
				this.isInTrigger--;
				if(this.CanInteract(EventStartType.TriggerExit, other.gameObject))
				{
					this.StartEvent(other.gameObject);
				}
			}
		}
		
		void OnTriggerStay(Collider other)
		{
			if(this.CheckStartObject(other.gameObject))
			{
				if(this.CanInteract(EventStartType.TriggerStay, other.gameObject))
				{
					this.StartEvent(other.gameObject);
				}
			}
		}
		
		
		/*
		============================================================================
		Trigger2D functions
		============================================================================
		*/
		void OnTriggerEnter2D(Collider2D other)
		{
			if(this.CheckStartObject(other.gameObject))
			{
				this.isInTrigger++;
				if(this.CanInteract(EventStartType.TriggerEnter, other.gameObject))
				{
					this.StartEvent(other.gameObject);
				}
			}
		}
		
		void OnTriggerExit2D(Collider2D other)
		{
			if(this.CheckStartObject(other.gameObject))
			{
				this.isInTrigger--;
				if(this.CanInteract(EventStartType.TriggerExit, other.gameObject))
				{
					this.StartEvent(other.gameObject);
				}
			}
		}
		
		void OnTriggerStay2D(Collider2D other)
		{
			if(this.CheckStartObject(other.gameObject))
			{
				if(this.CanInteract(EventStartType.TriggerStay, other.gameObject))
				{
					this.StartEvent(other.gameObject);
				}
			}
		}
		
		
		/*
		============================================================================
		Collision functions
		============================================================================
		*/
		void OnCollisionEnter(Collision collision)
		{
			if(this.CheckStartObject(collision.gameObject))
			{
				this.isColliding++;
				if(this.CanInteract(EventStartType.CollisionEnter, collision.gameObject))
				{
					this.StartEvent(collision.gameObject);
				}
			}
		}
		
		void OnCollisionExit(Collision collision)
		{
			if(this.CheckStartObject(collision.gameObject))
			{
				this.isColliding--;
				if(this.CanInteract(EventStartType.CollisionExit, collision.gameObject))
				{
					this.StartEvent(collision.gameObject);
				}
			}
		}
		
		void OnCollisionStay(Collision collision)
		{
			if(this.CheckStartObject(collision.gameObject))
			{
				if(this.CanInteract(EventStartType.CollisionStay, collision.gameObject))
				{
					this.StartEvent(collision.gameObject);
				}
			}
		}
		
		
		/*
		============================================================================
		Collision2D functions
		============================================================================
		*/
		void OnCollisionEnter2D(Collision2D collision)
		{
			if(this.CheckStartObject(collision.gameObject))
			{
				this.isColliding++;
				if(this.CanInteract(EventStartType.CollisionEnter, collision.gameObject))
				{
					this.StartEvent(collision.gameObject);
				}
			}
		}
		
		void OnCollisionExit2D(Collision2D collision)
		{
			if(this.CheckStartObject(collision.gameObject))
			{
				this.isColliding--;
				if(this.CanInteract(EventStartType.CollisionExit, collision.gameObject))
				{
					this.StartEvent(collision.gameObject);
				}
			}
		}
		
		void OnCollisionStay2D(Collision2D collision)
		{
			if(this.CheckStartObject(collision.gameObject))
			{
				if(this.CanInteract(EventStartType.CollisionStay, collision.gameObject))
				{
					this.StartEvent(collision.gameObject);
				}
			}
		}
		
		
		/*
		============================================================================
		Key functions
		============================================================================
		*/
		void Update()
		{
			if(!this.registered)
			{
				this.OnEnable();
			}
			this.KeyPress();
		}
		
		public void KeyPress()
		{
			if(!ORK.Game.Paused && 
				this.CanInteract(EventStartType.KeyPress, ORK.Game.GetPlayer()) && 
				ORK.InputKeys.Get(this.keyToPress).GetButton() &&
				(!this.keyPressInTrigger || this.isInTrigger > 0) && 
				(!this.keyPressWhileColliding || this.isColliding > 0))
			{
				this.StartEvent(ORK.Game.GetPlayer());
			}
		}
		
		
		/*
		============================================================================
		Forward interaction functions
		============================================================================
		*/
		public bool ForwardInteract()
		{
			return this.Interact();
		}
		
		public void ForwardTouchInteract()
		{
			this.TouchInteract();
		}
		
		public void ForwardOnMouseUp()
		{
			this.OnMouseUp();
		}
		
		public bool ForwardDropInteract(DragInfo drag)
		{
			return this.DropInteract(drag);
		}
		
		public void ForwardOnTriggerEnter(Collider other)
		{
			this.OnTriggerEnter(other);
		}
		
		public void ForwardOnTriggerExit(Collider other)
		{
			this.OnTriggerExit(other);
		}
		
		public void ForwardOnTriggerStay(Collider other)
		{
			this.OnTriggerStay(other);
		}
		
		public void ForwardOnTriggerEnter2D(Collider2D other)
		{
			this.OnTriggerEnter2D(other);
		}
		
		public void ForwardOnTriggerExit2D(Collider2D other)
		{
			this.OnTriggerExit2D(other);
		}
		
		public void ForwardOnTriggerStay2D(Collider2D other)
		{
			this.OnTriggerStay2D(other);
		}
		
		public void ForwardOnCollisionEnter(Collision collision)
		{
			this.OnCollisionEnter(collision);
		}
		
		public void ForwardOnCollisionExit(Collision collision)
		{
			this.OnCollisionExit(collision);
		}
		
		public void ForwardOnCollisionStay(Collision collision)
		{
			this.OnCollisionStay(collision);
		}
		
		public void ForwardOnCollisionEnter2D(Collision2D collision)
		{
			this.OnCollisionEnter2D(collision);
		}
		
		public void ForwardOnCollisionExit2D(Collision2D collision)
		{
			this.OnCollisionExit2D(collision);
		}
		
		public void ForwardOnCollisionStay2D(Collision2D collision)
		{
			this.OnCollisionStay2D(collision);
		}
	}
}