
using ORKFramework;
using UnityEngine;
using System.Collections;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("")]
	public class CameraEventMover : MonoBehaviour
	{
		private Transform cam;
		
		private Camera cameraComponent;

		private float time;

		private float time2;

		private float hitTime;
	
	
		// mover
		private bool running = false;

		private CameraPosition camPos;

		private Transform target;
	
		private Function interpolate;

		private Vector3 startPos;

		private Vector3 distancePos;

		private Quaternion startRot;

		private Quaternion endRot;

		private float startFoV;

		private float distanceFov;
	
	
		// shaker
		private bool shaking = false;

		private float intensity;

		private float originalPosition;

		private float shakeSpeed;
	
	
		// rotater
		private bool rotating = false;

		private float rotateSpeed ;

		private Vector3 rotationAxis;
		
		public void Stop()
		{
			this.shaking = false;
			this.running = false;
			this.rotating = false;
		}
	
		public void SetTargetData(CameraPosition cp, Transform camera, Transform target, EaseType et, float t)
		{
			this.Stop();
		
			this.camPos = cp;
			this.cam = camera;
			this.cameraComponent = this.cam.GetComponent<Camera>();
			this.target = target;
			this.interpolate = Interpolate.Ease(et);
			this.time = 0;
			this.time2 = t;
		
			Transform tmp = new GameObject().transform;
			tmp.position = camera.position;
			tmp.rotation = camera.rotation;
			this.camPos.Use(tmp, this.target);
			
			this.startPos = this.cam.position;
			this.distancePos = tmp.position - this.startPos;
			this.startRot = this.cam.rotation;
			this.endRot = tmp.rotation;
			if(this.cameraComponent != null)
			{
				this.startFoV = this.cameraComponent.fieldOfView;
			}
			this.distanceFov = this.camPos.fieldOfView - this.startFoV;
			GameObject.Destroy(tmp.gameObject);
			
			this.running = true;
		}
	
		public void SetTargetData(Vector3 pos, Quaternion rot, float fov, Transform camera, EaseType et, float t)
		{
			this.Stop();
		
			this.cam = camera;
			this.cameraComponent = this.cam.GetComponent<Camera>();
			this.interpolate = Interpolate.Ease(et);
			this.time = 0;
			this.time2 = t;
			this.camPos = null;
			
			this.startPos = this.cam.position;
			this.distancePos = pos - this.startPos;
			this.startRot = this.cam.rotation;
			this.endRot = rot;
			if(this.cameraComponent != null)
			{
				this.startFoV = this.cameraComponent.fieldOfView;
			}
			this.distanceFov = fov - this.startFoV;
			this.running = true;
		}
	
		public void CameraShake(Transform camera, float t, float i, float speed)
		{
			this.Stop();
		
			this.cam = camera;
			this.cameraComponent = this.cam.GetComponent<Camera>();
			this.time = 0;
			this.time2 = t;
			this.intensity = i;
			this.shakeSpeed = speed;
		
			this.hitTime = Time.time;
			this.originalPosition = this.cam.localPosition.x;
			this.shaking = true;
		}
	
		public void CameraRotate(Transform camera, Transform target, Vector3 axes, float t, float speed)
		{
			this.Stop();
		
			this.cam = camera;
			this.cameraComponent = this.cam.GetComponent<Camera>();
			this.target = target;
			this.rotationAxis = axes;
			this.time = 0;
			this.time2 = t;
			this.rotateSpeed = speed;
		
			this.rotating = true;
		}
	
		void Update()
		{
			if(this.cam != null)
			{
				if(this.running && !ORK.Game.Paused)
				{
					this.time += ORK.Game.DeltaTime;
					this.cam.position = Interpolate.Ease(this.interpolate, this.startPos, this.distancePos, this.time, this.time2);
					this.cam.rotation = Interpolate.Ease(this.interpolate, this.startRot, this.endRot, this.time, this.time2);
					if(this.cameraComponent != null)
					{
						this.cameraComponent.fieldOfView = Interpolate.Ease(this.interpolate, this.startFoV, this.distanceFov, this.time, this.time2);
					}
					if(this.time >= this.time2)
					{
						this.running = false;
					}
				}
				else if(this.shaking && !ORK.Game.Paused)
				{
					this.time += ORK.Game.DeltaTime;
					float timer = (Time.time - hitTime) * shakeSpeed;
					float factor = (1 - ((this.time2 - this.time) / this.time2));
					this.cam.localPosition = new Vector3(originalPosition + Mathf.Sin(timer) * this.intensity * factor, this.cam.localPosition.y, this.cam.localPosition.z);
					if(timer > Mathf.PI * 2)
					{
						hitTime = Time.time;
					}
					if(this.time >= this.time2)
					{
						this.cam.localPosition = new Vector3(originalPosition, this.cam.localPosition.y, this.cam.localPosition.z);
						this.shaking = false;
					}
				}
				else if(this.rotating && !ORK.Game.Paused)
				{
					float t = ORK.Game.DeltaTime;
					this.time += t;
					this.cam.RotateAround(this.target.position, this.rotationAxis, this.rotateSpeed * t);
					if(this.time >= this.time2)
					{
						this.rotating = false;
					}
				}
			}
		}
	}
}
